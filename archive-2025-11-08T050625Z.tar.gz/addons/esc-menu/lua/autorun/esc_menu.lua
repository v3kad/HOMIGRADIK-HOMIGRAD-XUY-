-- "addons\\esc-menu\\lua\\autorun\\esc_menu.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
escMenu = escMenu or {}
escMenu.cfg = escMenu.cfg or {
    logoUrl = "",
    leftBarItems = { top = {}, bottom = {} },
    socialMedia = {},
    footerFontWeight = 800
}

if SERVER then
    AddCSLuaFile('esc-menu/cl_init.lua')
    AddCSLuaFile('esc-menu/vgui/mhs_pause_bar_button.lua')
    AddCSLuaFile('esc-menu/vgui/mhs_pause_leftbar.lua')
    AddCSLuaFile('esc-menu/vgui/mhs_pause_panel.lua')
    AddCSLuaFile('esc-menu/vgui/mhs_pause_scrollpanel.lua')
    AddCSLuaFile('esc-menu/vgui/mhs_pause_social_media_bar.lua')
    AddCSLuaFile('esc-menu/vgui/mhs_pause_social_media_button.lua')
else
    include('esc-menu/cl_init.lua')
    include('esc-menu/vgui/mhs_pause_bar_button.lua')
    include('esc-menu/vgui/mhs_pause_leftbar.lua')
    include('esc-menu/vgui/mhs_pause_panel.lua')
    include('esc-menu/vgui/mhs_pause_scrollpanel.lua')
    include('esc-menu/vgui/mhs_pause_social_media_bar.lua')
    include('esc-menu/vgui/mhs_pause_social_media_button.lua')

    if CLIENT then
        escMenu.cfg.leftBarItems.top = {
            {
                title = 'Продолжить',
                desc = 'Закрыть меню',
                icon = Material('icon16/arrow_left.png'),
                onClick = function()
                    escMenu.close()
                end
            },
            {
                title = 'Стандартное меню',
                desc = 'Открыть стандартное меню',
                icon = Material('icon16/application_form.png'),
                onClick = function()
                    escMenu.close()
                    escMenu._shouldIgnoreHook = true
                    gui.ActivateGameUI()
                end
            },
        }

        escMenu.cfg.leftBarItems.bottom = {
            {
                title = 'Выйти с сервера',
                desc = 'Отключиться от сервера',
                icon = Material('icon16/disconnect.png'),
                onClick = function()
                    RunConsoleCommand('disconnect')
                end
            },
        }
    end
end