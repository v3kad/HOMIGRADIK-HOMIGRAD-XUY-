-- "addons\\esc-menu\\lua\\esc-menu\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
escMenu.Opened = false

function escMenu.open()
	if escMenu.isOpened() then return end
	escMenu.Opened = true

	if IsValid(escMenu._mainPanel) then escMenu._mainPanel:Remove() end
	escMenu._mainPanel = vgui.Create('mhs.pausePanel')
end

function escMenu.close()
	if not escMenu.isOpened() then return end
	escMenu.Opened = false
	if IsValid(escMenu._mainPanel) then escMenu._mainPanel:Remove() end
end

function escMenu.isOpened()
	return escMenu.Opened
end

function escMenu.toggle()
	if escMenu.isOpened() then
		escMenu.close()
	else
		escMenu.open()
	end
end

hook.Add('OnPauseMenuShow', 'esc-menu', function()
	if escMenu._shouldIgnoreHook then return end
	escMenu.toggle()
	return false
end)

hook.Add('Think', 'escMenu', function()
	if escMenu._shouldIgnoreHook then escMenu._shouldIgnoreHook = nil end
end)