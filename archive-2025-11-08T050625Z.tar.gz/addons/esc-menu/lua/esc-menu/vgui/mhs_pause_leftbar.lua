-- "addons\\esc-menu\\lua\\esc-menu\\vgui\\mhs_pause_leftbar.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local PANEL = {}

local color_bg = Color(0, 0, 0, 0)

function PANEL:Init()
	self.logo = self:Add('DHTML')
	local logo = self.logo
	logo:SetHTML([[
		<img src="]]..escMenu.cfg.logoUrl..[[" style="width: 100%; height: 100%" />
	]])

	self.top = self:Add('mhs.pausePanel.scrollPanel')
	local top = self.top
	top:SetDock(TOP)
	top:DockPadding(16, 16, 16, 16)

	self.bottom = self:Add('mhs.pausePanel.scrollPanel')
	local bottom = self.bottom
	bottom:SetDock(BOTTOM)
	bottom:DockPadding(16, 16, 16, 16)

	local topOptions = escMenu.cfg and escMenu.cfg.leftBarItems and escMenu.cfg.leftBarItems.top or {}
	local bottomOptions = escMenu.cfg and escMenu.cfg.leftBarItems and escMenu.cfg.leftBarItems.bottom or {}
	for _, option in ipairs(topOptions) do
		local btn = top:Add('mhs.pausePanel.barButton')
		btn:SetOption(option)
		btn:SetTall(32)
		btn:DockMargin(8, 8, 8, 8)
	end
	for _, option in ipairs(bottomOptions) do
		local btn = bottom:Add('mhs.pausePanel.barButton')
		btn:SetOption(option)
		btn:SetTall(32)
		btn:DockMargin(8, 8, 8, 8)
	end
end

function PANEL:PerformLayout(w, h)
	local top = self.top
	local bottom = self.bottom
	local logo = self.logo

	local offset = 0
	if IsValid(logo) then
		logo:SetSize(w, w / 4)
		logo:SetPos(w / 2 - logo:GetWide() / 2, 16)
		offset = logo:GetTall() + 16
	end

	if IsValid(top) then
		top:SetPos(0, offset)
		top:SetSize(w, h / 2 - offset)
	end

	if IsValid(bottom) then
		bottom:SetPos(0, h / 2)
		bottom:SetSize(w, h / 2)
	end
end

function PANEL:Paint(w, h)
	draw.RoundedBox(16, 0, 0, w, h, color_bg)
end

vgui.Register('mhs.pausePanel.leftBar', PANEL, 'DPanel')