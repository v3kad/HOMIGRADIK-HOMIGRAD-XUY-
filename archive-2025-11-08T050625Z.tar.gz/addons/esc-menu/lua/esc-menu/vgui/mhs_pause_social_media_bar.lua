-- "addons\\esc-menu\\lua\\esc-menu\\vgui\\mhs_pause_social_media_bar.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local PANEL = {}

local color_bg = Color(6, 47, 29, 230)

function PANEL:Init() end

function PANEL:AddMedia(iconUrl, tooltip, url, wide)
	local btn = self:Add('mhs.pausePanel.socialMediaButton')
	btn:SetImageURL(iconUrl)
	btn:SetURL(url)
	btn:SetTooltip(tooltip)
	btn:SetWide(wide or 64)
end

function PANEL:SetGap(gap)
	self.gap = gap
end

function PANEL:GetGap()
	return self.gap or 8
end

function PANEL:PerformLayout(w, h)
	local lp, tp, rp, bp = self:GetDockPadding()
	local children = self:GetChildren()
	local offset = 0
	local sumSize = 0
	for k, item in ipairs(children) do
		item:SetSize(item:GetWide(), h - tp - bp)
		item:SetPos(w - item:GetWide() - rp - offset, h / 2 - item:GetTall() / 2)

		local gap = self:GetGap()
		offset = offset + item:GetWide() + gap

		sumSize = sumSize + item:GetWide()
		if next(children, k) then sumSize = sumSize + gap end
	end
	self.sumSize = sumSize
end

function PANEL:Paint(w, h)
	local sumSize = self.sumSize or w
	draw.RoundedBox(16, w - sumSize, 0, sumSize, h, color_bg)
end

vgui.Register('mhs.pausePanel.socialMediaBar', PANEL, 'DPanel')