-- "addons\\esc-menu\\lua\\esc-menu\\vgui\\mhs_pause_social_media_button.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local PANEL = {}

local animFactor = 0.1
local hoverScale = 1.25

function PANEL:Paint() end

function PANEL:Init()
	self:SetText('')

	self.img = self:Add('DHTML')
	local img = self.img
	img:SetMouseInputEnabled(false)
	img:SetKeyboardInputEnabled(false)

	img.Think = function()
		local w, h = self:GetSize()

		self.lerpScale = self.lerpScale or 1

		if self:IsHovered() then
			self.lerpScale = Lerp(animFactor, self.lerpScale, hoverScale)
		else
			self.lerpScale = Lerp(animFactor, self.lerpScale, 1)
		end

		local scale = self.lerpScale
		local newW, newH = w * scale, h * scale

		img:SetPos(w / 2 - newW / 2, h / 2 - newH / 2)
		img:SetSize(newW, newH)
	end
end

function PANEL:SetImageURL(url)
	local img = self.img
	if not IsValid(img) then return end
	self.img:SetHTML([[
		<img src="]]..url..[[" style="width: 100%; height: 100%" />
	]])
end

function PANEL:SetURL(url)
	self.url = url
end

function PANEL:DoClick()
	gui.OpenURL(self.url or 'https://mohostan.ru')
end

vgui.Register('mhs.pausePanel.socialMediaButton', PANEL, 'DButton')