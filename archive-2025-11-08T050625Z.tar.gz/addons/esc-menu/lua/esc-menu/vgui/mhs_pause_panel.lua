-- "addons\\esc-menu\\lua\\esc-menu\\vgui\\mhs_pause_panel.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local PANEL = {}

local matKaneki = Material('homigrad/ui/kaneki3.png', 'smooth')

local lastFooterWeight
local function EnsureFooterFont()
	local weight = (escMenu and escMenu.cfg and escMenu.cfg.footerFontWeight) or 800
	if lastFooterWeight == weight then return end
	lastFooterWeight = weight
	surface.CreateFont('mhs.pauseFooter', {
		font = 'HudDefault',
		size = 22,
		weight = weight,
		extended = true,
	})
end

function PANEL:Init()
	local sw, sh = ScrW(), ScrH()

	EnsureFooterFont()

	self:MakePopup()
	self:SetSize(sw, sh)

	local leftBar = self:Add('mhs.pausePanel.leftBar')
	leftBar:SetSize(sw / 4, sh - 64)
	leftBar:SetPos(32, 32)

	local socialMediaBar = self:Add('mhs.pausePanel.socialMediaBar')
	socialMediaBar:SetSize(sw - leftBar:GetWide() - leftBar:GetX() - 64, 64)
	socialMediaBar:SetPos(sw - socialMediaBar:GetWide() - 32, 32)

	for _, v in ipairs(escMenu.cfg.socialMedia) do
		socialMediaBar:AddMedia(v.icon, v.tooltip, v.url, 64)
	end
end

function PANEL:Paint(w, h)
	-- global dim overlay
	EnsureFooterFont()
	draw.RoundedBox(0, 0, 0, w, h, Color(0, 0, 0, 200))
	if matKaneki and not matKaneki:IsError() then
		surface.SetDrawColor(255, 255, 255, 255)
		surface.SetMaterial(matKaneki)
		local imgH = math.min(256, math.floor(h * 0.30))
		local imgW = math.min(math.floor(imgH * 1.8), math.floor(w * 0.6))
		surface.DrawTexturedRect(w - imgW - 16, h - imgH - 16, imgW, imgH)
	end
  
	local footer = "HOMIGRAD XUY v2.6 by coldat10 and Vekad"
	draw.Text({
		font = 'mhs.pauseFooter',
		text = footer,
		pos = {w / 2 + 720, h - 18},
		xalign = TEXT_ALIGN_CENTER,
		yalign = TEXT_ALIGN_CENTER,
		color = color_white,
	})
end

vgui.Register('mhs.pausePanel', PANEL, 'DPanel')