-- "addons\\esc-menu\\lua\\esc-menu\\vgui\\mhs_pause_bar_button.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local PANEL = {}

local color_shadow = Color(65, 65, 65)
local color_bg = Color(217, 217, 217)
local color_text = Color(0, 0, 0)

local animFactor = 0.1
local hoverScale = 0.7

surface.CreateFont('mhs.pauseBarButton', {
	font = 'Montserrat Bold',
	size = 24,
	extended = true,
})

function PANEL:Init()
	self:SetText('')
end

function PANEL:SetOption(option)
	self.option = option
	self.DoClick = option.onClick
	self:SetTooltip(option.desc)
end

function PANEL:Paint(w, h)
	draw.RoundedBox(16, 0, 0, w, h, color_shadow)

	self.lerpW = self.lerpW or w
	self.lerpH = self.lerpH or h

	if self:IsHovered() then
		local scaledW, scaledH = w * hoverScale, h * hoverScale
		local minDiff = math.min(w - scaledW, h - scaledH)
		local targetW, targetH = w - minDiff, h - minDiff

		self.lerpW, self.lerpH = Lerp(animFactor, self.lerpW, targetW), Lerp(animFactor, self.lerpH, targetH)
	else
		self.lerpW, self.lerpH = Lerp(animFactor, self.lerpW, w), Lerp(animFactor, self.lerpH, h)
	end

	local btnW, btnH = self.lerpW, self.lerpH
	draw.RoundedBox(16, w / 2 - btnW / 2, h / 2 - btnH / 2, btnW, btnH, color_bg)

	local option = self.option
	if not option then return end

	local iconSize = h - 16
	local offset = option.icon and iconSize or 0

	local tw = draw.Text({
		font = 'mhs.pauseBarButton',
		text = option.title,
		pos = {w / 2 + offset, h / 2},
		xalign = TEXT_ALIGN_CENTER,
		yalign = TEXT_ALIGN_CENTER,
		color = color_text,
	})

	if option.icon then
		local iconSize = h - 16

		surface.SetDrawColor(color_white)
		surface.SetMaterial(option.icon)
		surface.DrawTexturedRect(w / 2 - tw / 2 - iconSize, h / 2 - iconSize / 2, iconSize, iconSize)
	end
end

vgui.Register('mhs.pausePanel.barButton', PANEL, 'DButton')