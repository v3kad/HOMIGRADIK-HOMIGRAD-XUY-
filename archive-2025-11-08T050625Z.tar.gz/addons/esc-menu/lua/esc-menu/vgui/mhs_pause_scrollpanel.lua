-- "addons\\esc-menu\\lua\\esc-menu\\vgui\\mhs_pause_scrollpanel.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local PANEL = {}

function PANEL:Init() end
function PANEL:Paint() end

function PANEL:SetDock(dock)
	self.dock = dock
end

function PANEL:PerformLayout(w, h)
	local children = self:GetChildren()
	local lp, tp, rp, bp = self:GetDockPadding()

	local dock = self.dock or TOP
	local offset = (dock == TOP and tp) or (dock == BOTTOM and bp)
	for _, item in ipairs(children) do
		if dock == TOP then
			local lm, tm, rm, bm = item:GetDockMargin()

			item:SetSize(w - lp - rp - lm - rm, item:GetTall())
			item:SetPos(lp + lm, tm + offset)
			offset = offset + item:GetTall() + bm
		elseif dock == BOTTOM then
			local lm, tm, rm, bm = item:GetDockMargin()

			item:SetSize(w - lp - rp - lm - rm, item:GetTall())
			item:SetPos(lp + lm, h - item:GetTall() - bm - offset)
			offset = offset + item:GetTall() + tm
		end
	end
end

vgui.Register('mhs.pausePanel.scrollPanel', PANEL, 'DPanel')