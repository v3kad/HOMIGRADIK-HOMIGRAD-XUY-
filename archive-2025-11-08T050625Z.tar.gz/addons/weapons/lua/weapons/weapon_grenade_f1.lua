SWEP.Base = 'salat_base'

SWEP.PrintName = "F-1"
SWEP.Author = "Homigrad"
SWEP.Instructions = "Ручная граната F-1"
SWEP.Category = "Оружие: Гранаты"

SWEP.Spawnable = true
SWEP.AdminOnly = false

-- Primary (we use as single-use throw)
SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = -1
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "none"
SWEP.ShootWait = 0.5

-- No secondary
SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = "none"

-- Weapon handling
SWEP.Weight = 1
SWEP.AutoSwitchTo = false
SWEP.AutoSwitchFrom = false
SWEP.HoldType = "grenade"

-- Slot/visuals
SWEP.Slot = 4
SWEP.SlotPos = 0
SWEP.DrawAmmo = false
SWEP.DrawCrosshair = false

if CLIENT then
    SWEP.WepSelectIcon = surface.GetTextureID("pwb/sprites/f1")
    SWEP.BounceWeaponIcon = false
end

SWEP.Icon = "materials/grenade/weapon_grenade_f1_lod0_nrm.vtf"

-- Models
SWEP.ViewModel = "models/eft_grenades/grenade f-1.mdl"
SWEP.WorldModel = "models/eft_grenades/grenade f-1.mdl"

SWEP.VMOffsetPos = Vector(0, 0, 0)
SWEP.VMOffsetAng = Angle(0, 0, 0)
SWEP.WMOffsetPos = Vector(0, 0, 0)
SWEP.WMOffsetAng = Angle(0, 0, 0)

-- Explosion config
local FUSE_TIME = 3.5
local BLAST_RADIUS = 350
local BLAST_DAMAGE = 110
local EXPLOSION_PARTICLE = "pcf_jack_groundsplode_medium"

-- Shrapnel config
local SHRAPNEL_COUNT = 360
local SHRAPNEL_DAMAGE = 10
local SHRAPNEL_FORCE = 1
local SHRAPNEL_DISTANCE = 2500

if PrecacheParticleSystem then
    pcall(function()
        if game and game.AddParticles then game.AddParticles("particles/pcf_jack_groundsplode_medium.pcf") end
        PrecacheParticleSystem(EXPLOSION_PARTICLE)
    end)
end

if SERVER then
    util.AddNetworkString("f1_explode")
end

function SWEP:Initialize()
    self:SetHoldType(self.HoldType)
end

local function EmitShrapnel(srcEnt, pos, attacker)
    if not SERVER then return end
    local fireEnt = IsValid(srcEnt) and srcEnt or game.GetWorld()
    local atk = IsValid(attacker) and attacker or fireEnt
    for i = 1, SHRAPNEL_COUNT do
        local dir = VectorRand()
        dir:Normalize()

        local bullet = {}
        bullet.Num = 1
        bullet.Src = pos + dir * 2
        bullet.Dir = dir
        bullet.Spread = Vector(0, 0, 0)
        bullet.Tracer = 0
        bullet.Force = SHRAPNEL_FORCE
        bullet.Damage = SHRAPNEL_DAMAGE
        bullet.Distance = SHRAPNEL_DISTANCE
        bullet.HullSize = 3
        bullet.AmmoType = "SMG1"
        bullet.IgnoreEntity = srcEnt
        bullet.DamageType = DMG_BULLET

        bullet.Callback = function(att, tr, dmginfo)
            dmginfo:SetDamage(SHRAPNEL_DAMAGE)
            dmginfo:SetDamageType(DMG_BULLET)
            if IsValid(atk) then
                dmginfo:SetAttacker(atk)
            end
        end

        if IsValid(fireEnt) and fireEnt.FireBullets then
            fireEnt:FireBullets(bullet)
        end
    end
end

local function ExplodeGrenade(ent, owner)
    if not IsValid(ent) then return end
    local pos = ent:GetPos()

    -- Effect: broadcast to clients to play custom particle
    if SERVER then
        net.Start("f1_explode")
        net.WriteVector(pos)
        net.Broadcast()
    end

    -- Shrapnel damage instead of simple BlastDamage
    EmitShrapnel(ent, pos, IsValid(owner) and owner or ent)

    -- Guarantee some close-range self-damage for the thrower if very near the blast
    if IsValid(owner) and owner:IsPlayer() and owner:Alive() then
        local r = 120
        if owner:GetPos():DistToSqr(pos) <= r * r then
            local tr = util.TraceLine({
                start = pos,
                endpos = owner:WorldSpaceCenter(),
                filter = ent
            })
            if tr.Fraction > 0.9 or tr.Entity == owner then
                local di = DamageInfo()
                di:SetDamage(math.random(15, 30))
                di:SetDamageType(DMG_BULLET)
                di:SetAttacker(owner)
                di:SetInflictor(ent)
                di:SetDamageForce((owner:GetPos() - pos):GetNormalized() * 200)
                owner:TakeDamageInfo(di)
                -- Ensure adequate pain for the thrower beyond default bullet pain
                if owner.AddHGPain then
                    local pain = math.Clamp((di:GetDamage() or 20) * 0.9, 12, 35)
                    owner:AddHGPain(pain)
                end
            end
        end
    end

    -- Sound fallback
    sound.Play("BaseExplosionEffect.Sound", pos, 100, 100)

    -- Decal
    util.Decal("Scorch", pos + Vector(0,0,8), pos - Vector(0,0,16))

    -- Remove entity
    SafeRemoveEntity(ent)
end

function SWEP:PrimaryAttack()
    if not IsFirstTimePredicted() then return end
    if (self.NextShot or 0) > CurTime() then return end
    if timer.Exists("reload"..self:EntIndex()) then return end

    self.NextShot = CurTime() + (self.ShootWait or 0.5)

    if SERVER then
        local owner = self:GetOwner()
        if not IsValid(owner) then return end

        local src = owner:EyePos() + owner:GetAimVector() * 12 + owner:GetRight() * 3 + owner:GetUp() * -2
        local ang = owner:EyeAngles()
        local vel = owner:GetVelocity() + ang:Forward() * 900 + ang:Up() * 120

        local grenade = ents.Create("prop_physics")
        if not IsValid(grenade) then return end
        grenade:SetModel(self.WorldModel)
        grenade:SetPos(src)
        grenade:SetAngles(Angle(0, ang.y, 0))
        grenade:SetOwner(owner)
        grenade:Spawn()
        grenade:Activate()

        local phys = grenade:GetPhysicsObject()
        if IsValid(phys) then
            phys:SetVelocity(vel)
            phys:AddAngleVelocity(VectorRand() * 600)
        end

        grenade:SetCollisionGroup(COLLISION_GROUP_PROJECTILE)

        timer.Simple(FUSE_TIME, function()
            ExplodeGrenade(grenade, IsValid(owner) and owner or grenade)
        end)

        self:EmitSound("weapons/m67/handling/m67_throw.wav", 70, 100, 1, CHAN_AUTO)

        -- Remove weapon after throw (single-use)
        self:Remove()
    end
end

function SWEP:SecondaryAttack()
    -- no alternate throw for now
end

function SWEP:Deploy()
    self:SetHoldType(self.HoldType)
    self.NextShot = CurTime() + 0.3
    return true
end

function SWEP:ShouldDropOnDie()
    return false
end

function SWEP:DrawWorldModel()
    local owner = self:GetOwner()
    if not IsValid(owner) then
        self:DrawModel()
        return
    end

    local bone = owner:LookupBone("ValveBiped.Bip01_R_Hand")
    if not bone then return end

    local m = owner:GetBoneMatrix(bone)
    if not m then return end

    local pos, ang = m:GetTranslation(), m:GetAngles()
    ang:RotateAroundAxis(ang:Right(), self.WMOffsetAng.x)
    ang:RotateAroundAxis(ang:Forward(), self.WMOffsetAng.y)
    ang:RotateAroundAxis(ang:Up(), self.WMOffsetAng.z)

    pos = pos + ang:Right() * self.WMOffsetPos.x + ang:Forward() * self.WMOffsetPos.y + ang:Up() * self.WMOffsetPos.z

    self:SetRenderOrigin(pos)
    self:SetRenderAngles(ang)
    self:DrawModel()
end

if CLIENT then
    function SWEP:CalcViewModelView(vm, oldPos, oldAng, pos, ang)
        local p = pos + ang:Right() * self.VMOffsetPos.x + ang:Forward() * self.VMOffsetPos.y + ang:Up() * self.VMOffsetPos.z
        local a = Angle(ang)
        a:RotateAroundAxis(a:Right(), self.VMOffsetAng.x)
        a:RotateAroundAxis(a:Forward(), self.VMOffsetAng.y)
        a:RotateAroundAxis(a:Up(), self.VMOffsetAng.z)
        return p, a
    end

    net.Receive("f1_explode", function()
        local pos = net.ReadVector()
        if PrecacheParticleSystem then
            pcall(function()
                if game and game.AddParticles then game.AddParticles("particles/pcf_jack_groundsplode_medium.pcf") end
                PrecacheParticleSystem(EXPLOSION_PARTICLE)
            end)
        end
        ParticleEffect(EXPLOSION_PARTICLE, pos, Angle(0, 0, 0), nil)
    end)
end
