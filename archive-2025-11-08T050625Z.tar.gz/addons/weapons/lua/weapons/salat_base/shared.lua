skins = {
    megapenis = true,
    meagsponsor = true,
    donator = true,
    superadmin = true,
    microdonater = true,
    admin = true
}
local vecZero = Vector(0,0,0)
local angZero = Angle(0,0,0)
SWEP.Base = 'weapon_base'

SWEP.PrintName = "salat_base"
SWEP.Author = "Homigrad"
SWEP.Instructions = ""
SWEP.Category = "Other"
-- WepSelectIcon должен быть числом (ID текстуры) или nil для использования стандартной иконки
-- Используем nil, чтобы базовый класс использовал стандартную обработку
SWEP.WepSelectIcon = nil

SWEP.Spawnable = false
SWEP.AdminOnly = false

SWEP.Primary.ClipSize = 50
SWEP.Primary.DefaultClip = 0
SWEP.Primary.Automatic = true
SWEP.Primary.Ammo = "pistol"
SWEP.Primary.Cone = 0
SWEP.Primary.Damage = 100
SWEP.Primary.Spread = 0
SWEP.Primary.Sound = "weapons/fiveseven/fiveseven-1.wav"
SWEP.Primary.SoundFar = "m9/m9_dist.wav"
SWEP.Primary.Force = 0
SWEP.ReloadTime = 2
SWEP.ShootWait = 0.12
SWEP.NextShot = 0
SWEP.Sight = false
SWEP.ReloadSound = ""
SWEP.TwoHands = false

SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = "none"

SWEP.CSMuzzleFlashes = true

SWEP.Weight = 5
SWEP.AutoSwitchTo = false
SWEP.AutoSwitchFrom = false

SWEP.HoldType = ""
SWEP.revolver = false
SWEP.shotgun = false

-- Используем стандартную функцию выбора оружия из базового класса
-- SWEP.DrawWeaponSelection будет наследоваться от weapon_base автоматически
SWEP.vbw = true
SWEP.vbwPos = false
SWEP.vbwAng = false
SWEP.Suppressed = false

SWEP.Recoil = 1
SWEP.RecoilVertical = 1.5
SWEP.RecoilHorizontal = 0.5

SWEP.RecoilPos = Vector(0, 0, 0)
SWEP.RecoilAng = Angle(0, 0, 0)
SWEP.RecoilKick = Vector(0, 0, 0)
SWEP.RecoilKickAng = Angle(0, 0, 0)
SWEP.RecoilAccumulation = 0
SWEP.LastRecoilTime = 0

SWEP.DebugMuzzle = false

local hg_skins = CreateClientConVar("hg_skins","1",true,false,"ubrat govno",0,1)

local hg_debug_muzzle = CreateClientConVar("hg_debug_muzzle","0",true,false,"Debug muzzle position",0,1)

function SWEP:DrawWorldModel()
    self:DrawModel()
    
    if not hg_skins:GetBool() then return end

    if IsValid(self:GetOwner()) and self:GetOwner():IsPlayer() and skins[self:GetOwner():GetUserGroup()] then
        self:DrawModel()
    end
end

HMCD_SurfaceHardness = {
    [MAT_METAL]=.95,[MAT_COMPUTER]=.95,[MAT_VENT]=.95,[MAT_GRATE]=.95,[MAT_FLESH]=.5,[MAT_ALIENFLESH]=.3,
    [MAT_SAND]=.1,[MAT_DIRT]=.3,[74]=.1,[85]=.2,[MAT_WOOD]=.5,[MAT_FOLIAGE]=.5,
    [MAT_CONCRETE]=.9,[MAT_TILE]=.8,[MAT_SLOSH]=.05,[MAT_PLASTIC]=.3,[MAT_GLASS]=.6
}

function SWEP:BulletCallbackFunc(dmgAmt,ply,tr,dmg,tracer,hard,multi)
    if tr.MatType == MAT_FLESH then
        util.Decal("Impact.Flesh",tr.HitPos+tr.HitNormal,tr.HitPos-tr.HitNormal)
    end
    if (self.NumBullet or 1) > 1 then return end
    if tr.HitSky then return end
    if hard then self:RicochetOrPenetrate(tr) end
end

function SWEP:RicochetOrPenetrate(initialTrace)
    local AVec, IPos, TNorm, SMul = initialTrace.Normal, initialTrace.HitPos, initialTrace.HitNormal, HMCD_SurfaceHardness[initialTrace.MatType]
    if not SMul then SMul = .5 end
    local ApproachAngle = -math.deg(math.asin(TNorm:DotProduct(AVec)))
    local MaxRicAngle = 60 * SMul
    
    if ApproachAngle > (MaxRicAngle * 1.25) then
        local MaxDist, SearchPos, SearchDist, Penetrated = (self.Primary.Damage/SMul)*.15, IPos, 5, false
        while not Penetrated and SearchDist < MaxDist do
            SearchPos = IPos + AVec * SearchDist
            local PeneTrace = util.QuickTrace(SearchPos, -AVec * SearchDist)
            if not PeneTrace.StartSolid and PeneTrace.Hit then
                Penetrated = true
            else
                SearchDist = SearchDist + 5
            end
        end
        if Penetrated then
            self:FireBullets({
                Attacker = self:GetOwner(),
                Damage = 1,
                Force = 1,
                Num = 1,
                Tracer = 0,
                Dir = -AVec,
                Spread = Vector(0,0,0),
                Src = SearchPos + AVec
            })
            self:FireBullets({
                Attacker = self:GetOwner(),
                Damage = self.Primary.Damage * .65,
                Force = self.Primary.Damage / 15,
                Num = 1,
                Tracer = 0,
                Dir = AVec,
                Spread = Vector(0,0,0),
                Src = SearchPos + AVec
            })
        end
    elseif ApproachAngle < (MaxRicAngle * .25) then
        sound.Play("snd_jack_hmcd_ricochet_"..math.random(1,2)..".wav", IPos, 70, math.random(90,100))
        local NewVec = AVec:Angle()
        NewVec:RotateAroundAxis(TNorm, 180)
        NewVec = NewVec:Forward()
        self:FireBullets({
            Attacker = self:GetOwner(),
            Damage = self.Primary.Damage * .85,
            Force = self.Primary.Damage / 15,
            Num = 1,
            Tracer = 0,
            Dir = -NewVec,
            Spread = Vector(0,0,0),
            Src = IPos + TNorm
        })
    end
end

homigrad_weapons = homigrad_weapons or {}

function SWEP:Initialize()
    homigrad_weapons[self] = true
    self.lerpClose = 0
    
    self.RecoilPos = Vector(0, 0, 0)
    self.RecoilAng = Angle(0, 0, 0)
    self.RecoilKick = Vector(0, 0, 0)
    self.RecoilKickAng = Angle(0, 0, 0)
    self.RecoilAccumulation = 0
    self.LastRecoilTime = 0

    self.DebugMuzzle = hg_debug_muzzle:GetBool()
    
    if CLIENT then
        cvars.AddChangeCallback("hg_debug_muzzle", function(_, _, new)
            self.DebugMuzzle = tobool(new)
        end)
    end
end

function SWEP:PrePrimaryAttack()
end

function SWEP:CanFireBullet()
    return true
end

if SERVER then
    util.AddNetworkString("huysound")
end

if CLIENT then
    net.Receive("huysound", function(len)
        local pos = net.ReadVector()
        local sound = net.ReadString()
        local farsound = net.ReadString() or "m9/m9_dist.wav"
        local ent = net.ReadEntity()

        if ent == LocalPlayer() then return end

        local dist = LocalPlayer():EyePos():Distance(pos)
        if ent:IsValid() and dist < 1575 then
            ent:EmitSound(sound, ent.Supressed and 35 or 125, math.random(100,120), 1, CHAN_WEAPON, 0, 0)
        elseif ent:IsValid() then
            ent:EmitSound(farsound, ent.Supressed and 35 or 125, math.random(100,120), 1, CHAN_WEAPON, 0, 0)
        end
    end)
end

function SWEP:ApplyRecoil()
    if not IsFirstTimePredicted() then return end
    
    local ply = self:GetOwner()
    if not IsValid(ply) then return end
    
    local baseRecoil = (self.Primary.Damage or 30) / 25  
    local verticalRecoil = baseRecoil * (self.RecoilVertical or 1.5)
    local horizontalRecoil = baseRecoil * (self.RecoilHorizontal or 0.5)
    
    local timeSinceLastShot = CurTime() - (self.LastRecoilTime or 0)
    if timeSinceLastShot < 0.3 then
        self.RecoilAccumulation = (self.RecoilAccumulation or 0) + 0.15
    else
        self.RecoilAccumulation = 0
    end
    
    local accumMultiplier = 1 + (self.RecoilAccumulation or 0)

    local randomVert = math.Rand(0.8, 1.2)
    local randomHoriz = math.Rand(-1.0, 1.0)

    local finalVert = verticalRecoil * randomVert * accumMultiplier
    local finalHoriz = horizontalRecoil * randomHoriz * accumMultiplier

    self.RecoilKick = Vector(
        math.Rand(-0.1, 0.1) * finalVert,
        -finalVert * 0.5, 
        math.Rand(-0.05, 0.05) * finalVert
    )
    
    self.RecoilKickAng = Angle(
        -finalVert * 3.0, 
        finalHoriz * 2.0,  
        math.Rand(-1, 1) * finalVert * 0.5 
    )
    
    self.RecoilAng = self.RecoilAng + Angle(-finalVert * 0.3, finalHoriz * 0.2, 0)
    self.RecoilPos = self.RecoilPos + Vector(0, -finalVert * 0.1, 0)
    
    self.LastRecoilTime = CurTime()

    if self:IsLocal() then
        local eyeAngles = ply:EyeAngles()
        eyeAngles.p = eyeAngles.p - finalVert * 0.8 
        eyeAngles.y = eyeAngles.y + finalHoriz * 0.6 
        ply:SetEyeAngles(eyeAngles)
    end
end

function SWEP:UpdateRecoil()
    local frameTime = FrameTime()
    
    local kickDecay = frameTime * 8
    self.RecoilKick = LerpVector(kickDecay, self.RecoilKick, Vector(0, 0, 0))
    self.RecoilKickAng = LerpAngle(kickDecay, self.RecoilKickAng, Angle(0, 0, 0))
    
    local smoothDecay = frameTime * 3
    self.RecoilPos = LerpVector(smoothDecay, self.RecoilPos, Vector(0, 0, 0))
    self.RecoilAng = LerpAngle(smoothDecay, self.RecoilAng, Angle(0, 0, 0))
end

function SWEP:PrimaryAttack()
    if not IsFirstTimePredicted() then return end
    
    if (self.NextShot or 0) > CurTime() then return end 
    if timer.Exists("reload"..self:EntIndex()) then return end

    local canfire = self:CanFireBullet()
    
    if self:Clip1() <= 0 or (not canfire and (self.NextShot or 0) < CurTime()) then
        if SERVER then
            sound.Play("snd_jack_hmcd_click.wav", self:GetPos(), 65, 100)
        end
        self.NextShot = CurTime() + (self.ShootWait or 0.12)
        return
    end

    self:PrePrimaryAttack()

    if self.isClose or (not self:GetOwner():IsNPC() and self:GetOwner():IsSprinting()) then return end

    local ply = self:GetOwner()
    self.NextShot = CurTime() + (self.ShootWait or 0.12)

    self:ApplyRecoil()

    if SERVER then
        net.Start("huysound")
        net.WriteVector(self:GetPos())
        net.WriteString(self.Primary.Sound or "")
        net.WriteString(self.Primary.SoundFar or "m9/m9_dist.wav")
        net.WriteEntity(ply)
        net.Broadcast()
        
        self:FireBullet(dmg, 1, 5)
    else
        if ply == LocalPlayer() then
            self:EmitSound(self.Primary.Sound or "", 511, math.random(100,120), 1, CHAN_VOICE_BASE, 0, 0)
        end
    end
    
    if CLIENT and self:GetOwner() != LocalPlayer() then
        self:GetOwner():SetAnimation(PLAYER_ATTACK1)
    end
    
    self.lastShoot = CurTime()
    self:SetNWFloat("LastShoot", CurTime())
end

function SWEP:Reload()
    if not self:GetOwner():KeyDown(IN_WALK) then
        if timer.Exists("reload"..self:EntIndex()) or self:Clip1() >= self:GetMaxClip1() or self:GetOwner():GetAmmoCount(self:GetPrimaryAmmoType()) <= 0 then return nil end
        if self:GetOwner():IsSprinting() then return nil end
        if self.NextShot > CurTime() then return end
        
        self:GetOwner():SetAnimation(PLAYER_RELOAD)
        self:EmitSound(self.ReloadSound, 60, 100, 0.8, CHAN_AUTO)
        
        timer.Create("reload"..self:EntIndex(), self.ReloadTime, 1, function()
            if IsValid(self) and IsValid(self:GetOwner()) and self:GetOwner():GetActiveWeapon() == self then
                local oldclip = self:Clip1()
                self:SetClip1(math.Clamp(self:Clip1() + self:GetOwner():GetAmmoCount(self:GetPrimaryAmmoType()), 0, self:GetMaxClip1()))
                local needed = self:Clip1() - oldclip
                self:GetOwner():SetAmmo(self:GetOwner():GetAmmoCount(self:GetPrimaryAmmoType()) - needed, self:GetPrimaryAmmoType())
            end
        end)
    end
end

SWEP.addPos = Vector(0,0,0)
SWEP.addAng = Angle(0,0,0)

if SERVER then
    util.AddNetworkString("shoot_huy")
else
    net.Receive("shoot_huy", function(len)
        local tr = net.ReadTable()
        local dist, vec, dist2 = util.DistanceToLine(tr.StartPos, tr.HitPos, EyePos())
        if dist < 128 and dist2 > 128 then
            EmitSound("snd_jack_hmcd_bc_"..tostring(math.random(1,7))..".wav", vec, 1, CHAN_WEAPON, 1, 75, 0, 100)
        end
    end)
end

function SWEP:FireBullet(dmg, numbul, spread)
    if self:Clip1() <= 0 then return end
    if timer.Exists("reload"..self:EntIndex()) then return nil end
    
    local ply = self:GetOwner()
    if not IsValid(ply) then return end

    ply:LagCompensation(true)

    local shootOrigin, shootAngles
    
    local muzzleAtt = self:LookupAttachment("muzzle")
    if muzzleAtt and muzzleAtt > 0 then
        local muzzleData = self:GetAttachment(muzzleAtt)
        if muzzleData then
            shootOrigin = muzzleData.Pos
            shootAngles = muzzleData.Ang

            if CLIENT and self.DebugMuzzle then
                debugoverlay.Sphere(shootOrigin, 3, 5, Color(255, 0, 0), true)
                debugoverlay.Line(shootOrigin, shootOrigin + shootAngles:Forward() * 100, 5, Color(255, 0, 255), true)
                debugoverlay.EntityTextAtPosition(shootOrigin, 0, "MUZZLE POSITION", 5, Color(255, 0, 0))
                debugoverlay.EntityTextAtPosition(shootOrigin, 1, string.format("X: %.1f Y: %.1f Z: %.1f", shootOrigin.x, shootOrigin.y, shootOrigin.z), 5, Color(255, 255, 0))
            end
        end
    end

    if not shootOrigin then
        shootOrigin = ply:GetShootPos()
        shootAngles = ply:EyeAngles()
        
        if CLIENT and self.DebugMuzzle then
            debugoverlay.Sphere(shootOrigin, 3, 5, Color(0, 255, 0), true)
            debugoverlay.EntityTextAtPosition(shootOrigin, 0, "FALLBACK POSITION", 5, Color(0, 255, 0))
        end
    end

    local vec = Vector(0,0,0)
    vec:Set(self.addPos or Vector(0,0,0))
    vec:Rotate(shootAngles)
    shootOrigin:Add(vec)

    local ang = Angle(0,0,0)
    ang:Set(self.addAng or Angle(0,0,0))
    shootAngles:Add(ang)

    local shootDir = shootAngles:Forward()
   
    local bullet = {
        Num = self.NumBullet or 1,
        Src = shootOrigin,
        Dir = shootDir, 
        Spread = Vector(self.Primary.Cone or 0.01, self.Primary.Cone or 0.01, 0),
        Tracer = 1,
        TracerName = self.Tracer or "Tracer",
        TracerCount = 1,
        Force = (self.Primary.Force or 0) / 40,
        Damage = dmg or (self.Primary.Damage or 30),
        AmmoType = self.Primary.Ammo or "pistol",
        Attacker = ply,
        IgnoreEntity = ply
    }

    local weapon = self
    bullet.Callback = function(attacker, tr, dmginfo)
        if IsValid(weapon) then
            weapon:BulletCallbackFunc(dmg or 30, attacker, tr, dmginfo, false, true, false)
        end

        if weapon.Primary.Ammo == "buckshot" then
            local k = math.max(1 - tr.StartPos:Distance(tr.HitPos) / 750, 0)
            dmginfo:ScaleDamage(k)
        end

        local effectdata = EffectData()
        effectdata:SetOrigin(tr.HitPos)
        effectdata:SetNormal(tr.HitNormal)
        effectdata:SetScale(1)
        util.Effect("Impact", effectdata)
        
        if SERVER then
            net.Start("shoot_huy")
            net.WriteTable(tr)
            net.Broadcast()
        end
    end

    if SERVER then 
        self:TakePrimaryAmmo(1) 
    end

    ply:FireBullets(bullet)
    ply:LagCompensation(false)

    if CLIENT then
        local effectdata = EffectData()
        effectdata:SetOrigin(shootOrigin)
        effectdata:SetNormal(shootDir)
        effectdata:SetAngles(shootAngles)
        effectdata:SetScale(1)
        effectdata:SetEntity(self)
        util.Effect("MuzzleEffect", effectdata)
    end

    if ply:IsNPC() then
        self:SendWeaponAnim(ACT_VM_PRIMARYATTACK)
    end

    return true
end

local mul = 1
local FrameTime, TickInterval = FrameTime, engine.TickInterval

hook.Add("Think", "Mul lerp", function()
    mul = FrameTime() / TickInterval()
end)

local Lerp, LerpVector, LerpAngle = Lerp, LerpVector, LerpAngle
local math_min = math.min

function LerpFT(lerp, source, set)
    return Lerp(math_min(lerp * mul, 1), source, set)
end

function LerpVectorFT(lerp, source, set)
    return LerpVector(math_min(lerp * mul, 1), source, set)
end

function LerpAngleFT(lerp, source, set)
    return LerpAngle(math_min(lerp * mul, 1), source, set)
end

local pairs, IsValid = pairs, IsValid

hook.Add("Think", "weapons-sadsalat", function()
    for wep in pairs(homigrad_weapons) do
        if not IsValid(wep) then 
            homigrad_weapons[wep] = nil 
            continue 
        end

        local owner = wep:GetOwner()
        if not IsValid(owner) or (owner:IsPlayer() and not owner:Alive()) or owner:GetActiveWeapon() ~= wep then 
            continue 
        end

        if wep.Step then wep:Step() end
        if wep.UpdateRecoil then wep:UpdateRecoil() end
    end
end)

function SWEP:Think()
    self:UpdateRecoil()
    
    if CLIENT then
        self.DebugMuzzle = hg_debug_muzzle:GetBool()
    end
end

local timer_Exists = timer.Exists

function SWEP:IsLocal()
    return CLIENT and self:GetOwner() == LocalPlayer()
end

function SWEP:IsReloaded()
    return timer_Exists("reload"..self:EntIndex())
end

function SWEP:IsScope()
    local ply = self:GetOwner()
    if ply:IsNPC() then return end

    if self:IsLocal() or SERVER then
        return not ply:IsSprinting() and ply:KeyDown(IN_ATTACK2) and not self:IsReloaded()
    else
        return self:GetNWBool("IsScope")
    end
end

if SERVER then
    concommand.Add("suicide", function(ply)
        if not ply:Alive() then return end
        ply.suiciding = not ply.suiciding
        ply:SetNWBool("Suiciding", ply.suiciding)
    end)
end

hook.Add("PlayerDeath", "suciding", function(ply)
    ply.suiciding = false
    ply:SetNWBool("Suiciding", false)
end)

local util_QuickTrace = util.QuickTrace
local math_Clamp = math.Clamp
local closeAng = Angle(0,0,0)

local angZero = Angle(0,0,0)
local angSuicide = Angle(160,30,90)
local angSuicide2 = Angle(160,30,90)
local angSuicide3 = Angle(60,-30,90)
local forearm, clavicle, hand = Angle(0,0,0), Angle(0,0,0), Angle(0,0,0)

local runArmAngles = Angle(60, 0, 0)


function SWEP:Step()
    local ply = self:GetOwner()
    local isLocal = self:IsLocal()

    if not IsValid(ply) or ply:IsNPC() or IsValid(ply:GetNWEntity("Ragdoll")) then return end

    local t = {}
    if not self.TwoHands then
        t.start = ply:GetShootPos() + ply:GetAngles():Right() * 2.5
    else
        t.start = ply:GetShootPos() + ply:GetAngles():Right() * 7
    end

    t.endpos = t.start + Angle(0, ply:GetAngles().y, ply:GetAngles().z):Forward() * 100
    t.filter = player.GetAll()
    local tr = util.TraceLine(t)
    self.dist = (tr.HitPos - t.start):Length()

    forearm:Set(angZero)
    clavicle:Set(angZero)
    hand:Set(angZero)

    if not ply:IsSprinting() then
        local scope = self:IsScope()
        if SERVER then self:SetNWBool("IsScope", scope) end

        if isLocal or SERVER then
            local head = ply:LookupBone("ValveBiped.Bip01_L_Hand")
            if head then
                local pos, ang = ply:GetBonePosition(head)
                pos[3] = pos[3] + 5
                ang:RotateAroundAxis(ang:Up(), -90)

                local dir = ang:Forward() * 1000
                local tr = util_QuickTrace(pos, dir, ply)
                self.isClose = self.dist <= 35 and not self:IsReloaded()
                
                if SERVER then self:SetNWBool("isClose", self.isClose) end
            end
        else
            self.isClose = self:GetNWBool("isClose")
        end
        
        if not self.isClose and not ply:IsSprinting() then
            if not ply:GetNWBool("Suiciding") then
                self:SetWeaponHoldType(self.HoldType)
            elseif not self.TwoHands and ply:GetNWBool("Suiciding") then
                self:SetWeaponHoldType("normal")
                forearm:Set(angSuicide2)
                hand:Set(angSuicide3)
            elseif ply:GetNWBool("Suiciding") then
                self:SetWeaponHoldType("normal")
                hand:Set(angSuicide)
            end
        end
    else
        self.isClose = true
        if not self.TwoHands then
            self:SetWeaponHoldType("normal")
        else
            self:SetWeaponHoldType("passive")
        end
    end
    
    self.lerpClose = LerpFT(0.1, self.lerpClose, self.isClose and 1 or 0)

    if not ply:LookupBone("ValveBiped.Bip01_R_Forearm") then return end

    ply:ManipulateBoneAngles(ply:LookupBone("ValveBiped.Bip01_R_Forearm"), forearm, false)
    ply:ManipulateBoneAngles(ply:LookupBone("ValveBiped.Bip01_R_Clavicle"), clavicle, false)
    ply:ManipulateBoneAngles(ply:LookupBone("ValveBiped.Bip01_R_Hand"), hand, false)
end

function SWEP:Holster(wep)
    local ply = self:GetOwner()
    if not ply:LookupBone("ValveBiped.Bip01_R_Forearm") then return end

    ply:ManipulateBoneAngles(ply:LookupBone("ValveBiped.Bip01_R_Hand"), Angle(0,0,0))
    ply:ManipulateBoneAngles(ply:LookupBone("ValveBiped.Bip01_R_Forearm"), Angle(0,0,0))
    ply:ManipulateBoneAngles(ply:LookupBone("ValveBiped.Bip01_R_Clavicle"), Angle(0,0,0))

    self.RecoilPos = Vector(0, 0, 0)
    self.RecoilAng = Angle(0, 0, 0)
    self.RecoilKick = Vector(0, 0, 0)
    self.RecoilKickAng = Angle(0, 0, 0)
    self.RecoilAccumulation = 0

    return true
end

hook.Add("PlayerDeath", "weapons", function(ply)
    ply:ManipulateBoneAngles(ply:LookupBone("ValveBiped.Bip01_R_Forearm"), angZero, false)
    ply:ManipulateBoneAngles(ply:LookupBone("ValveBiped.Bip01_R_Clavicle"), angZero, false)
    ply:ManipulateBoneAngles(ply:LookupBone("ValveBiped.Bip01_R_Hand"), angZero, false)
end)

function SWEP:SecondaryAttack() 
    return 
end

function SWEP:Deploy()
    self:SetHoldType("normal")
    if SERVER then
        self:GetOwner():EmitSound("snd_jack_hmcd_pistoldraw.wav", 65, self.TwoHands and 100 or 110, 1, CHAN_AUTO)
    end

    self.NextShot = CurTime() + 0.5
    self:SetHoldType(self.HoldType) 
    
    self.RecoilPos = Vector(0, 0, 0)
    self.RecoilAng = Angle(0, 0, 0)
    self.RecoilKick = Vector(0, 0, 0)
    self.RecoilKickAng = Angle(0, 0, 0)
    self.RecoilAccumulation = 0
    self.LastRecoilTime = 0
end

function SWEP:ShouldDropOnDie()
    return false
end