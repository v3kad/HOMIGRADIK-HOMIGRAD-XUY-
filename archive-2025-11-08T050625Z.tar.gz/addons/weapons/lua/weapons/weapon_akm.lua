SWEP.Base = 'salat_base'

SWEP.PrintName = "АКМ"
SWEP.Author = "Homigrad"
SWEP.Instructions = "Автоматическая винтовка под калибр 7,62х39"
SWEP.Category = "Оружие: Винтовки"

SWEP.Spawnable = true
SWEP.AdminOnly = false

------------------------------------------

SWEP.Primary.ClipSize = 30
SWEP.Primary.DefaultClip = 30
SWEP.Primary.Automatic = true
SWEP.Primary.Ammo = "ar2"
SWEP.Primary.Cone = 0.01
SWEP.Primary.Damage = 45
SWEP.Primary.Spread = 0.01
SWEP.Primary.Sound = "weapons/ak74/ak74_fp.wav"
SWEP.Primary.SoundFar = "zcitysnd/sound/weapons/ak74/ak74_dist.wav"
SWEP.Primary.Force = 10
SWEP.ReloadTime = 2
SWEP.ShootWait = 0.1
SWEP.ReloadSound = "weapons/ak74/handling/ak74_boltback.wav"
SWEP.TwoHands = true

SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = "none"

------------------------------------------

SWEP.Weight = 5
SWEP.AutoSwitchTo = false
SWEP.AutoSwitchFrom = false

SWEP.HoldType = "ar2"

------------------------------------------

SWEP.Slot = 2
SWEP.SlotPos = 0
SWEP.DrawAmmo = true
SWEP.DrawCrosshair = false

if CLIENT then
    SWEP.WepSelectIcon = surface.GetTextureID("pwb/sprites/akm")
    SWEP.BounceWeaponIcon = false
end

SWEP.Icon = "materials/entities/tfa_ins2_akm_r.png"

SWEP.ViewModel = "models/kali/weapons/ak/ak-74.mdl"
SWEP.WorldModel = "models/kali/weapons/ak/ak-74.mdl"

-- Настройки эффектов
SWEP.Tracer = "Tracer"
SWEP.MuzzleEffect = "muzzle_rifle"
-- Particle effect для дула (из homigradik_effects)
SWEP.MuzzleParticle = "muzzleflash_ar"

SWEP.Recoil = 1
SWEP.RecoilVertical = 1.1
SWEP.RecoilHorizontal = 0.96

-- Специфичные смещения для AKM
SWEP.addPos = Vector(0, 0, 0)
SWEP.addAng = Angle(0, 0, 0)

-- Настройки позиции оружия в рэгдоле (относительно правой руки)
-- Vector(вперёд/назад, влево/вправо, вверх/вниз)
SWEP.RagdollWeaponPos = Vector(13, 0, -4)
-- Angle(вверх/вниз, поворот влево/вправо, наклон)
SWEP.RagdollWeaponAng = Angle(-150, -90, 0)

-- Методы для совместимости с arc9_muzzleeffect
function SWEP:GetProcessedValue(key, ...)
    return self[key]
end

function SWEP:GetVM()
    local ply = self:GetOwner()
    if IsValid(ply) and ply == LocalPlayer() then
        return ply:GetViewModel()
    end
    return nil
end

function SWEP:ShouldTPIK()
    return false
end

function SWEP:GetMuzzleDevice(wm, ...)
    if wm then
        return self
    else
        local vm = self:GetVM()
        return IsValid(vm) and vm or self
    end
end

function SWEP:GetNthShot()
    return self.NthShot or 0
end

function SWEP:FindMuzzleAttachment()
    -- Пытаемся найти attachment дула по имени или по содержанию "muzz"
    local idx = self:LookupAttachment("muzzle")
    if idx and idx > 0 then
        local d = self:GetAttachment(idx)
        if d then return idx, d end
    end

    local atts = self:GetAttachments()
    if istable(atts) then
        for i, info in ipairs(atts) do
            local name = tostring(info.name or info)
            local lname = string.lower(name)
            if string.find(lname, "muzz", 1, true) or lname == "1" or lname == "muzzle_flash" then
                local d = self:GetAttachment(i)
                if d then return i, d end
            end
        end
        -- Если не нашли по имени, возьмём первый attachment как крайний случай
        local first = atts[1]
        if first then
            local d = self:GetAttachment(1)
            if d then return 1, d end
        end
    end

    return 0, nil
end

function SWEP:ComputeMuzzle(ply)
    local origin, ang
    local att, data = self:FindMuzzleAttachment()
    if att and att > 0 and data then
        origin = data.Pos
        ang = data.Ang
    end

    if (not origin) or (not ang) then
        if IsValid(ply) then
            local handAtt = ply:LookupAttachment("anim_attachment_RH")
            if handAtt and handAtt > 0 then
                local h = ply:GetAttachment(handAtt)
                if h then
                    origin = h.Pos + h.Ang:Forward() * 25 + h.Ang:Right() * 1 + h.Ang:Up() * -2
                    -- Для направления стараемся не использовать углы руки, чтобы не привязываться к взгляду
                    -- Пусть углы берутся из самого оружия как более стабильные для world model
                    ang = self:GetAngles()
                end
            end
        end
    end

    if (not origin) or (not ang) then
        origin = self:GetPos()
        ang = self:GetAngles()
    end

    return origin, ang
end

-- Устанавливаем Owner для совместимости с arc9_muzzleeffect
function SWEP:SetupDataTables()
    if self.BaseClass and self.BaseClass.SetupDataTables then
        self.BaseClass.SetupDataTables(self)
    end
end

-- Инициализация переменных для плавной отдачи
function SWEP:Initialize()
    -- Вызываем базовую инициализацию
    if self.BaseClass and self.BaseClass.Initialize then
        self.BaseClass.Initialize(self)
    end
    
    -- Инициализируем переменные для плавной отдачи
    if not self.AKMInitialized then
        self.AKMRecoilOffset = Angle(0, 0, 0)  -- Смещение отдачи (не абсолютные углы!)
        self.AKMLastEyeAngles = nil  -- Для отслеживания изменений углов игрока
        self.AKMRecoilSmoothness = 0.3  -- Коэффициент плавности (меньше = плавнее)
        self.AKMInitialized = true
        
        -- Инициализируем таблицу для particle systems
        self.MuzzPCFs = {}
        
        -- Инициализируем счетчик выстрелов для эффектов
        self.NthShot = 0
        
        -- Устанавливаем Owner для совместимости с arc9_muzzleeffect
        self.Owner = self:GetOwner()
        
        -- Флаг для отслеживания состояния перезарядки
        self._AKMWasReloading = false
    end
end

-- Переопределение функции отдачи для плавной радиальной отдачи (без преимущественного направления вверх)
function SWEP:ApplyRecoil()
    if not IsFirstTimePredicted() then return end
    
    local ply = self:GetOwner()
    if not IsValid(ply) then return end
    
    -- Базовый расчет отдачи (уменьшен для плавности)
    local baseRecoil = (self.Primary.Damage or 30) / 35  -- Уменьшено с 25 до 35 для плавности
    
    -- Накопление отдачи при быстрой стрельбе (более плавное)
    local timeSinceLastShot = CurTime() - (self.LastRecoilTime or 0)
    if timeSinceLastShot < 0.3 then
        self.RecoilAccumulation = (self.RecoilAccumulation or 0) + 0.1  -- Уменьшено с 0.15
    else
        self.RecoilAccumulation = math.max(0, (self.RecoilAccumulation or 0) - 0.05)  -- Плавное затухание
    end
    
    local accumMultiplier = 1 + (self.RecoilAccumulation or 0)
    
    -- Радиальная отдача: случайный угол в горизонтальной плоскости
    local randomAngle = math.Rand(0, 360)  -- Случайный угол по кругу
    local randomRadius = math.Rand(0.7, 1.3)  -- Случайная сила отдачи
    local recoilMagnitude = baseRecoil * randomRadius * accumMultiplier
    
    -- Конвертируем угол в x, y компоненты (горизонтальная плоскость)
    local radAngle = math.rad(randomAngle)
    local recoilX = math.cos(radAngle) * recoilMagnitude
    local recoilY = math.sin(radAngle) * recoilMagnitude
    
    -- Небольшой случайный компонент вверх/вниз (но не преимущественно вверх)
    local recoilZ = math.Rand(-0.2, 0.3) * recoilMagnitude  -- От -0.2 до 0.3, может быть немного вверх или вниз, но не преимущественно
    
    -- Для углов: pitch может быть немного вверх или вниз, yaw рандомный, roll рандомный
    local pitchRecoil = math.Rand(-0.3, 0.5) * recoilMagnitude  -- Может быть немного вверх/вниз, но не преимущественно вверх
    local yawRecoil = recoilX * 1.5  -- По горизонтали в соответствии с углом
    local rollRecoil = math.Rand(-1.0, 1.0) * recoilMagnitude * 0.6  -- Рандомный наклон

    -- RecoilKick - импульсная отдача в радиусе (уменьшена для плавности)
    self.RecoilKick = Vector(
        recoilX * 0.15,  -- Влево/вправо по углу
        recoilY * 0.15,  -- Вперед/назад по углу
        recoilZ * 0.1    -- Небольшой компонент вверх/вниз
    )
    
    -- RecoilKickAng - угловая импульсная отдача в радиусе (уменьшена для плавности)
    self.RecoilKickAng = Angle(
        pitchRecoil * 1.8,    -- Может быть немного вверх/вниз
        yawRecoil * 1.2,      -- По горизонтали
        rollRecoil * 0.8      -- Рандомный наклон
    )
    
    -- Плавная накопленная отдача (уменьшена для плавности)
    self.RecoilAng = self.RecoilAng + Angle(pitchRecoil * 0.15, yawRecoil * 0.12, rollRecoil * 0.08)
    self.RecoilPos = self.RecoilPos + Vector(recoilX * 0.04, recoilY * 0.04, recoilZ * 0.02)
    
    self.LastRecoilTime = CurTime()

    -- Добавляем отдачу к смещению (не к абсолютным углам!)
    if self:IsLocal() then
        if not self.AKMRecoilOffset then
            self.AKMRecoilOffset = Angle(0, 0, 0)
        end
        -- Добавляем отдачу к смещению (будет применяться плавно)
        self.AKMRecoilOffset.p = self.AKMRecoilOffset.p + pitchRecoil * 0.5
        self.AKMRecoilOffset.y = self.AKMRecoilOffset.y + yawRecoil * 0.4
    end
end

-- Переопределение PrimaryAttack для разрешения стрельбы в рэгдоле
function SWEP:PrimaryAttack()
    if not IsFirstTimePredicted() then return end
    
    if (self.NextShot or 0) > CurTime() then return end 
    if timer.Exists("reload"..self:EntIndex()) then return end

    local canfire = self:CanFireBullet()
    
    if self:Clip1() <= 0 then
        if SERVER and not self.EmptyClickPlayed then
            sound.Play("weapons/ak74/handling/ak74_empty.wav", self:GetPos(), 65, 100)
        end
        self.EmptyClickPlayed = true
        self.NextShot = CurTime() + (self.ShootWait or 0.12)
        return
    elseif (not canfire and (self.NextShot or 0) < CurTime()) then
        self.NextShot = CurTime() + (self.ShootWait or 0.12)
        return
    end

    self:PrePrimaryAttack()

    local ply = self:GetOwner()
    -- Проверяем, находится ли игрок в рэгдоле
    local inRagdoll = HG_IsRagdolled and HG_IsRagdolled(ply) or false
    
    -- В рэгдоле разрешаем стрельбу всегда (убираем проверку isClose и IsSprinting)
    if not inRagdoll then
        if self.isClose or (not ply:IsNPC() and ply:IsSprinting()) then return end
    end

    self.NextShot = CurTime() + (self.ShootWait or 0.12)

    self:ApplyRecoil()

    if SERVER then
        -- Определяем позицию для звука выстрела
        local soundPos = ply:EyePos()
        if inRagdoll then
            local rag = ply:GetNWEntity("hg_ragdoll_entity")
            if IsValid(rag) then
                local rightHandBone = rag:LookupBone("ValveBiped.Bip01_R_Hand") or 0
                local rightHandPhysIndex = rag:TranslateBoneToPhysBone(rightHandBone) or 0
                local rightHand = rag:GetPhysicsObjectNum(rightHandPhysIndex)
                if IsValid(rightHand) then
                    soundPos = rightHand:GetPos() + ply:EyeAngles():Forward() * 15
                end
            end
        else
            local muzzPos = nil
            do
                local o, a = self:ComputeMuzzle(ply)
                if o then muzzPos = o end
            end
            if muzzPos then soundPos = muzzPos end
        end
        
        net.Start("huysound")
        net.WriteVector(soundPos)
        net.WriteString(self.Primary.Sound or "")
        net.WriteString(self.Primary.SoundFar or "m9/m9_dist.wav")
        net.WriteEntity(ply)
        net.Broadcast()
        
        -- FireBullet сам определит правильную позицию для выстрела
        self:FireBullet(self.Primary.Damage, 1, 5)
    else
        if ply == LocalPlayer() then
            self:EmitSound(self.Primary.Sound or "", 511, math.random(100,120), 1, CHAN_VOICE_BASE, 0, 0)
            -- Вызовем FireBullet на клиенте для локального игрока, чтобы показать трассеры и эффекты
            -- Это не нанесёт урон и не продублирует выстрел на сервере, но позволит увидеть собственные эффекты
            self:FireBullet(self.Primary.Damage, 1, 5)
        end
    end
    
    if CLIENT and self:GetOwner() != LocalPlayer() then
        self:GetOwner():SetAnimation(PLAYER_ATTACK1)
    end
    
    self.lastShoot = CurTime()
    self:SetNWFloat("LastShoot", CurTime())
end

-- Переопределение FireBullet для использования позиции руки в рэгдоле
function SWEP:FireBullet(dmg, numbul, spread)
    if self:Clip1() <= 0 then return end
    if timer.Exists("reload"..self:EntIndex()) then return nil end
    
    local ply = self:GetOwner()
    if not IsValid(ply) then return end

    if SERVER then
        ply:LagCompensation(true)
    end

    local shootOrigin, shootAngles
    local inRagdoll = HG_IsRagdolled and HG_IsRagdolled(ply) or false
    
    -- Получаем позицию дула из мировой модели/правой руки (без ViewModel)
    shootOrigin, shootAngles = self:ComputeMuzzle(ply)
    
    -- В рэгдоле используем позицию правой руки, но направление всё равно из дула
    if inRagdoll then
        local rag = ply:GetNWEntity("hg_ragdoll_entity")
        if IsValid(rag) then
            local rightHandBone = rag:LookupBone("ValveBiped.Bip01_R_Hand") or 0
            local rightHandPhysIndex = rag:TranslateBoneToPhysBone(rightHandBone) or 0
            local rightHand = rag:GetPhysicsObjectNum(rightHandPhysIndex)
            
            if IsValid(rightHand) then
                -- Используем позицию руки для старта пули
                shootOrigin = rightHand:GetPos()
                
                -- Если не получили направление из дула, используем направление руки с учетом углов оружия
                if not shootAngles then
                    -- Пытаемся получить углы из кости руки
                    local bonePos, boneAng = rag:GetBonePosition(rightHandBone)
                    if boneAng then
                        -- Корректируем углы для направления дула
                        shootAngles = boneAng + Angle(0, 0, 0)
                    else
                        -- Fallback: используем направление взгляда
                        shootAngles = ply:EyeAngles()
                    end
                end
            else
                -- Fallback: если нет руки и дула, берем позицию оружия
                if not shootOrigin then
                    shootOrigin = self:GetPos()
                end
                if not shootAngles then
                    shootAngles = self:GetAngles()
                end
            end
        else
            if not shootOrigin then
                shootOrigin = self:GetPos()
            end
            if not shootAngles then
                shootAngles = self:GetAngles()
            end
        end
    else
        -- Обычная логика для не-рэгдолла
        -- Если не получили из дула, используем позицию оружия и его углы
        if not shootOrigin then
            shootOrigin = self:GetPos()
        end
        if not shootAngles then
            shootAngles = self:GetAngles()
        end
    end

    -- Направление строго по углу дула (без EyeTrace)
    local baseAng = Angle(shootAngles.p, shootAngles.y, shootAngles.r)
    local shootDir = baseAng:Forward()

    -- Применяем дополнительные смещения относительно направления выстрела
    local dirAng = Angle(baseAng.p, baseAng.y, baseAng.r)
    local vec = Vector(0,0,0)
    vec:Set(self.addPos or Vector(0,0,0))
    vec:Rotate(dirAng)
    shootOrigin:Add(vec)

    local ang = Angle(0,0,0)
    ang:Set(self.addAng or Angle(0,0,0))
    dirAng:Add(ang)
    shootDir = dirAng:Forward()
   
    local bullet = {
        Num = self.NumBullet or 1,
        Src = shootOrigin,
        Dir = shootDir, 
        Spread = Vector(self.Primary.Cone or 0.01, self.Primary.Cone or 0.01, 0),
        Tracer = 1,
        TracerName = self.Tracer or "Tracer",
        TracerCount = 1,
        Force = (self.Primary.Force or 0) / 40,
        Damage = dmg or (self.Primary.Damage or 30),
        AmmoType = self.Primary.Ammo or "pistol",
        Attacker = ply,
        IgnoreEntity = ply
    }

    local weapon = self
    bullet.Callback = function(attacker, tr, dmginfo)
        if IsValid(weapon) then
            weapon:BulletCallbackFunc(dmg or 30, attacker, tr, dmginfo, false, true, false)
        end

        if weapon.Primary.Ammo == "buckshot" then
            local k = math.max(1 - tr.StartPos:Distance(tr.HitPos) / 750, 0)
            dmginfo:ScaleDamage(k)
        end

        local effectdata = EffectData()
        effectdata:SetOrigin(tr.HitPos)
        effectdata:SetNormal(tr.HitNormal)
        effectdata:SetScale(1)
        util.Effect("Impact", effectdata)
        
        if SERVER then
            net.Start("shoot_huy")
            net.WriteTable(tr)
            net.Broadcast()
        end
    end

    if SERVER then 
        self:TakePrimaryAmmo(1) 
    end

    ply:FireBullets(bullet)
    if SERVER then
        ply:LagCompensation(false)
    end

    if CLIENT and IsFirstTimePredicted() then
        -- Обновляем счетчик выстрелов
        self.NthShot = (self.NthShot or 0) + 1
        
        -- Получаем attachment дула и entity для particle effect
        local muzzleAtt = 1
        local muzzleEntity = nil
        local isLocalPlayer = IsValid(ply) and ply == LocalPlayer()
        
        -- Сначала пробуем найти attachment на ViewModel для локального игрока
        if isLocalPlayer then
            local vm = ply:GetViewModel()
            if IsValid(vm) then
                local vmAtt = vm:LookupAttachment("muzzle")
                if vmAtt and vmAtt > 0 then
                    muzzleAtt = vmAtt
                    muzzleEntity = vm
                else
                    -- Если нет attachment на ViewModel, используем ViewModel с attachment 1
                    muzzleEntity = vm
                end
            end
        end
        
        -- Если не нашли ViewModel или не локальный игрок, пробуем на самом оружии
        if not IsValid(muzzleEntity) then
            local wepAtt = self:LookupAttachment("muzzle")
            if wepAtt and wepAtt > 0 then
                muzzleAtt = wepAtt
            end
            muzzleEntity = self
        end
        
        -- Создаем particle effect напрямую
        local muzzleParticle = self.MuzzleParticle or "muzzleflash_ar"
        if muzzleParticle and IsValid(muzzleEntity) then
            -- Получаем позицию дула
            local muzzlePos = shootOrigin
            local muzzleAng = shootAngles
            
            if muzzleAtt > 0 then
                local attData = muzzleEntity:GetAttachment(muzzleAtt)
                if attData then
                    muzzlePos = attData.Pos
                    muzzleAng = attData.Ang or muzzleAng
                end
            end
            
            -- Пробуем создать particle system через CreateParticleSystem
            local pcf = CreateParticleSystem(muzzleEntity, muzzleParticle, PATTACH_POINT_FOLLOW, muzzleAtt)
            if IsValid(pcf) then
                pcf:StartEmission()
                
                -- Добавляем в таблицу для управления
                if not self.MuzzPCFs then
                    self.MuzzPCFs = {}
                end
                table.insert(self.MuzzPCFs, pcf)
            else
                -- Если CreateParticleSystem не сработал, пробуем ParticleEffectAttach
                if muzzleAtt > 0 then
                    ParticleEffectAttach(muzzleParticle, PATTACH_POINT_FOLLOW, muzzleEntity, muzzleAtt)
                end
                
                -- Также создаем эффект на позиции как резерв
                local effectdata_pos = EffectData()
                effectdata_pos:SetOrigin(muzzlePos)
                effectdata_pos:SetAngles(muzzleAng)
                effectdata_pos:SetScale(1)
                util.Effect("MuzzleFlash", effectdata_pos)
            end
        end
        
        -- Также создаем динамическое освещение (muzzle flash)
        if isLocalPlayer and IsValid(muzzleEntity) then
            local attData = muzzleEntity:GetAttachment(muzzleAtt)
            if attData then
                local light = DynamicLight(self:EntIndex() + math.random(1000))
                if light then
                    light.Pos = attData.Pos
                    light.r = 244
                    light.g = 209
                    light.b = 66
                    light.Brightness = 2
                    light.Decay = 2500
                    light.Size = 256
                    light.DieTime = CurTime() + 0.1
                end
            end
        end
        
        -- Также пробуем вызвать эффект arc9_muzzleeffect для совместимости
        local effectdata = EffectData()
        effectdata:SetEntity(self)
        effectdata:SetAttachment(muzzleAtt)
        effectdata:SetSurfaceProp(self.NthShot % 2)
        
        -- Устанавливаем Owner для совместимости
        self.Owner = ply
        
        util.Effect("arc9_muzzleeffect", effectdata, true)
    end

    if ply:IsNPC() then
        self:SendWeaponAnim(ACT_VM_PRIMARYATTACK)
    end

    return true
end

-- Переопределение для более плавного затухания отдачи и плавного применения к камере
function SWEP:UpdateRecoil()
    local frameTime = FrameTime()
    
    -- Если игрок прекратил стрельбу, сбросить накопленную отдачу
    local timeSinceLastShot = CurTime() - (self.LastRecoilTime or 0)
    if timeSinceLastShot > 0.25 then
        self.RecoilAccumulation = 0
    end
    
    -- Более плавное затухание импульсной отдачи
    local kickDecay = frameTime * 5  -- Уменьшено с 8 до 5 для плавности
    self.RecoilKick = LerpVector(kickDecay, self.RecoilKick, Vector(0, 0, 0))
    self.RecoilKickAng = LerpAngle(kickDecay, self.RecoilKickAng, Angle(0, 0, 0))
    
    -- Более плавное затухание накопленной отдачи
    local smoothDecay = frameTime * 2  -- Уменьшено с 3 до 2 для плавности
    self.RecoilPos = LerpVector(smoothDecay, self.RecoilPos, Vector(0, 0, 0))
    self.RecoilAng = LerpAngle(smoothDecay, self.RecoilAng, Angle(0, 0, 0))
    
    -- Плавное применение отдачи к углам взгляда через смещения
    if self:IsLocal() then
        local ply = self:GetOwner()
        if IsValid(ply) and self.AKMRecoilOffset then
            local currentAngles = ply:EyeAngles()
            
            -- Инициализируем отслеживание базовых углов (без отдачи)
            if not self.AKMLastBaseAngles then
                self.AKMLastBaseAngles = Angle(currentAngles.p, currentAngles.y, currentAngles.r)
                self.AKMAppliedOffset = Angle(0, 0, 0)  -- Текущее примененное смещение
            end
            
            -- Вычисляем изменение базовых углов (без учета отдачи)
            local baseAngles = Angle(
                currentAngles.p - self.AKMAppliedOffset.p,
                currentAngles.y - self.AKMAppliedOffset.y,
                currentAngles.r
            )
            
            local deltaP = math.abs(math.AngleDifference(baseAngles.p, self.AKMLastBaseAngles.p))
            local deltaY = math.abs(math.AngleDifference(baseAngles.y, self.AKMLastBaseAngles.y))
            
            -- Если игрок активно двигает мышью, быстро убираем отдачу
            if deltaP > 0.3 or deltaY > 0.3 then
                -- Игрок активно управляет камерой - быстро сбрасываем отдачу
                local cancelSpeed = frameTime * 10.0
                self.AKMRecoilOffset.p = Lerp(cancelSpeed, self.AKMRecoilOffset.p, 0)
                self.AKMRecoilOffset.y = Lerp(cancelSpeed, self.AKMRecoilOffset.y, 0)
                self.AKMAppliedOffset.p = Lerp(cancelSpeed, self.AKMAppliedOffset.p, 0)
                self.AKMAppliedOffset.y = Lerp(cancelSpeed, self.AKMAppliedOffset.y, 0)
            elseif deltaP > 0.05 or deltaY > 0.05 then
                -- Небольшое движение - умеренно уменьшаем отдачу
                local cancelSpeed = frameTime * 5.0
                self.AKMRecoilOffset.p = Lerp(cancelSpeed, self.AKMRecoilOffset.p, 0)
                self.AKMRecoilOffset.y = Lerp(cancelSpeed, self.AKMRecoilOffset.y, 0)
                self.AKMAppliedOffset.p = Lerp(cancelSpeed, self.AKMAppliedOffset.p, 0)
                self.AKMAppliedOffset.y = Lerp(cancelSpeed, self.AKMAppliedOffset.y, 0)
            else
                -- Нет движения мышью - применяем отдачу плавно
                local smoothFactor = frameTime * (1.0 / (self.AKMRecoilSmoothness or 0.3))
                smoothFactor = math.min(smoothFactor, 1.0)
                
                -- Плавно увеличиваем примененное смещение к целевому
                self.AKMAppliedOffset.p = Lerp(smoothFactor, self.AKMAppliedOffset.p, self.AKMRecoilOffset.p)
                self.AKMAppliedOffset.y = Lerp(smoothFactor, self.AKMAppliedOffset.y, self.AKMRecoilOffset.y)
                
                -- Применяем смещение к углам только если оно достаточно большое
                if math.abs(self.AKMAppliedOffset.p) > 0.01 or math.abs(self.AKMAppliedOffset.y) > 0.01 then
                    ply:SetEyeAngles(Angle(
                        baseAngles.p + self.AKMAppliedOffset.p,
                        baseAngles.y + self.AKMAppliedOffset.y,
                        currentAngles.r
                    ))
                end
            end
            
            -- Плавно затухаем смещение отдачи
            local decaySpeed = frameTime * 3.0
            self.AKMRecoilOffset.p = Lerp(decaySpeed, self.AKMRecoilOffset.p, 0)
            self.AKMRecoilOffset.y = Lerp(decaySpeed, self.AKMRecoilOffset.y, 0)
            
            -- Сохраняем базовые углы (без отдачи) для следующего кадра
            self.AKMLastBaseAngles = Angle(baseAngles.p, baseAngles.y, baseAngles.r)
        end
    end
end

-- Сброс флага звука пустого магазина при отпускании спуска или появлении патронов
function SWEP:Think()
    if self.BaseClass and self.BaseClass.Think then
        self.BaseClass.Think(self)
    end

    local ply = self:GetOwner()
    if not IsValid(ply) then
        self.EmptyClickPlayed = false
        return
    end

    -- Отслеживаем завершение перезарядки и сбрасываем накопленную отдачу
    do
        local reloading = self.IsReloaded and self:IsReloaded() or false
        if self._AKMWasReloading and not reloading then
            -- Перезарядка только что завершилась — сбросить всю накопленную отдачу
            self.RecoilAccumulation = 0
            self.RecoilPos = Vector(0, 0, 0)
            self.RecoilAng = Angle(0, 0, 0)
            self.RecoilKick = Vector(0, 0, 0)
            self.RecoilKickAng = Angle(0, 0, 0)
            self.LastRecoilTime = 0

            if self.AKMRecoilOffset then
                self.AKMRecoilOffset = Angle(0, 0, 0)
            end
            if self.AKMAppliedOffset then
                self.AKMAppliedOffset = Angle(0, 0, 0)
            end
            self.AKMLastBaseAngles = nil
        end
        self._AKMWasReloading = reloading
    end

    if (self:Clip1() or 0) > 0 then
        self.EmptyClickPlayed = false
        return
    end

    if not ply:KeyDown(IN_ATTACK) then
        self.EmptyClickPlayed = false
    end
end

if CLIENT then
end