SWEP.Base = 'salat_base'

SWEP.PrintName = "Макаров"
SWEP.Author = "Homigrad"
SWEP.Instructions = "Пистолет под калибр 9×18"
SWEP.Category = "Оружие: Пистолеты"

SWEP.Spawnable = true
SWEP.AdminOnly = false

------------------------------------------

SWEP.Primary.ClipSize = 7
SWEP.Primary.DefaultClip = 7
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "pistol"
SWEP.Primary.Cone = 0.015
SWEP.Primary.Damage = 26
SWEP.Primary.Spread = 0.012
SWEP.Primary.Sound = "weapons/makarov/makarov_fp.wav"
SWEP.Primary.SoundFar = "weapons/makarov/makarov_dist.wav"
SWEP.Primary.Force = 6
SWEP.ReloadTime = 1.6
SWEP.ShootWait = 0.24
SWEP.ReloadSound = "weapons/makarov/handling/makarov_maghit.wav"
SWEP.TwoHands = false

SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = "none"

------------------------------------------

SWEP.Weight = 2
SWEP.AutoSwitchTo = false
SWEP.AutoSwitchFrom = false

SWEP.HoldType = "pistol"

------------------------------------------

SWEP.Slot = 1
SWEP.SlotPos = 0
SWEP.DrawAmmo = true
SWEP.DrawCrosshair = false

if CLIENT then
    SWEP.WepSelectIcon = surface.GetTextureID("vgui/hud/tfa_ins2_pm")
    SWEP.BounceWeaponIcon = false
end

SWEP.Icon = "materials/entities/tfa_ins2_pm.png"

SWEP.ViewModel = "models/weapons/tfa_ins2/w_pm.mdl"
SWEP.WorldModel = "models/weapons/tfa_ins2/w_pm.mdl"

-- Эффекты
SWEP.Tracer = "Tracer"
SWEP.MuzzleEffect = "muzzle_pistol"
SWEP.MuzzleParticle = "muzzleflash_pistol"

-- Умеренная отдача для пистолета
SWEP.Recoil = 0.6
SWEP.RecoilVertical = 0.7
SWEP.RecoilHorizontal = 0.5

-- Небольшие смещения (оставим по нулям)
SWEP.addPos = Vector(0, 0, 0)
SWEP.addAng = Angle(0, 0, 0)

-- Позиция оружия в рэгдоле
SWEP.RagdollWeaponPos = Vector(9, 1, -4)
SWEP.RagdollWeaponAng = Angle(-160, -90, 0)

-- Совместимость с эффектами дула (минимально необходимое)
function SWEP:GetProcessedValue(key, ...)
    return self[key]
end

function SWEP:GetVM()
    local ply = self:GetOwner()
    if IsValid(ply) and ply == LocalPlayer() then
        return ply:GetViewModel()
    end
    return nil
end

function SWEP:ShouldTPIK()
    return false
end

-- Переопределим звук пустого магазина под заданный файл
function SWEP:PrimaryAttack()
    if not IsFirstTimePredicted() then return end
    if (self.NextShot or 0) > CurTime() then return end
    if timer.Exists("reload"..self:EntIndex()) then return end

    local canfire = self.CanFireBullet and self:CanFireBullet() or true

    if self:Clip1() <= 0 then
        if SERVER and not self.EmptyClickPlayed then
            sound.Play("weapons/makarov/handling/makarov_safety.wav", self:GetPos(), 65, 100)
        end
        self.EmptyClickPlayed = true
        self.NextShot = CurTime() + (self.ShootWait or 0.25)
        return
    elseif (not canfire and (self.NextShot or 0) < CurTime()) then
        self.NextShot = CurTime() + (self.ShootWait or 0.25)
        return
    end

    if self.PrePrimaryAttack then self:PrePrimaryAttack() end

    -- Вызовем стандартную стрельбу из базового класса, если есть
    if self.FireBullet then
        local ply = self:GetOwner()
        self.NextShot = CurTime() + (self.ShootWait or 0.25)
        if SERVER then
            local soundPos = IsValid(ply) and ply:EyePos() or self:GetPos()
            net.Start("huysound")
            net.WriteVector(soundPos)
            net.WriteString(self.Primary.Sound or "")
            net.WriteString(self.Primary.SoundFar or "m9/m9_dist.wav")
            net.WriteEntity(ply or self)
            net.Broadcast()

            self:FireBullet(self.Primary.Damage, 1, 5)
        else
            if ply == LocalPlayer() then
                self:EmitSound(self.Primary.Sound or "", 511, math.random(100,120), 1, CHAN_VOICE_BASE, 0, 0)
                self:FireBullet(self.Primary.Damage, 1, 5)
            end
        end

        if CLIENT and self:GetOwner() ~= LocalPlayer() then
            self:GetOwner():SetAnimation(PLAYER_ATTACK1)
        end

        self.lastShoot = CurTime()
        self:SetNWFloat("LastShoot", CurTime())
    end
end

function SWEP:Think()
    if self.BaseClass and self.BaseClass.Think then
        self.BaseClass.Think(self)
    end

    local ply = self:GetOwner()
    if not IsValid(ply) then
        self.EmptyClickPlayed = false
        return
    end

    if (self:Clip1() or 0) > 0 then
        self.EmptyClickPlayed = false
        return
    end

    if not ply:KeyDown(IN_ATTACK) then
        self.EmptyClickPlayed = false
    end
end

if CLIENT then
end
