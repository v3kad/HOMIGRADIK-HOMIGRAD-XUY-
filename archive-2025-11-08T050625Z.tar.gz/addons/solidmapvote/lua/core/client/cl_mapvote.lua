SolidMapVote.isOpen = SolidMapVote.isOpen or false
SolidMapVote.isNominating = SolidMapVote.isNominating or false

function SolidMapVote.open( maps )
    SolidMapVote.isOpen = true
    gui.EnableScreenClicker( SolidMapVote.isOpen )

    SolidMapVote.Menu = vgui.Create( 'SolidMapVote' )
    SolidMapVote.Menu:SetMaps( maps )
end

function SolidMapVote.close()
    if ValidPanel( SolidMapVote.Menu ) then
        SolidMapVote.isOpen = false
        SolidMapVote.Menu:Remove()

        gui.EnableScreenClicker( SolidMapVote.isOpen )
    end
end

function SolidMapVote.GetMapConfigInfo( map )
    for _, mapData in pairs( SolidMapVote[ 'Config' ][ 'Specific Maps' ] ) do
        if map == mapData.filename then
            return mapData
        end
    end

    
    local mapName = map:lower()
    local potentialPaths = {
    
        "maps/thumb/" .. mapName .. ".png",
        "maps/thumb/" .. mapName .. ".jpg",
        "maps/thumb/" .. mapName .. ".jpeg",
        "maps/thumb/" .. mapName .. ".vtf",
        
        "maps/" .. mapName .. ".png", 
        "maps/" .. mapName .. ".jpg",
        "maps/" .. mapName .. ".jpeg",
        "maps/" .. mapName .. ".vtf",
        
   
        "materials/maps/" .. mapName .. ".png",
        "materials/maps/" .. mapName .. ".jpg", 
        "materials/maps/" .. mapName .. ".jpeg",
        "materials/maps/" .. mapName .. ".vtf",
        
        "materials/" .. mapName .. ".png",
        "materials/" .. mapName .. ".jpg",
        "materials/" .. mapName .. ".jpeg",
        "materials/" .. mapName .. ".vtf",
        
      
        "maps/thumb/" .. mapName .. "_thumb.png",
        "maps/thumb/" .. mapName .. "_thumbnail.png",
        "maps/thumb/" .. mapName .. "-thumb.png",
        "maps/thumb/" .. mapName .. "-thumbnail.png",
        
        "materials/maps/" .. mapName .. "_thumb.png",
        "materials/maps/" .. mapName .. "_thumbnail.png",
        "materials/maps/" .. mapName .. "-thumb.png",
        "materials/maps/" .. mapName .. "-thumbnail.png",
        
       
        "materials/vgui/thumb/" .. mapName .. ".png",
        "materials/vgui/thumb/" .. mapName .. ".jpg",
        "materials/vgui/thumb/" .. mapName .. ".vtf",
        
      
        "materials/vgui/ttt/" .. mapName .. ".png",
        "materials/vgui/ttt/thumbnails/" .. mapName .. ".png",
        "materials/vgui/ttt/thumbnails/" .. mapName .. ".jpg",
        
        "materials/vgui/sandbox/" .. mapName .. ".png",
        "materials/vgui/sandbox/thumbnails/" .. mapName .. ".png",
        
        "materials/vgui/darkrp/" .. mapName .. ".png",
        "materials/vgui/darkrp/thumbnails/" .. mapName .. ".png",
        
        "materials/vgui/murder/" .. mapName .. ".png",
        "materials/vgui/murder/thumbnails/" .. mapName .. ".png",
        
        "materials/vgui/prophunt/" .. mapName .. ".png",
        "materials/vgui/prophunt/thumbnails/" .. mapName .. ".png",
        
        "materials/vgui/deathrun/" .. mapName .. ".png",
        "materials/vgui/deathrun/thumbnails/" .. mapName .. ".png",
        
        "materials/vgui/jailbreak/" .. mapName .. ".png",
        "materials/vgui/jailbreak/thumbnails/" .. mapName .. ".png",
    }

    local localImage = ""
    for _, path in ipairs(potentialPaths) do
        if file.Exists(path, "GAME") then
            localImage = path
            break
        end
    end

   
    if localImage == "" then
       
        local gamemodeFolder = engine.ActiveGamemode()
        if gamemodeFolder then
            local gmPaths = {
                "materials/vgui/" .. gamemodeFolder .. "/default_map.png",
                "materials/vgui/" .. gamemodeFolder .. "/default_map.jpg",
                "materials/vgui/" .. gamemodeFolder .. "/thumbnails/default.png",
            }
            
            for _, gmPath in ipairs(gmPaths) do
                if file.Exists(gmPath, "GAME") then
                    localImage = gmPath
                    break
                end
            end
        end
    end

    return {
        filename = map,
        displayname = string.Replace( map, '_', ' ' ),
        image = localImage ~= "" and localImage or SolidMapVote[ 'Config' ][ 'Missing Image' ],
        width = SolidMapVote[ 'Config' ][ 'Missing Image Size' ].width,
        height = SolidMapVote[ 'Config' ][ 'Missing Image Size' ].height
    }
end

hook.Add( 'PlayerBindPress', 'SolidMapVote.StopMovement', function( ply, bind )
    if ValidPanel( SolidMapVote.Menu ) and
       SolidMapVote.Menu:IsVisible() and
       bind != 'solidmapvote_test' and
       (bind != 'messagemode' and SolidMapVote[ 'Config' ][ 'Enable Chat' ]) and
       (bind != 'messagemode2' and SolidMapVote[ 'Config' ][ 'Enable Chat' ]) and
       (bind != '+voicerecord' and SolidMapVote[ 'Config' ][ 'Enable Voice' ])
    then
        return true
    end
end )

local matBlur = Material( 'pp/blurscreen' )
hook.Add( 'HUDPaint', 'SolidMapVote.DrawBackgroundBlur', function()
    if SolidMapVote.isOpen then
        surface.SetDrawColor( 255, 255, 255, 255 )
        surface.SetMaterial( matBlur )

        for i = 1, 3 do
            matBlur:SetFloat( '$blur', i )
            matBlur:Recompute()
            render.UpdateScreenEffectTexture()
            surface.DrawTexturedRect( 0, 0, ScrW(), ScrH() )
        end
    end
end )

concommand.Add( 'solidmapvote_nomination_menu', function()
   
    if SolidMapVote.isOpen then return end
    if SolidMapVote.isNominating then
        if ValidPanel( SolidMapVote.Nominate ) then
            SolidMapVote.Nominate:Remove()
            SolidMapVote.isNominating = false
            gui.EnableScreenClicker( SolidMapVote.isNominating )
        end

        return
    end

    SolidMapVote.isNominating = true
    gui.EnableScreenClicker( SolidMapVote.isNominating )
    SolidMapVote.Nominate = vgui.Create( 'SolidMapVoteNomination' )
end )

concommand.Add( 'solidmapvote_close_ui', function()
    SolidMapVote.close()
end )