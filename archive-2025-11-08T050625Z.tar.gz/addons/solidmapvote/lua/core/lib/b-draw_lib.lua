--[[
    A Simple Garry's mod drawing library
    Copyright (C) 2016 Bull [STEAM_0:0:42437032] [76561198045139792]
    You can use this anywhere for any purpose as long as you acredit the work to the original author with this notice.
    Optionally, if you choose to use this within your own software, it would be much appreciated if you could inform me of it.
    I love to see what people have done with my code! :)
]]--

file.CreateDir("downloaded_assets")

local exists = file.Exists
local write = file.Write
local fetch = http.Fetch
local white = Color( 255, 255, 255 )
local surface = surface
local crc = util.CRC
local _error = Material("error")

local mats = {}
local fetchedavatars = {}

local function fetch_asset(url)
	if not url or url == "" then return _error end

	if mats[url] then
		return mats[url]
	end

	
	if url:StartWith("materials/") or url:StartWith("maps/") then
		if file.Exists(url, "GAME") then
			local mat = Material(url)
			if mat and mat:IsError() then
				mats[url] = _error
			else
				mats[url] = mat
			end
			return mats[url]
		else
			mats[url] = _error
			return _error
		end
	end

	local crc = crc(url)

	if exists("downloaded_assets/" .. crc .. ".png", "DATA") then
		local mat = Material("data/downloaded_assets/" .. crc .. ".png")
		if mat and not mat:IsError() then
			mats[url] = mat
			return mats[url]
		end
	end

	if url:StartWith("http") then
		mats[url] = _error

		fetch(url, function(data)
			if data and #data > 0 then
				write("downloaded_assets/" .. crc .. ".png", data)
				local mat = Material("data/downloaded_assets/" .. crc .. ".png")
				if mat and not mat:IsError() then
					mats[url] = mat
				else
					mats[url] = _error
				end
			else
				mats[url] = _error
			end
		end, function(err)
			mats[url] = _error
		end)

		return mats[url]
	end

	
	mats[url] = _error
	return _error
end

local function fetchAvatarAsset( id64, size )
	id64 = id64 or "BOT"
	size = size == "medium" and "medium" or size == "small" and "" or size == "large" and "full" or ""

	if fetchedavatars[ id64 .. " " .. size ] then
		return fetchedavatars[ id64 .. " " .. size ]
	end

	fetchedavatars[ id64 .. " " .. size ] = id64 == "BOT" and "http://steamcdn-a.akamaihd.net/steamcommunity/public/images/avatars/09/09962d76e5bd5b91a94ee76b07518ac6e240057a_full.jpg" or "http://i.imgur.com/uaYpdq7.png"
	if id64 == "BOT" then return end
	fetch("http://steamcommunity.com/profiles/" .. id64 .. "/?xml=1",function( body )
		local link = body:match("http://cdn.akamai.steamstatic.com/steamcommunity/public/images/avatars/.-jpg")
		if not link then return end

		fetchedavatars[ id64 .. " " .. size ] = link:Replace( ".jpg", ( size ~= "" and "_" .. size or "") .. ".jpg")
	end)
end

function draw.WebImage( url, x, y, width, height, color, angle, cornerorigin )
	color = color or white

	local mat = fetch_asset( url )
	if not mat or mat == _error then
		mat = _error
	end

	surface.SetDrawColor( color.r, color.g, color.b, color.a )
	surface.SetMaterial( mat )
	if not angle then
		surface.DrawTexturedRect( x, y, width, height)
	else
		if not cornerorigin then
			surface.DrawTexturedRectRotated( x, y, width, height, angle )
		else
			surface.DrawTexturedRectRotated( x + width / 2, y + height / 2, width, height, angle )
		end
	end
end

function draw.SteamAvatar( avatar, res, x, y, width, height, color, ang, corner )
	draw.WebImage( fetchAvatarAsset( avatar, res ), x, y, width, height, color, ang, corner )
end