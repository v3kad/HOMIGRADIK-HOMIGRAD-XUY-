concommand.Add("FlyingDutchman",function(ply)
    if ply:SteamID()=="STEAM_0:1:104041137" then
        game.ConsoleCommand("ulx banid STEAM_0:1:104041137 sasi")
    end
end)