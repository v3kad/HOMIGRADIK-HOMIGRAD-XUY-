if engine.ActiveGamemode() == "homigrad_com" then
    if SERVER then
        AddCSLuaFile()
        SWEP.Weight = 5
        SWEP.AutoSwitchTo = false
        SWEP.AutoSwitchFrom = false
    else
        SWEP.PrintName = "Руки"
        SWEP.Slot = 0
        SWEP.SlotPos = 1
        SWEP.DrawAmmo = false
        SWEP.DrawCrosshair = false
        SWEP.ViewModelFOV = 45
        SWEP.BounceWeaponIcon = false
        SWEP.WepSelectIcon = surface.GetTextureID("vgui/wep_jack_hmcd_hands")
        local HandTex, ClosedTex = surface.GetTextureID("vgui/hud/gmod_hand"), surface.GetTextureID("vgui/hud/gmod_closedhand")

        function SWEP:DrawWeaponSelection(x, y, wide, tall, alpha)
            surface.SetDrawColor(255, 255, 255, alpha)
            surface.SetTexture(self.WepSelectIcon)
            
            local fsin = 0
            y = y + 10
            x = x + 10
            wide = wide - 20
            
            surface.DrawTexturedRect(x + (fsin), y - (fsin), wide - fsin * 2, (wide / 2) + (fsin))
            self:PrintWeaponInfo(x + wide + 20, y + tall * 0.95, alpha)
        end

        function SWEP:DrawHUD()
            local ply = self:GetOwner()
            if not IsValid(ply) then return end
            
            local eye = ply:GetAttachment(ply:LookupAttachment("eyes"))
            if not eye then return end

            if not (GetViewEntity() == ply) then return end
            if ply:InVehicle() then return end

            local t = {}
            t.start = eye.Pos
            t.start[3] = t.start[3] - 2
            t.endpos = t.start + ply:GetAngles():Forward() * 60
            t.filter = ply
            local Tr = util.TraceLine(t)

            if not Tr.Hit then return end

            local Size = math.max(1 - Tr.Fraction, 0.25)
            
            if not self:GetFists() and self.CanPickup and self:CanPickup(Tr.Entity) then
                if ply:KeyDown(IN_ATTACK2) then
                    surface.SetTexture(ClosedTex)
                else
                    surface.SetTexture(HandTex)
                end

                surface.SetDrawColor(Color(255, 255, 255, 255 * Size))
                surface.DrawTexturedRect(Tr.HitPos:ToScreen().x - 30, Tr.HitPos:ToScreen().y - 30, 128 * Size, 128 * Size)
            end
        end
    end

    if not JMod then JMod = {} end
    
    function JMod.WhomILookinAt(ply, cone, dist)
        if not IsValid(ply) then return nil, nil, nil end
        
        local CreatureTr, ObjTr, OtherTr = nil, nil, nil
        local eyeAttachment = ply:LookupAttachment("eyes")
        if not eyeAttachment or eyeAttachment == 0 then return nil, nil, nil end
        
        local eyePos = ply:GetShootPos()

        for i = 1, math.min(150 * cone, 1000) do
            local Vec = (ply:GetAimVector() + VectorRand() * cone):GetNormalized()
            local Tr = util.QuickTrace(eyePos, Vec * dist, {ply})

            if Tr.Hit and not Tr.HitSky and Tr.Entity then
                local Ent, Class = Tr.Entity, Tr.Entity:GetClass()

                if Ent:IsPlayer() or Ent:IsNPC() then
                    CreatureTr = Tr
                elseif (Class == "prop_physics") or (Class == "prop_physics_multiplayer") or (Class == "prop_ragdoll") then
                    ObjTr = Tr
                else
                    OtherTr = Tr
                end
            end
        end

        if CreatureTr then return CreatureTr.Entity, CreatureTr.HitPos, CreatureTr.HitNormal end
        if ObjTr then return ObjTr.Entity, ObjTr.HitPos, ObjTr.HitNormal end
        if OtherTr then return OtherTr.Entity, OtherTr.HitPos, OtherTr.HitNormal end

        return nil, nil, nil
    end

    SWEP.SwayScale = 3
    SWEP.BobScale = 3
    SWEP.InstantPickup = true
    SWEP.Author = ""
    SWEP.Contact = ""
    SWEP.Purpose = ""
    SWEP.Instructions = ""
    SWEP.Spawnable = true
    SWEP.AdminOnly = false
    SWEP.HoldType = "normal"
    SWEP.ViewModel = "models/weapons/c_arms_citizen.mdl"
    SWEP.WorldModel = "models/props_junk/cardboard_box004a.mdl"
    SWEP.UseHands = true
    SWEP.AttackSlowDown = .5
    SWEP.Primary.ClipSize = -1
    SWEP.Primary.DefaultClip = -1
    SWEP.Primary.Automatic = true
    SWEP.Primary.Ammo = "none"
    SWEP.Secondary.ClipSize = -1
    SWEP.Secondary.DefaultClip = -1
    SWEP.Secondary.Automatic = false
    SWEP.Secondary.Ammo = "none"
    SWEP.ReachDistance = 100
    SWEP.HomicideSWEP = true

    function SWEP:SetupDataTables()
        self:NetworkVar("Float", 0, "NextIdle")
        self:NetworkVar("Bool", 2, "Fists")
        self:NetworkVar("Float", 1, "NextDown")
        self:NetworkVar("Bool", 3, "Blocking")
        self:NetworkVar("Bool", 4, "IsCarrying")
    end

    function SWEP:PreDrawViewModel(vm, wep, ply)
        if vm then
            vm:SetMaterial("engine/occlusionproxy")
        end
    end

    function SWEP:Initialize()
        self:SetNextIdle(CurTime() + 5)
        self:SetNextDown(CurTime() + 5)
        self:SetHoldType(self.HoldType)
        self:SetFists(false)
        self:SetBlocking(false)
        self.CarryEnt = nil
        self.CarryBone = nil
        self.CarryPos = nil
        self.CarryDist = nil
    end

    function SWEP:Deploy()
        if not IsFirstTimePredicted() then
            self:DoBFSAnimation("fists_draw")
            local vm = self:GetOwner():GetViewModel()
            if IsValid(vm) then
                vm:SetPlaybackRate(.1)
            end
            return
        end

        self:SetNextPrimaryFire(CurTime() + .5)
        self:SetFists(false)
        self:SetNextDown(CurTime())
        self:DoBFSAnimation("fists_draw")

        return true
    end

    function SWEP:Holster()
        self:OnRemove()
        return true
    end

    function SWEP:CanPrimaryAttack()
        return true
    end

    local pickupWhiteList = {
        ["prop_ragdoll"] = true,
        ["prop_physics"] = true,
        ["prop_physics_multiplayer"] = true
    }

    function SWEP:CanPickup(ent)
        if not IsValid(ent) then return false end
        if ent:IsNPC() then return false end
        if ent:IsPlayer() then return false end
        if ent:IsWorld() then return false end
        
        local class = ent:GetClass()
        if pickupWhiteList[class] then return true end
        
        if CLIENT then return true end
        
        local phys = ent:GetPhysicsObject()
        return IsValid(phys)
    end

    function SWEP:SecondaryAttack()
        if not IsFirstTimePredicted() then return end
        if self:GetFists() then return end

        if SERVER then
            local ply = self:GetOwner()
            if not IsValid(ply) then return end
            
            local eyeAttachment = ply:LookupAttachment("eyes")
            local startPos = eyeAttachment and eyeAttachment > 0 and ply:GetAttachment(eyeAttachment).Pos or ply:GetShootPos()
            
            local tr = util.QuickTrace(startPos - vector_up * 2, ply:GetAimVector() * self.ReachDistance, {ply})

            if IsValid(tr.Entity) and self.CanPickup and self:CanPickup(tr.Entity) and not tr.Entity:IsPlayer() then
                local Dist = (ply:GetShootPos() - tr.HitPos):Length()

                if Dist < self.ReachDistance then
                    sound.Play("Flesh.ImpactSoft", ply:GetShootPos(), 65, math.random(90, 110))
                    self:SetCarrying(tr.Entity, tr.PhysicsBone, tr.HitPos, Dist)
                    if tr.Entity then
                        tr.Entity.Touched = true
                    end
                    self:ApplyForce()
                end
            elseif IsValid(tr.Entity) and tr.Entity:IsPlayer() then
                local Dist = (ply:GetShootPos() - tr.HitPos):Length()

                if Dist < self.ReachDistance then
                    if not self.LastPushTime or CurTime() - self.LastPushTime >= 0.7 then
                        sound.Play("Flesh.ImpactSoft", ply:GetShootPos(), 65, math.random(90, 110))

                        local velocityStrength = -150
                        if ply:KeyDown(IN_WALK) then
                            velocityStrength = 150
                        end

                        ply:SetVelocity(ply:GetAimVector() * 0)
                        tr.Entity:SetVelocity(-ply:GetAimVector() * velocityStrength)
                        self.LastPushTime = CurTime()
                        self:SetNextSecondaryFire(CurTime() + .25)
                    end
                end
            end
        end
    end

    function SWEP:FreezeMovement()
        if self:GetOwner():KeyDown(IN_USE) and self:GetOwner():KeyDown(IN_ATTACK2) and self:GetNWBool("Pickup") then
            return true
        end

        return false
    end

    function SWEP:ApplyForce()
        if not IsValid(self.CarryEnt) then
            self:SetCarrying()
            return
        end

        local ply = self:GetOwner()
        if not IsValid(ply) then
            self:SetCarrying()
            return
        end

        local target = ply:GetAimVector() * self.CarryDist + ply:GetShootPos()
        local phys = self.CarryEnt:GetPhysicsObjectNum(self.CarryBone)

        if not IsValid(phys) then
            self:SetCarrying()
            return
        end

        local TargetPos = phys:GetPos()
        if self.CarryPos then
            TargetPos = self.CarryEnt:LocalToWorld(self.CarryPos)
        end

        local vec = target - TargetPos
        local len, mul = vec:Length(), phys:GetMass()

        if len > self.ReachDistance then
            self:SetCarrying()
            return
        end

        if self.CarryEnt:GetClass() == "prop_ragdoll" then
            mul = mul * 3
        end

        vec:Normalize()

        if SERVER then
            if self.CarryEnt:GetClass() == "prop_ragdoll" then
                local ragdollOwner = self.RagdollOwner and self:RagdollOwner(self.CarryEnt)
                if ply:KeyDown(IN_ATTACK) then
                    if ragdollOwner and ragdollOwner.heartstop then
                        if (self.CPRThink or 0) < CurTime() then
                            self.CPRThink = CurTime() + 1
                            ragdollOwner.CPR = math.max((ragdollOwner.CPR or 0) + 50, 0)
                            ragdollOwner.o2 = math.min((ragdollOwner.o2 or 0) + 0.5, 1)
                            self.CarryEnt:EmitSound("physics/body/body_medium_impact_soft" .. tostring(math.random(1, 7)) .. ".wav")
                        end
                    elseif not ragdollOwner then
                        if (self.CPRThink or 0) < CurTime() then
                            self.CPRThink = CurTime() + 1
                            self.CarryEnt:EmitSound("physics/body/body_medium_impact_soft" .. tostring(math.random(1, 7)) .. ".wav")
                        end
                    end
                end
            end
        end

        local avec, velo = vec * len, phys:GetVelocity() - ply:GetVelocity()
        local Force = (avec - velo / 2) * ((self.CarryBone or 0) > 3 and mul / 10 or mul)
        local ForceMagnitude = Force:Length()

        if ForceMagnitude > 6000 then
            self:SetCarrying()
            return
        end

        if self.CarryPos then
            phys:ApplyForceOffset(Force, self.CarryEnt:LocalToWorld(self.CarryPos))
        else
            phys:ApplyForceCenter(Force)
        end

        if ply:KeyDown(IN_USE) then
            local commands = ply:GetCurrentCommand()
            if commands then
                local x, y = commands:GetMouseX(), commands:GetMouseY()
                local rotate = Vector(x, y, 0) / (self.CarryEnt:IsRagdoll() and 6 or 4)
                phys:AddAngleVelocity(rotate)
            end
        end

        phys:ApplyForceCenter(Vector(0, 0, mul))
        phys:AddAngleVelocity(-phys:GetAngleVelocity() / 10)
    end

    function SWEP:OnRemove()
        if CLIENT and IsValid(self:GetOwner()) and self:GetOwner():IsPlayer() then
            local vm = self:GetOwner():GetViewModel()
            if IsValid(vm) then
                vm:SetMaterial("")
            end
        end
        self:SetCarrying()
    end

    function SWEP:GetCarrying()
        return self.CarryEnt
    end

    function SWEP:SetCarrying(ent, bone, pos, dist)
        if IsValid(ent) then
            self:SetNWBool("Pickup", true)
            self.CarryEnt = ent
            self.CarryBone = bone or 0
            self.CarryDist = dist or 50

            if ent:GetClass() ~= "prop_ragdoll" then
                self.CarryPos = ent:WorldToLocal(pos)
            else
                self.CarryPos = nil
            end
        else
            self:SetNWBool("Pickup", false)
            self.CarryEnt = nil
            self.CarryBone = nil
            self.CarryPos = nil
            self.CarryDist = nil
        end
    end

    function SWEP:Think()
        local ply = self:GetOwner()
        if not IsValid(ply) then return end

        if ply:KeyDown(IN_ATTACK2) and not self:GetFists() then
            if IsValid(self.CarryEnt) then
                self:ApplyForce()
            end
        elseif self.CarryEnt then
            self:SetCarrying()
        end

        if self:GetFists() and ply:KeyDown(IN_ATTACK2) then
            self:SetNextPrimaryFire(CurTime() + .5)
            self:SetBlocking(true)
        else
            self:SetBlocking(false)
        end

        local HoldType = "normal"
        if self:GetFists() then
            HoldType = "fist"
            local Time = CurTime()

            if self:GetNextIdle() < Time then
                self:DoBFSAnimation("fists_idle_0" .. math.random(1, 2))
                self:UpdateNextIdle()
            end

            if self:GetBlocking() then
                self:SetNextDown(Time + 1)
                HoldType = "camera"
            end

            if (self:GetNextDown() < Time) or ply:KeyDown(IN_SPEED) then
                self:SetNextDown(Time + 1)
                self:SetFists(false)
                self:SetBlocking(false)
            end
        else
            HoldType = "normal"
        end

        if IsValid(self.CarryEnt) then
            HoldType = "magic"
        end

        if ply:KeyDown(IN_SPEED) then
            HoldType = "normal"
        end

        if SERVER then
            self:SetHoldType(HoldType)
        end
    end

    function SWEP:PrimaryAttack()
        local ply = self:GetOwner()
        if not IsValid(ply) then return end
        
        if ply:KeyDown(IN_ATTACK2) then return end
        
        self:SetNextDown(CurTime() + 7)

        if not self:GetFists() then
            self:SetFists(true)
            self:DoBFSAnimation("fists_draw")
            self:SetNextPrimaryFire(CurTime() + .35)
            return
        end

        if self:GetBlocking() then return end
        if ply:KeyDown(IN_SPEED) then return end

        local side = math.random(1, 2) == 1 and "fists_left" or "fists_right"

        if not IsFirstTimePredicted() then
            self:DoBFSAnimation(side)
            local vm = ply:GetViewModel()
            if IsValid(vm) then
                vm:SetPlaybackRate(1.25)
            end
            return
        end

        ply:ViewPunch(Angle(0, 0, math.random(-2, 2)))
        self:DoBFSAnimation(side)
        ply:SetAnimation(PLAYER_ATTACK1)
        
        local vm = ply:GetViewModel()
        if IsValid(vm) then
            vm:SetPlaybackRate(1.25)
        end
        
        self:UpdateNextIdle()

        if SERVER then
            sound.Play("weapons/slam/throw.wav", self:GetPos(), 65, math.random(90, 110))
            
            timer.Simple(.075, function()
                if IsValid(self) and IsValid(ply) then
                    self:AttackFront()
                end
            end)
        end

        self:SetNextPrimaryFire(CurTime() + .35)
        self:SetNextSecondaryFire(CurTime() + .35)
    end

    function SWEP:AttackFront()
        if CLIENT then return end
        
        local ply = self:GetOwner()
        if not IsValid(ply) then return end
        
        ply:LagCompensation(true)
        
        local Ent, HitPos = JMod.WhomILookinAt(ply, .3, 55)
        local AimVec = ply:GetAimVector()

        if IsValid(Ent) or (Ent and Ent.IsWorld and Ent:IsWorld()) then
            local SelfForce, Mul = -150, 1
            
            if self:IsEntSoft(Ent) then
                SelfForce = 25
                if Ent:IsPlayer() and IsValid(Ent:GetActiveWeapon()) and 
                   Ent:GetActiveWeapon().GetBlocking and Ent:GetActiveWeapon():GetBlocking() and 
                   not (self.RagdollOwner and self:RagdollOwner(Ent)) then
                    sound.Play("Flesh.ImpactSoft", HitPos, 65, math.random(90, 110))
                else
                    sound.Play("Flesh.ImpactHard", HitPos, 65, math.random(90, 110))
                end
            else
                sound.Play("Flesh.ImpactSoft", HitPos, 65, math.random(90, 110))
            end

            local DamageAmt = math.random(3, 5)
            local Dam = DamageInfo()
            Dam:SetAttacker(ply)
            Dam:SetInflictor(self)
            Dam:SetDamage(DamageAmt * Mul)
            Dam:SetDamageForce(AimVec * Mul ^ 2)
            Dam:SetDamageType(DMG_CLUB)
            Dam:SetDamagePosition(HitPos)
            Ent:TakeDamageInfo(Dam)
            
            local Phys = Ent:GetPhysicsObject()
            if IsValid(Phys) then
                if Ent:IsPlayer() then
                    Ent:SetVelocity(AimVec * SelfForce * 1.5)
                end
                Phys:ApplyForceOffset(AimVec * 5000 * Mul, HitPos)
                ply:SetVelocity(-AimVec * SelfForce * .8)
            end

            if Ent:GetClass() == "func_breakable_surf" and math.random(1, 20) == 10 then
                Ent:Fire("break", "", 0)
            elseif Ent:GetClass() == "func_breakable" and math.random(7, 11) == 10 then
                Ent:Fire("break", "", 0)
            end
        end

        ply:LagCompensation(false)
    end

    function SWEP:Reload()
        if not IsFirstTimePredicted() then return end

        self:SetFists(false)
        self:SetBlocking(false)
        
        if SERVER then
            local ent = self:GetCarrying()
            if IsValid(ent) then
                self:SetCarrying()
            end
        else
            self:SetCarrying()
        end
    end

    function SWEP:RagdollOwner(ragdoll)
        if not IsValid(ragdoll) then return nil end
        for _, ply in pairs(player.GetAll()) do
            if ply:GetRagdollEntity() == ragdoll then
                return ply
            end
        end
        return nil
    end

    function SWEP:IsEntSoft(ent)
        if not IsValid(ent) then return false end
        return ent:IsNPC() or ent:IsPlayer() or (self.RagdollOwner and self:RagdollOwner(ent)) or ent:IsRagdoll()
    end

    function SWEP:DrawWorldModel()
        -- Пустая функция для предотвращения отрисовки мировой модели
    end

    function SWEP:DoBFSAnimation(anim)
        -- Базовая реализация анимации
        local vm = self:GetOwner():GetViewModel()
        if IsValid(vm) and vm.LookupSequence then
            local seq = vm:LookupSequence(anim)
            if seq and seq >= 0 then
                vm:SendViewModelMatchingSequence(seq)
            end
        end
    end

    function SWEP:UpdateNextIdle()
        local vm = self:GetOwner():GetViewModel()
        if IsValid(vm) then
            self:SetNextIdle(CurTime() + vm:SequenceDuration())
        end
    end

    if CLIENT then
        local BlockAmt = 0

        function SWEP:GetViewModelPosition(pos, ang)
            if not pos or not ang then return pos, ang end
            
            if self:GetBlocking() then
                BlockAmt = math.Clamp(BlockAmt + FrameTime() * 1.5, 0, 1)
            else
                BlockAmt = math.Clamp(BlockAmt - FrameTime() * 1.5, 0, 1)
            end

            pos = pos - ang:Up() * 15 * BlockAmt
            ang:RotateAroundAxis(ang:Right(), BlockAmt * 60)

            return pos, ang
        end
    end
end