AddCSLuaFile()

SWEP.Base = "weapon_base"

SWEP.PrintName = "Бинт"
SWEP.Category = "Медицина"
SWEP.Instructions = "ЛКМ: наложить бинт на себя (до 5 ран)."

SWEP.Spawnable = true
SWEP.AdminSpawnable = true
SWEP.AdminOnly = false

SWEP.ViewModelFOV = 62
SWEP.ViewModel = "models/weapons/medecine/bandage/healthvial.mdl"
SWEP.WorldModel = "models/weapons/medecine/bandage/healthvial.mdl"
SWEP.UseHands = true

-- offsets
SWEP.VMOffsetPos = Vector(0, 0, 0)
SWEP.VMOffsetAng = Angle(0, 0, 0)
SWEP.WMOffsetPos = Vector(-3, -3, -1)
SWEP.WMOffsetAng = Angle(-50, 0, 180)

SWEP.Slot = 1
SWEP.SlotPos = 5

SWEP.DrawAmmo = false
SWEP.DrawCrosshair = false

SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = -1
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "none"
SWEP.Primary.Delay = 1.2

SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = "none"

if CLIENT then
    SWEP.WepSelectIcon = surface.GetTextureID("vgui/wep_jack_hmcd_bandage")
    SWEP.BounceWeaponIcon = false
end

local BANDAGE_MAX_WOUNDS = 5

function SWEP:SetupDataTables()
	self:NetworkVar("Int", 0, "HGBandageUses")
end

function SWEP:Initialize()
	self:SetHoldType("slam")
	if SERVER then
		if self:GetHGBandageUses() == 0 then
			self:SetHGBandageUses(BANDAGE_MAX_WOUNDS)
		end
	end
end

function SWEP:Deploy()
	self:SetHoldType("slam")
	return true
end

function SWEP:PrimaryAttack()
	if self:GetNextPrimaryFire() > CurTime() then return end
	self:SetNextPrimaryFire(CurTime() + self.Primary.Delay)

	if not IsValid(self:GetOwner()) then return end
	local owner = self:GetOwner()
	if not owner:IsPlayer() then return end

	if SERVER then
		local usesLeft = self:GetHGBandageUses()
		if usesLeft <= 0 then return end

		local wounds = owner.GetHGBulletWounds and owner:GetHGBulletWounds() or 0
		if wounds <= 0 and not owner:IsHGBleeding() then
			owner:ChatPrint("Нет ран для перевязки.")
			return
		end

		local toStop = math.min(usesLeft, math.max(0, wounds))
		if toStop <= 0 and owner:IsHGBleeding() then
			-- остановить обычное кровотечение, если нет огнестрела
			owner:SetHGBleeding(0)
			usesLeft = usesLeft - 1
			self:SetHGBandageUses(usesLeft)
			owner:EmitSound("items/medshot4.wav", 65, 100)
			if usesLeft <= 0 then
				owner:StripWeapon(self:GetClass())
			end
			return
		end

		if toStop > 0 then
			owner:AddHGBulletWounds(-toStop)
			usesLeft = usesLeft - toStop
			self:SetHGBandageUses(usesLeft)

			if (owner:GetHGBulletWounds() <= 0) and (owner:GetHGBleedingRate() >= 2) then
				owner:SetHGBleeding(0)
			end

			owner:EmitSound("items/medshot4.wav", 65, 100)
			owner:ChatPrint("Перевязано ран: " .. tostring(toStop))

			if usesLeft <= 0 then
				owner:StripWeapon(self:GetClass())
			end
		end
	end
end

function SWEP:SecondaryAttack()
	if self.GetNextSecondaryFire and self:GetNextSecondaryFire() > CurTime() then return end
	if self.SetNextSecondaryFire then self:SetNextSecondaryFire(CurTime() + (self.Primary and self.Primary.Delay or 1)) end

	if not IsValid(self:GetOwner()) then return end
	local owner = self:GetOwner()
	if not owner:IsPlayer() then return end

	if SERVER then
		local usesLeft = self:GetHGBandageUses()
		if usesLeft <= 0 then return end

		-- Trace target
		local tr = owner:GetEyeTrace()
		local ent = IsValid(tr.Entity) and tr.Entity or nil
		local target = nil
		if IsValid(ent) then
			if ent:IsPlayer() then
				target = ent
			elseif ent:GetClass() == "prop_ragdoll" then
				local ragOwner = ent:GetNWEntity("hg_ragdoll_owner")
				if IsValid(ragOwner) and ragOwner:IsPlayer() then
					target = ragOwner
				end
				if not IsValid(target) then
					for _, p in ipairs(player.GetAll()) do
						local rag = p:GetNWEntity("hg_ragdoll_entity")
						if IsValid(rag) and rag == ent then
							target = p
							break
						end
					end
				end
			end
		end

		if not IsValid(target) or target == owner then return end

		-- distance check
		local maxDist = 160
		if owner:GetPos():DistToSqr(target:GetPos()) > (maxDist * maxDist) then return end

		-- Apply bandage logic to target (mirrors PrimaryAttack but for target)
		local wounds = target.GetHGBulletWounds and target:GetHGBulletWounds() or 0
		if wounds <= 0 and not target:IsHGBleeding() then
			owner:ChatPrint("У игрока нет ран для перевязки.")
			return
		end

		local toStop = math.min(usesLeft, math.max(0, wounds))
		if toStop <= 0 and target:IsHGBleeding() then
			-- stop normal bleeding if no bullet wounds
			target:SetHGBleeding(0)
			usesLeft = usesLeft - 1
			self:SetHGBandageUses(usesLeft)
			target:EmitSound("items/medshot4.wav", 65, 100)
			owner:ChatPrint("Вы остановили кровотечение.")
			if usesLeft <= 0 then
				owner:StripWeapon(self:GetClass())
			end
			return
		end

		if toStop > 0 then
			target:AddHGBulletWounds(-toStop)
			usesLeft = usesLeft - toStop
			self:SetHGBandageUses(usesLeft)

			if (target:GetHGBulletWounds() <= 0) and (target:GetHGBleedingRate() >= 2) then
				target:SetHGBleeding(0)
			end

			target:EmitSound("items/medshot4.wav", 65, 100)
			owner:ChatPrint("Перевязано ран цели: " .. tostring(toStop))

			if usesLeft <= 0 then
				owner:StripWeapon(self:GetClass())
			end
		end
	end
end

-- third-person (worldmodel) offset in owner's hand
function SWEP:DrawWorldModel()
	local owner = self:GetOwner()
	if not IsValid(owner) then
		self:DrawModel()
		return
	end

	local bone = owner:LookupBone("ValveBiped.Bip01_R_Hand")
	if not bone then return end

	local m = owner:GetBoneMatrix(bone)
	if not m then return end

	local pos, ang = m:GetTranslation(), m:GetAngles()
	ang:RotateAroundAxis(ang:Right(), self.WMOffsetAng.x)
	ang:RotateAroundAxis(ang:Forward(), self.WMOffsetAng.y)
	ang:RotateAroundAxis(ang:Up(), self.WMOffsetAng.z)

	pos = pos + ang:Right() * self.WMOffsetPos.x + ang:Forward() * self.WMOffsetPos.y + ang:Up() * self.WMOffsetPos.z

	self:SetRenderOrigin(pos)
	self:SetRenderAngles(ang)
	self:DrawModel()
end

if CLIENT then
	local iconPath = "models/w_models/nh2_gmn"
	SWEP.WepSelectIcon = surface.GetTextureID(iconPath)
	killicon.Add("weapon_hg_bandage", iconPath, Color(255, 255, 255, 255))
	SWEP.BounceWeaponIcon = false

    -- first-person offset
    function SWEP:CalcViewModelView(vm, oldPos, oldAng, pos, ang)
        local p = pos + ang:Right() * self.VMOffsetPos.x + ang:Forward() * self.VMOffsetPos.y + ang:Up() * self.VMOffsetPos.z
        local a = Angle(ang)
        a:RotateAroundAxis(a:Right(), self.VMOffsetAng.x)
        a:RotateAroundAxis(a:Forward(), self.VMOffsetAng.y)
        a:RotateAroundAxis(a:Up(), self.VMOffsetAng.z)
        return p, a
    end

	local function DrawCenteredBar(x, y, w, h, frac, bg, fg)
		surface.SetDrawColor(bg.r, bg.g, bg.b, bg.a)
		surface.DrawRect(x, y, w, h)
		surface.SetDrawColor(fg.r, fg.g, fg.b, fg.a)
		surface.DrawRect(x + 2, y + 2, math.floor((w - 4) * math.Clamp(frac, 0, 1)), h - 4)
		surface.SetDrawColor(255, 255, 255, 25)
		surface.DrawOutlinedRect(x, y, w, h)
	end

	function SWEP:DrawHUD()
		local uses = self.GetHGBandageUses and self:GetHGBandageUses() or BANDAGE_MAX_WOUNDS
		local frac = math.Clamp(uses / BANDAGE_MAX_WOUNDS, 0, 1)
		local sw, sh = ScrW(), ScrH()
		local barW = math.max(220, math.floor(sw * 0.2))
		local barH = 18
		local x = (sw - barW) * 0.5
		local y = sh - 80
		DrawCenteredBar(x, y, barW, barH, frac, Color(0, 0, 0, 160), Color(120, 200, 120, 220))
		draw.SimpleText("Бинт: " .. tostring(uses) .. " / " .. tostring(BANDAGE_MAX_WOUNDS), "DermaDefaultBold", sw * 0.5, y - 18, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)

		self._hgAimCrossAlpha = self._hgAimCrossAlpha or 0
		local lp = LocalPlayer()
		local tr = lp:GetEyeTrace()
		local ent = IsValid(tr.Entity) and tr.Entity or nil
		local targetPly = nil
		if IsValid(ent) and ent:GetClass() == "prop_ragdoll" then
			local owner = ent:GetNWEntity("hg_ragdoll_owner")
			if IsValid(owner) and owner:IsPlayer() then
				targetPly = owner
			end
			if not IsValid(targetPly) then
				for _, p in ipairs(player.GetAll()) do
					local rag = p:GetNWEntity("hg_ragdoll_entity")
					if IsValid(rag) and rag == ent then
						targetPly = p
						break
					end
				end
			end
		end
		local show = IsValid(targetPly)
		if show then
			local maxDist = 160
			show = lp:GetPos():DistToSqr((IsValid(ent) and ent:GetPos()) or targetPly:GetPos()) <= (maxDist * maxDist)
		end
		local targetAlpha = show and 255 or 0
		self._hgAimCrossAlpha = Lerp(FrameTime() * 8, self._hgAimCrossAlpha, targetAlpha)
		if self._hgAimCrossAlpha > 1 then
			local cx, cy = math.floor(sw * 0.5), math.floor(sh * 0.5)
			local size, thick = 8, 2
			surface.SetDrawColor(255, 255, 255, math.floor(self._hgAimCrossAlpha))
			surface.DrawRect(cx - math.floor(thick * 0.5), cy - size, thick, size * 2 + 1)
			surface.DrawRect(cx - size, cy - math.floor(thick * 0.5), size * 2 + 1, thick)
		end
	end
end


