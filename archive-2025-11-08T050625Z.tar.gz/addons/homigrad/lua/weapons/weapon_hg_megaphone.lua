AddCSLuaFile()

SWEP.Base = "weapon_base"

SWEP.PrintName = "Громко говоритель"
SWEP.Category = "Связь"
SWEP.Instructions = "Зажмите ЛКМ чтобы говорить в громко говоритель"

SWEP.Spawnable = true
SWEP.AdminSpawnable = true
SWEP.AdminOnly = false

SWEP.ViewModelFOV = 62
SWEP.ViewModel = "models/radio/c_radio.mdl"
SWEP.WorldModel = "models/radio/c_radio.mdl"
SWEP.UseHands = true

-- offsets
SWEP.VMOffsetPos = Vector(0, 0, 0)
SWEP.VMOffsetAng = Angle(0, 0, 0)
SWEP.WMOffsetPos = Vector(-3, -3, -1)
SWEP.WMOffsetAng = Angle(-50, 0, 180)

SWEP.Slot = 1
SWEP.SlotPos = 7

SWEP.DrawAmmo = false
SWEP.DrawCrosshair = false

SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = -1
SWEP.Primary.Automatic = true
SWEP.Primary.Ammo = "none"
SWEP.Primary.Delay = 0.1

SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = "none"

function SWEP:SetupDataTables()
	self:NetworkVar("Bool", 0, "IsSpeaking")
end

function SWEP:Initialize()
	self:SetHoldType("pistol")
	if SERVER then
		self:SetIsSpeaking(false)
	end
end

function SWEP:Deploy()
	self:SetHoldType("pistol")
	return true
end

function SWEP:PrimaryAttack()
	-- Эта функция вызывается при удержании ЛКМ благодаря Primary.Automatic = true
	if SERVER then
		if not self:GetIsSpeaking() then
			self:SetIsSpeaking(true)
			local owner = self:GetOwner()
			if IsValid(owner) and owner:IsPlayer() then
				owner:ChatPrint("Вы начали говорить")
				-- Увеличиваем громкость голоса для живых игроков
				self:UpdateVoiceRange()
			end
		end
	end
end

function SWEP:Think()
	if SERVER then
		local owner = self:GetOwner()
		if not IsValid(owner) or not owner:IsPlayer() then return end
		
		local isHolding = owner:KeyDown(IN_ATTACK) and self == owner:GetActiveWeapon()
		
		if isHolding and not self:GetIsSpeaking() then
			self:SetIsSpeaking(true)
			owner:ChatPrint("Вы начали говорить")
			self:UpdateVoiceRange()
		elseif not isHolding and self:GetIsSpeaking() then
			self:SetIsSpeaking(false)
			owner:ChatPrint("Вы перестали говорить")
			self:RestoreVoiceRange()
		end
		
		-- Обновляем громкость для слушателей каждый тик
		if self:GetIsSpeaking() then
			self:UpdateVoiceRange()
		end
	end
end

function SWEP:UpdateVoiceRange()
	if not SERVER then return end
	
	local owner = self:GetOwner()
	if not IsValid(owner) or not owner:IsPlayer() then return end
	
	-- Устанавливаем сетевую переменную, чтобы клиенты знали, что этот игрок говорит через мегафон
	owner:SetNWBool("HG_MegaphoneSpeaking", true)
end

function SWEP:RestoreVoiceRange()
	if not SERVER then return end
	
	local owner = self:GetOwner()
	if not IsValid(owner) or not owner:IsPlayer() then return end
	
	-- Убираем сетевую переменную
	owner:SetNWBool("HG_MegaphoneSpeaking", false)
end

function SWEP:Holster()
	if SERVER then
		if self:GetIsSpeaking() then
			local owner = self:GetOwner()
			if IsValid(owner) and owner:IsPlayer() then
				owner:ChatPrint("Вы перестали говорить")
			end
			self:SetIsSpeaking(false)
			self:RestoreVoiceRange()
		end
	end
	return true
end

function SWEP:OnRemove()
	if SERVER then
		if self:GetIsSpeaking() then
			self:RestoreVoiceRange()
		end
	end
end

-- third-person (worldmodel) offset in owner's hand
function SWEP:DrawWorldModel()
	local owner = self:GetOwner()
	if not IsValid(owner) then
		self:DrawModel()
		return
	end

	local bone = owner:LookupBone("ValveBiped.Bip01_R_Hand")
	if not bone then return end

	local m = owner:GetBoneMatrix(bone)
	if not m then return end

	local pos, ang = m:GetTranslation(), m:GetAngles()
	ang:RotateAroundAxis(ang:Right(), self.WMOffsetAng.x)
	ang:RotateAroundAxis(ang:Forward(), self.WMOffsetAng.y)
	ang:RotateAroundAxis(ang:Up(), self.WMOffsetAng.z)

	pos = pos + ang:Right() * self.WMOffsetPos.x + ang:Forward() * self.WMOffsetPos.y + ang:Up() * self.WMOffsetPos.z

	self:SetRenderOrigin(pos)
	self:SetRenderAngles(ang)
	self:DrawModel()
end

if CLIENT then
	-- first-person offset
	function SWEP:CalcViewModelView(vm, oldPos, oldAng, pos, ang)
		local p = pos + ang:Right() * self.VMOffsetPos.x + ang:Forward() * self.VMOffsetPos.y + ang:Up() * self.VMOffsetPos.z
		local a = Angle(ang)
		a:RotateAroundAxis(a:Right(), self.VMOffsetAng.x)
		a:RotateAroundAxis(a:Forward(), self.VMOffsetAng.y)
		a:RotateAroundAxis(a:Up(), self.VMOffsetAng.z)
		return p, a
	end

	function SWEP:DrawHUD()
		if self:GetIsSpeaking() then
			local sw, sh = ScrW(), ScrH()
			draw.SimpleText("ГОВОРИТЕ В ГРОМКО ГОВОРИТЕЛЬ", "DermaDefaultBold", sw * 0.5, sh - 100, Color(255, 200, 0, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end
	
	-- Хук для изменения громкости голоса игроков с мегафоном
	hook.Add("PlayerStartVoice", "HG_MegaphoneVoice", function(ply)
		if not IsValid(ply) then return end
		local listener = LocalPlayer()
		if not IsValid(listener) then return end
		
		-- Если игрок говорит через мегафон и слушатель жив - увеличиваем громкость
		if ply:GetNWBool("HG_MegaphoneSpeaking", false) and listener:Alive() then
			ply:SetVoiceVolumeScale(3.0)
		else
			ply:SetVoiceVolumeScale(1.0)
		end
	end)
	
	-- Обновляем громкость в реальном времени
	hook.Add("Think", "HG_MegaphoneVoiceUpdate", function()
		local listener = LocalPlayer()
		if not IsValid(listener) or not listener:Alive() then return end
		
		for _, ply in ipairs(player.GetAll()) do
			if IsValid(ply) and ply:IsPlayer() and ply ~= listener then
				if ply:GetNWBool("HG_MegaphoneSpeaking", false) and ply:IsSpeaking() then
					ply:SetVoiceVolumeScale(3.0)
				elseif not ply:GetNWBool("HG_MegaphoneSpeaking", false) then
					ply:SetVoiceVolumeScale(1.0)
				end
			end
		end
	end)
end

