TOOL.Category = "Homigrad"
TOOL.Name = "Loot Pointer"
TOOL.Command = nil
TOOL.ConfigName = ""

if CLIENT then
    language.Add("tool.hg_loot_pointer.name", "Loot Pointer")
    language.Add("tool.hg_loot_pointer.desc", "Установка точек спавна кейсов лута для Homicide")
    language.Add("tool.hg_loot_pointer.0", "ЛКМ — добавить точку, ПКМ — удалить ближайшую, R — сменить тип")

    local ghost
    local modelByType = {
        melee = "models/kali/props/cases/hard case c.mdl",
        guns  = "models/kali/props/cases/rifle case b.mdl",
        med   = "models/kali/props/cases/hard case b.mdl"
    }

    -- Cached points and clientside ghosts for already placed cases
    local lootPoints
    local lastRequest = 0
    local placedGhosts = { melee = {}, guns = {}, med = {} }

    local function clearPlacedGhosts()
        for _, list in pairs(placedGhosts) do
            for i = #list, 1, -1 do
                local ent = list[i]
                if IsValid(ent) then ent:Remove() end
                table.remove(list, i)
            end
        end
    end

    local function rebuildPlacedGhosts()
        clearPlacedGhosts()
        if not lootPoints then return end
        for tt, pts in pairs(lootPoints) do
            local mdl = modelByType[tt]
            if mdl and istable(pts) then
                for _, p in ipairs(pts) do
                    local ghost = ClientsideModel(mdl, RENDERGROUP_TRANSLUCENT)
                    if IsValid(ghost) then
                        ghost:SetNoDraw(true)
                        ghost:SetRenderMode(RENDERMODE_TRANSCOLOR)
                        ghost:SetColor(Color(255,255,255,110))
                        ghost.__hg_pos = Vector(p.x, p.y, p.z)
                        ghost.__hg_ang = Angle(p.p or 0, p.yw or 0, p.r or 0)
                        table.insert(placedGhosts[tt], ghost)
                    end
                end
            end
        end
    end

    net.Receive("HG_LootSpawns_Points", function()
        lootPoints = net.ReadTable() or { melee = {}, guns = {}, med = {} }
        rebuildPlacedGhosts()
    end)

    local function ensureGhost(mdl)
        if not IsValid(ghost) or ghost:GetModel() ~= mdl then
            if IsValid(ghost) then ghost:Remove() end
            ghost = ClientsideModel(mdl, RENDERGROUP_TRANSLUCENT)
            if IsValid(ghost) then
                ghost:SetNoDraw(true)
                ghost:SetRenderMode(RENDERMODE_TRANSCOLOR)
                ghost:SetColor(Color(255, 255, 255, 120))
            end
        end
    end

    local function removeGhost()
        if IsValid(ghost) then ghost:Remove() end
        ghost = nil
    end

    hook.Add("PostDrawTranslucentRenderables", "HG_LootPointer_Preview", function()
        local ply = LocalPlayer()
        if not IsValid(ply) then removeGhost() clearPlacedGhosts() return end
        -- Must be holding ToolGun with Loot Pointer selected
        local wep = ply.GetActiveWeapon and ply:GetActiveWeapon() or nil
        if not IsValid(wep) or wep:GetClass() ~= "gmod_tool" then removeGhost() clearPlacedGhosts() return end
        local mode = (wep.GetMode and wep:GetMode()) or wep.Mode
        if mode ~= "hg_loot_pointer" then removeGhost() clearPlacedGhosts() return end
        if not ply:IsSuperAdmin() then removeGhost() clearPlacedGhosts() return end

        local tr = util.GetPlayerTrace(ply)
        tr = util.TraceLine(tr)
        if not tr.Hit then removeGhost() return end

        local t = GetConVar("hg_loot_pointer_type") and GetConVar("hg_loot_pointer_type"):GetString() or "melee"
        local mdl = modelByType[t] or modelByType.melee
        ensureGhost(mdl)
        if not IsValid(ghost) then return end

        local pos = tr.HitPos
        local ang = Angle(0, ply:EyeAngles().y, 0)
        ghost:SetPos(pos)
        ghost:SetAngles(ang)
        ghost:DrawModel()

        -- Request points periodically while tool is active
        if (not lootPoints or CurTime() - lastRequest > 5) then
            net.Start("HG_LootSpawns_Points")
            net.SendToServer()
            lastRequest = CurTime()
        end

        -- Draw semi-transparent ghost props for all saved points
        for tt, list in pairs(placedGhosts) do
            for _, g in ipairs(list) do
                if IsValid(g) then
                    if g.__hg_pos then g:SetPos(g.__hg_pos) end
                    if g.__hg_ang then g:SetAngles(g.__hg_ang) end
                    g:DrawModel()
                end
            end
        end
    end)

    hook.Add("OnCleanupMap", "HG_LootPointer_PreviewCleanup", function()
        removeGhost()
        clearPlacedGhosts()
    end)

    -- Add halos to existing spawned loot case entities when holding the tool
    hook.Add("PreDrawHalos", "HG_LootPointer_Halos", function()
        local ply = LocalPlayer()
        if not IsValid(ply) then return end
        local wep = ply.GetActiveWeapon and ply:GetActiveWeapon() or nil
        if not IsValid(wep) or wep:GetClass() ~= "gmod_tool" then return end
        local mode = (wep.GetMode and wep:GetMode()) or wep.Mode
        if mode ~= "hg_loot_pointer" then return end
        if not ply:IsSuperAdmin() then return end

        local all = {}
        for _, cls in ipairs({"hg_loot_case_melee", "hg_loot_case_guns", "hg_loot_case_med"}) do
            for _, ent in ipairs(ents.FindByClass(cls)) do
                if IsValid(ent) then table.insert(all, ent) end
            end
        end
        if #all > 0 then
            halo.Add(all, Color(255, 215, 0), 2, 2, 1, true, true)
        end
    end)
end

TOOL.ClientConVar["type"] = "melee" -- melee, guns, med

local TYPES = { melee = true, guns = true, med = true }

local function cycleType(cur)
    if cur == "melee" then return "guns" end
    if cur == "guns" then return "med" end
    return "melee"
end

function TOOL:Allowed()
    local ply = self:GetOwner()
    return IsValid(ply) and ply:IsSuperAdmin()
end

function TOOL:LeftClick(trace)
    if not self:Allowed() then return false end
    if CLIENT then return true end
    local t = self:GetClientInfo("type") or "melee"
    if not TYPES[t] then t = "melee" end
    local pos = trace.HitPos
    local ang = Angle(0, self:GetOwner():EyeAngles().y, 0)
    if HG_LootSpawns and HG_LootSpawns.AddPoint then
        HG_LootSpawns.AddPoint(t, pos, ang)
        self:GetOwner():ChatPrint("[Loot] Добавлена точка: " .. t)
        return true
    end
    return false
end

function TOOL:RightClick(trace)
    if not self:Allowed() then return false end
    if CLIENT then return true end
    local t = self:GetClientInfo("type") or "melee"
    if not TYPES[t] then t = "melee" end
    local pos = trace.HitPos
    if HG_LootSpawns and HG_LootSpawns.RemoveNearest then
        local ok = HG_LootSpawns.RemoveNearest(t, pos, 128)
        if ok then
            self:GetOwner():ChatPrint("[Loot] Удалена ближайшая точка: " .. t)
        else
            self:GetOwner():ChatPrint("[Loot] Рядом точек не найдено: " .. t)
        end
        return ok
    end
    return false
end

function TOOL:Reload(trace)
    if not self:Allowed() then return false end
    if CLIENT then return true end
    local cur = self:GetClientInfo("type") or "melee"
    local nxt = cycleType(cur)
    self:GetOwner():ConCommand("hg_loot_pointer_type " .. nxt)
    self:GetOwner():ChatPrint("[Loot] Тип: " .. nxt)
    return true
end

function TOOL.BuildCPanel(panel)
    panel:AddControl("Header", { Description = "Кейсы спавнятся только в режиме Homicide в начале раунда" })
    local cb = vgui.Create("DComboBox", panel)
    cb:Dock(TOP)
    cb:SetValue("Тип: melee")
    cb:AddChoice("melee")
    cb:AddChoice("guns")
    cb:AddChoice("med")
    cb.OnSelect = function(_, _, val)
        RunConsoleCommand("hg_loot_pointer_type", val)
    end
    panel:AddItem(cb)
    local btn = vgui.Create("DButton", panel)
    btn:Dock(TOP)
    btn:SetText("Заспавнить кейсы (Homicide)")
    btn.DoClick = function() RunConsoleCommand("hg_loot_spawn_homicide") end
    panel:AddItem(btn)
end
