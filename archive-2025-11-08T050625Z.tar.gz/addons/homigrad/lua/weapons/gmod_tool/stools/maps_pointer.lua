TOOL.Category = "Homigrad"
TOOL.Name = "Map Pointer"
TOOL.Command = nil
TOOL.ConfigName = ""

if CLIENT then
	TOOL.Information = {
		{ name = "left" },
		{ name = "right" },
		{ name = "reload" }
	}

	language.Add("tool.maps_pointer.name", "Map Pointer")
	language.Add("tool.maps_pointer.desc", "Place spawn points on the map")
	language.Add("tool.maps_pointer.left", "Place spawn point")
	language.Add("tool.maps_pointer.right", "Remove spawn point")
	language.Add("tool.maps_pointer.reload", "Change spawn type")
end

TOOL.ClientConVar["spawntype"] = "dm"

if CLIENT then
	-- Types available
	local spawnTypes = { "rebels", "police", "homicide", "dm", "tdm_swat", "tdm_terrorists", "jb_guards", "jb_prisoners", "event", "school_victims", "school_shooters", "school_police" }
	local spawnTypeLabels = {
		rebels = "Rioters",
		police = "Police",
		homicide = "Homicide",
		dm = "Deathmatch",
		tdm_swat = "TDM SWAT",
		tdm_terrorists = "TDM Terrorists",
		jb_guards = "JB Guards",
		jb_prisoners = "JB Prisoners",
		event = "Event",
		school_victims = "School Victims",
		school_shooters = "School Shooters",
		school_police = "School Police"
	}

	function TOOL:BuildCPanel()
		if not LocalPlayer():IsSuperAdmin() then return end
		self:AddControl("Header", { Description = "#tool.maps_pointer.desc" })
		
		local options = {}
		for _, typ in ipairs(spawnTypes) do
			local label = spawnTypeLabels[typ] or typ
			options[label] = { maps_pointer_spawntype = typ }
		end
		
		self:AddControl("ComboBox", {
			Label = "Spawn Type",
			Options = options
		})
	end

	-- Preview sphere
	hook.Add("PostDrawTranslucentRenderables", "MapsPointer_Preview", function()
		local ply = LocalPlayer()
		if not IsValid(ply) then return end
		if not ply:GetTool("maps_pointer") then return end
		if not ply:IsSuperAdmin() then return end

		local tr = util.GetPlayerTrace(ply)
		tr = util.TraceLine(tr)
		if not tr.Hit then return end

		local pos = tr.HitPos
		local spawntype = GetConVar("maps_pointer_spawntype"):GetString()
		
		local colorByType = {
			police = Color(60,120,255,80),
			rebels = Color(255,80,80,80),
			homicide = Color(255,215,0,80),
			dm = Color(255,255,255,80),
			tdm_swat = Color(0,185,255,80),
			tdm_terrorists = Color(255,0,0,80),
			jb_guards = Color(60,100,200,80),
			jb_prisoners = Color(255,100,10,80),
			event = Color(242,0,255,80),
			school_victims = Color(0,255,29,80),
			school_shooters = Color(255,0,0,80),
			school_police = Color(16,0,255,80)
		}
		local col = colorByType[spawntype] or Color(255,255,255,80)

		render.SetColorMaterial()
		render.DrawSphere(pos, 8, 16, 16, col)
	end)
end

function TOOL:LeftClick(trace)
	if not IsValid(trace.Entity) and trace.HitWorld then
		if CLIENT then 
			surface.PlaySound("buttons/button15.wav")
			return true 
		end

		if not self:GetOwner():IsSuperAdmin() then
			return false
		end

		local pos = trace.HitPos
		local spawntype = self:GetClientInfo("spawntype") or "dm"

		local ent = ents.Create("homigrad_spawnpoint")
		if not IsValid(ent) then return false end
		ent:SetPos(pos)
		ent:Spawn()
		ent:SetSpawnType(spawntype)

		undo.Create("Spawn Point")
			undo.AddEntity(ent)
			undo.SetPlayer(self:GetOwner())
		undo.Finish()

		return true
	end

	return false
end

function TOOL:RightClick(trace)
	if CLIENT then 
		surface.PlaySound("buttons/button15.wav")
		return true 
	end

	if not self:GetOwner():IsSuperAdmin() then
		return false
	end

	local pos = trace.HitPos
	local rad = 32
	local closest, best = nil, math.huge

	for _, ent in ipairs(ents.FindByClass("homigrad_spawnpoint")) do
		if IsValid(ent) then
			local d = ent:GetPos():DistToSqr(pos)
			if d < best and d <= (rad * rad) then
				best = d
				closest = ent
			end
		end
	end

	if IsValid(closest) then
		closest:Remove()
		return true
	end

	return false
end

function TOOL:Reload(trace)
	if CLIENT then
		-- Cycle spawn type on client
		local spawnTypes = { "rebels", "police", "homicide", "dm", "tdm_swat", "tdm_terrorists", "jb_guards", "jb_prisoners", "event", "school_victims", "school_shooters", "school_police" }
		local current = GetConVar("maps_pointer_spawntype"):GetString() or "dm"
		local currentIndex = 1

		for i, typ in ipairs(spawnTypes) do
			if typ == current then
				currentIndex = i
				break
			end
		end

		local nextIndex = (currentIndex % #spawnTypes) + 1
		RunConsoleCommand("maps_pointer_spawntype", spawnTypes[nextIndex])
		
		local nextType = spawnTypes[nextIndex]
		local label = spawnTypeLabels and spawnTypeLabels[nextType] or nextType
		surface.PlaySound("buttons/lightswitch2.wav")
		notification.AddProgress("maps_pointer_type", "Spawn Type: " .. label)
		timer.Simple(2, function()
			notification.Kill("maps_pointer_type")
		end)
		
		return true
	end

	if not self:GetOwner():IsSuperAdmin() then
		return false
	end

	return true
end
