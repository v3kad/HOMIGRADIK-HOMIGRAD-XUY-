AddCSLuaFile()

SWEP.Base = "weapon_base"

SWEP.PrintName = "Обезболивающее"
SWEP.Category = "Медицина"
SWEP.Instructions = "ЛКМ: снизить боль на 10."

SWEP.Spawnable = true
SWEP.AdminSpawnable = true
SWEP.AdminOnly = false

SWEP.ViewModelFOV = 62
SWEP.ViewModel = "models/painkillers.mdl"
SWEP.WorldModel = "models/painkillers.mdl"
SWEP.UseHands = true

-- offsets
SWEP.VMOffsetPos = Vector(0, 0, 0)
SWEP.VMOffsetAng = Angle(0, 0, 0)
SWEP.WMOffsetPos = Vector(-2.8, 3, -1)
SWEP.WMOffsetAng = Angle(200, 0, 180)

SWEP.Slot = 1
SWEP.SlotPos = 6

SWEP.DrawAmmo = false
SWEP.DrawCrosshair = false

SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = -1
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "none"
SWEP.Primary.Delay = 1.0

SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = "none"

if CLIENT then
    SWEP.WepSelectIcon = surface.GetTextureID("vgui/wep_jack_hmcd_painpills")
    SWEP.BounceWeaponIcon = false
end

local PAIN_REDUCTION = 10

function SWEP:Initialize()
	self:SetHoldType("slam")
end

function SWEP:Deploy()
	self:SetHoldType("slam")
	return true
end

function SWEP:PrimaryAttack()
	if self:GetNextPrimaryFire() > CurTime() then return end
	self:SetNextPrimaryFire(CurTime() + self.Primary.Delay)

	if not IsValid(self:GetOwner()) then return end
	local owner = self:GetOwner()
	if not owner:IsPlayer() then return end

	if SERVER then
		local curPain = owner.GetHGPain and owner:GetHGPain() or 0
		if curPain <= 0 then
			owner:ChatPrint("Боль отсутствует.")
			return
		end

		local newPain = math.max(0, curPain - PAIN_REDUCTION)
		owner:SetHGPain(newPain)
		owner:EmitSound("items/medshot4.wav", 65, 100)
		owner:ChatPrint("Боль уменьшена на " .. tostring(math.min(PAIN_REDUCTION, curPain)) .. ".")

		owner:StripWeapon(self:GetClass())
	end
end

function SWEP:SecondaryAttack()
	if self.GetNextSecondaryFire and self:GetNextSecondaryFire() > CurTime() then return end
	if self.SetNextSecondaryFire then self:SetNextSecondaryFire(CurTime() + (self.Primary and self.Primary.Delay or 1)) end

	if not IsValid(self:GetOwner()) then return end
	local owner = self:GetOwner()
	if not owner:IsPlayer() then return end

	if SERVER then
		-- find target by eye trace, allow ragdoll owner
		local tr = owner:GetEyeTrace()
		local ent = IsValid(tr.Entity) and tr.Entity or nil
		local target = nil
		if IsValid(ent) then
			if ent:IsPlayer() then
				target = ent
			elseif ent:GetClass() == "prop_ragdoll" then
				local ragOwner = ent:GetNWEntity("hg_ragdoll_owner")
				if IsValid(ragOwner) and ragOwner:IsPlayer() then
					target = ragOwner
				end
				if not IsValid(target) then
					for _, p in ipairs(player.GetAll()) do
						local rag = p:GetNWEntity("hg_ragdoll_entity")
						if IsValid(rag) and rag == ent then
							target = p
							break
						end
					end
				end
			end
		end

		if not IsValid(target) or target == owner then return end

		-- distance check
		local maxDist = 160
		if owner:GetPos():DistToSqr(target:GetPos()) > (maxDist * maxDist) then return end

		local curPain = target.GetHGPain and target:GetHGPain() or 0
		if curPain <= 0 then
			owner:ChatPrint("У игрока нет боли.")
			return
		end

		local reduced = math.min(PAIN_REDUCTION, curPain)
		local newPain = math.max(0, curPain - PAIN_REDUCTION)
		target:SetHGPain(newPain)
		target:EmitSound("items/medshot4.wav", 65, 100)
		owner:ChatPrint("Вы снизили боль игрока на " .. tostring(reduced) .. ".")

		owner:StripWeapon(self:GetClass())
	end
end

-- third-person (worldmodel) offset in owner's hand
function SWEP:DrawWorldModel()
	local owner = self:GetOwner()
	if not IsValid(owner) then
		self:DrawModel()
		return
	end

	local bone = owner:LookupBone("ValveBiped.Bip01_R_Hand")
	if not bone then return end

	local m = owner:GetBoneMatrix(bone)
	if not m then return end

	local pos, ang = m:GetTranslation(), m:GetAngles()
	ang:RotateAroundAxis(ang:Right(), self.WMOffsetAng.x)
	ang:RotateAroundAxis(ang:Forward(), self.WMOffsetAng.y)
	ang:RotateAroundAxis(ang:Up(), self.WMOffsetAng.z)

	pos = pos + ang:Right() * self.WMOffsetPos.x + ang:Forward() * self.WMOffsetPos.y + ang:Up() * self.WMOffsetPos.z

	self:SetRenderOrigin(pos)
	self:SetRenderAngles(ang)
	self:DrawModel()
end

if CLIENT then
	local iconPath = "models/w_models/eq_painpills"
	SWEP.WepSelectIcon = surface.GetTextureID(iconPath)
	killicon.Add("weapon_hg_painkiller", iconPath, Color(255, 255, 255, 255))
	SWEP.BounceWeaponIcon = false

	-- first-person offset
	function SWEP:CalcViewModelView(vm, oldPos, oldAng, pos, ang)
		local p = pos + ang:Right() * self.VMOffsetPos.x + ang:Forward() * self.VMOffsetPos.y + ang:Up() * self.VMOffsetPos.z
		local a = Angle(ang)
		a:RotateAroundAxis(a:Right(), self.VMOffsetAng.x)
		a:RotateAroundAxis(a:Forward(), self.VMOffsetAng.y)
		a:RotateAroundAxis(a:Up(), self.VMOffsetAng.z)
		return p, a
	end

	function SWEP:DrawHUD()
		self._hgAimCrossAlpha = self._hgAimCrossAlpha or 0
		local lp = LocalPlayer()
		local tr = lp:GetEyeTrace()
		local ent = IsValid(tr.Entity) and tr.Entity or nil
		local targetPly = nil
		if IsValid(ent) and ent:GetClass() == "prop_ragdoll" then
			local owner = ent:GetNWEntity("hg_ragdoll_owner")
			if IsValid(owner) and owner:IsPlayer() then
				targetPly = owner
			end
			if not IsValid(targetPly) then
				for _, p in ipairs(player.GetAll()) do
					local rag = p:GetNWEntity("hg_ragdoll_entity")
					if IsValid(rag) and rag == ent then
						targetPly = p
						break
					end
				end
			end
		end
		local show = IsValid(targetPly)
		if show then
			local maxDist = 160
			show = lp:GetPos():DistToSqr((IsValid(ent) and ent:GetPos()) or targetPly:GetPos()) <= (maxDist * maxDist)
		end
		local targetAlpha = show and 255 or 0
		self._hgAimCrossAlpha = Lerp(FrameTime() * 8, self._hgAimCrossAlpha, targetAlpha)
		if self._hgAimCrossAlpha > 1 then
			local sw, sh = ScrW(), ScrH()
			local cx, cy = math.floor(sw * 0.5), math.floor(sh * 0.5)
			local size, thick = 8, 2
			surface.SetDrawColor(255, 255, 255, math.floor(self._hgAimCrossAlpha))
			surface.DrawRect(cx - math.floor(thick * 0.5), cy - size, thick, size * 2 + 1)
			surface.DrawRect(cx - size, cy - math.floor(thick * 0.5), size * 2 + 1, thick)
		end
	end
end





