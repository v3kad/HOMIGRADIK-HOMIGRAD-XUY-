SWEP.PrintName = "База ближнего боя"
SWEP.Category = "Ближний Бой"
SWEP.Spawnable = false
SWEP.AdminSpawnable = false
SWEP.AdminOnly = false

SWEP.ViewModelFOV = 60
SWEP.ViewModel = "models/weapons/v_knife_t.mdl"
SWEP.WorldModel = "models/weapons/w_knife_t.mdl"
SWEP.ViewModelFlip = false

SWEP.AutoSwitchTo = false
SWEP.AutoSwitchFrom = false

SWEP.Slot = 1
SWEP.SlotPos = 2

SWEP.UseHands = true
SWEP.FiresUnderwater = false
SWEP.DrawCrosshair = false
SWEP.DrawAmmo = true

SWEP.Base = "weapon_base"

SWEP.Primary.Damage = 25
SWEP.Primary.Ammo = "none"
SWEP.Primary.DefaultClip = -1
SWEP.Primary.Automatic = true
SWEP.Primary.Recoil = 0.5
SWEP.Primary.Delay = 0.8
SWEP.Primary.Force = 1000

SWEP.Secondary.ClipSize = 0
SWEP.Secondary.DefaultClip = 0
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = "none"

SWEP.DrawSound = "weapons/knife/knife_deploy1.wav"
SWEP.HitSound = "weapons/knife/knife_hitwall1.wav"
SWEP.FlashHitSound = "weapons/knife/knife_hit1.wav"
SWEP.ShouldDecal = true
SWEP.HoldTypeWep = "knife"
SWEP.DamageType = DMG_SLASH

function SWEP:Initialize()
    self:SetHoldType(self.HoldTypeWep)
end

function SWEP:Deploy()
    self:SetNextPrimaryFire(CurTime() + 0.5)
    if SERVER then
        self:GetOwner():EmitSound(self.DrawSound)
    end
    return true
end

function SWEP:PrimaryAttack()
    self:SetNextPrimaryFire(CurTime() + self.Primary.Delay)
    self:GetOwner():SetAnimation(PLAYER_ATTACK1)
    
    if CLIENT then return end
    
    -- Простой трейсинг
    local ply = self:GetOwner()
    local trace = {}
    trace.start = ply:GetShootPos()
    trace.endpos = trace.start + ply:GetAimVector() * 70
    trace.filter = ply
    trace.mins = Vector(-16, -16, -16)
    trace.maxs = Vector(16, 16, 16)
    
    local tr = util.TraceHull(trace)
    
    if not tr.Hit then return end
    
    if IsValid(tr.Entity) then
        -- Наносим урон entity
        local dmginfo = DamageInfo()
        dmginfo:SetDamage(self.Primary.Damage)
        dmginfo:SetAttacker(ply)
        dmginfo:SetInflictor(self)
        dmginfo:SetDamageType(self.DamageType)
        dmginfo:SetDamageForce(ply:GetAimVector() * self.Primary.Force)
        dmginfo:SetDamagePosition(tr.HitPos)
        
        tr.Entity:TakeDamageInfo(dmginfo)
        
        -- Звук попадания по entity
        if tr.Entity:IsPlayer() or tr.Entity:IsNPC() or tr.Entity:GetClass() == "prop_ragdoll" then
            self:GetOwner():EmitSound(self.FlashHitSound)
        else
            self:GetOwner():EmitSound(self.HitSound)
        end
    else
        -- Попадание в мир
        self:GetOwner():EmitSound(self.HitSound)
    end
    
    -- Декали
    if self.ShouldDecal then
        if tr.Entity:IsPlayer() or tr.Entity:IsNPC() or tr.Entity:GetClass() == "prop_ragdoll" then
            util.Decal("Blood", tr.HitPos + tr.HitNormal, tr.HitPos - tr.HitNormal)
        else
            util.Decal("Impact.Concrete", tr.HitPos + tr.HitNormal, tr.HitPos - tr.HitNormal)
        end
    end
end

function SWEP:SecondaryAttack()
    -- Заглушка для вторичной атаки
    self:SetNextSecondaryFire(CurTime() + 1)
end

function SWEP:DrawHUD()
    -- Упрощенный HUD (можно убрать если мешает)
    if not IsValid(self:GetOwner()) or self:GetOwner() ~= LocalPlayer() then return end
    
    local tr = util.TraceLine({
        start = self:GetOwner():GetShootPos(),
        endpos = self:GetOwner():GetShootPos() + self:GetOwner():GetAimVector() * 70,
        filter = self:GetOwner()
    })
    
    if tr.Hit then
        local pos = tr.HitPos:ToScreen()
        surface.SetDrawColor(255, 255, 255, 255)
        surface.DrawCircle(pos.x, pos.y, 10, 255, 255, 255, 255)
    end
end

function SWEP:Holster()
    return true
end

function SWEP:Reload()
    return false
end

function SWEP:Think()
end