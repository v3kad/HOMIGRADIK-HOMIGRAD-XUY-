AddCSLuaFile()
ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Fast Ops Helmet"
ENT.Category = "HG Armor"
ENT.Spawnable = true
ENT.AdminSpawnable = false
ENT.IconOverride = "entities/ent_jack_gmod_ezarmor_tackekfastmt.png"

if SERVER then
    function ENT:Initialize()
        self:SetModel("models/eft_props/gear/helmets/helmet_ops_core_fast_tan.mdl")
        self:PhysicsInit(SOLID_VPHYSICS)
        self:SetMoveType(MOVETYPE_VPHYSICS)
        self:SetSolid(SOLID_VPHYSICS)
        local phys = self:GetPhysicsObject()
        if IsValid(phys) then phys:Wake() end
        self:SetUseType(SIMPLE_USE)
    end

    function ENT:Use(ply)
        if not IsValid(ply) or not ply:IsPlayer() then return end
        if HG_EquipHelmet and HG_EquipHelmet(ply, "fast_ops") then
            self:Remove()
        end
    end
end
