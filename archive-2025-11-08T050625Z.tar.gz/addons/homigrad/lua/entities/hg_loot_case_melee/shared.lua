AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "HG Loot Case (Melee)"
ENT.Category = "Homigrad"
ENT.Spawnable = false
ENT.RenderGroup = RENDERGROUP_OPAQUE
