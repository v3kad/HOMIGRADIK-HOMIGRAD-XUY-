AddCSLuaFile()
ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "6B47 Cover Helmet"
ENT.Category = "HG Armor"
ENT.Spawnable = true
ENT.AdminSpawnable = false
ENT.IconOverride = "materials/entities/ent_jack_gmod_ezarmor_6b47chehol.png"

if SERVER then
    function ENT:Initialize()
        self:SetModel("models/eft_props/gear/helmets/helmet_6b47_cover.mdl")
        self:PhysicsInit(SOLID_VPHYSICS)
        self:SetMoveType(MOVETYPE_VPHYSICS)
        self:SetSolid(SOLID_VPHYSICS)
        local phys = self:GetPhysicsObject()
        if IsValid(phys) then phys:Wake() end
        self:SetUseType(SIMPLE_USE)
    end

    function ENT:Use(ply)
        if not IsValid(ply) or not ply:IsPlayer() then return end
        if HG_EquipHelmet and HG_EquipHelmet(ply, "helm_6b47_cover") then
            self:Remove()
        end
    end
end
