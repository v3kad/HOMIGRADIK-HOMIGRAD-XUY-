include("shared.lua")

local colorByType = {
	police = Color(60,120,255,200),
	rebels = Color(255,80,80,200),
	homicide = Color(255,215,0,200),
	dm = Color(255,255,255,200),
	tdm_swat = Color(0,185,255,200),
	tdm_terrorists = Color(255,0,0,200),
	jb_guards = Color(60,100,200,200),
	jb_prisoners = Color(255,100,10,200),
	event = Color(242,0,255,200)
}

local spawnTypeLabels = {
	rebels = "Rioters",
	police = "Police",
	homicide = "Homicide",
	dm = "Deathmatch",
	tdm_swat = "TDM SWAT",
	tdm_terrorists = "TDM Terrorists",
	jb_guards = "JB Guards",
	jb_prisoners = "JB Prisoners",
	event = "Event"
}

function ENT:Draw()
    local lp = LocalPlayer()
    if not IsValid(lp) then return end
    local wep = lp:GetActiveWeapon()
    if not IsValid(wep) or wep:GetClass() ~= "gmod_tool" then return end
    if not wep.GetMode or wep:GetMode() ~= "maps_pointer" then return end

	local pos = self:GetPos()
	local ang = LocalPlayer():EyeAngles()
	ang:RotateAroundAxis(ang:Right(), 90)
	ang:RotateAroundAxis(ang:Up(), -90)

	render.SetColorMaterial()
	local t = string.lower(self:GetSpawnType() or "")
	local col = colorByType[t] or Color(200,200,200,200)
	local label = spawnTypeLabels[t] or t
	cam.IgnoreZ(true)
	render.DrawSphere(pos, 6, 16, 16, Color(col.r, col.g, col.b, 60))
	cam.Start3D2D(pos + Vector(0,0,6), Angle(0, ang.y, 90), 0.1)
		draw.RoundedBox(4, -220, -26, 440, 52, Color(0,0,0,160))
		draw.SimpleText("Spawn: " .. label, "DermaLarge", 0, 0, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	cam.End3D2D()
	cam.IgnoreZ(false)
end

