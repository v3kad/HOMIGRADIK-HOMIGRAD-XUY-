ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Homigrad Spawn Point"
ENT.Author = "homigrad"
ENT.Spawnable = false
ENT.AdminSpawnable = false

function ENT:SetupDataTables()
	self:NetworkVar("String", 0, "SpawnType")
end



