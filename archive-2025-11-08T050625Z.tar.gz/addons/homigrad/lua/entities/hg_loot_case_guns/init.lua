AddCSLuaFile()
include("shared.lua")

ENT.Model = "models/kali/props/cases/rifle case b.mdl"

function ENT:Initialize()
    if SERVER then
        self:SetModel(self.Model)
        self:PhysicsInit(SOLID_VPHYSICS)
        self:SetMoveType(MOVETYPE_VPHYSICS)
        self:SetSolid(SOLID_VPHYSICS)
        self:SetUseType(SIMPLE_USE)
        local phys = self:GetPhysicsObject()
        if IsValid(phys) then phys:Wake() end
        self.HG_LootInventory = self.HG_LootInventory or {}
        if #self.HG_LootInventory == 0 then
            self:HG_FillDefaultLoot()
        end
    end
end

function ENT:HG_FillDefaultLoot()
    local pool = {
        {kind="weapon", class="weapon_akm", name="АКМ"},
        {kind="weapon", class="weapon_pistol", name="Пистолет"},
        {kind="ammo", caliber="7x62", amount=30, name="7x62"},
        {kind="ammo", caliber="7x62", amount=30, name="7x62"},
        {kind="ammo", caliber="9x19", amount=20, name="9x19"},
    }
    for _, it in ipairs(pool) do table.insert(self.HG_LootInventory, it) end
end

local LOOT_MAX_DIST = 80
function ENT:Use(activator)
    if not SERVER then return end
    local ply = activator
    if not IsValid(ply) or not ply:IsPlayer() then return end
    if ply:GetPos():Distance(self:GetPos()) > LOOT_MAX_DIST then return end
    net.Start("HG_Loot_Open")
        net.WriteEntity(self)
        net.WriteString("Кейс (Огнестрел)")
        net.WriteTable(self.HG_LootInventory or {})
    net.Send(ply)
    ply.HG_IsLooting = true
end

function ENT:OnTakeFromCase(ply, idx)
    if not (self.HG_LootInventory and self.HG_LootInventory[idx]) then return end
    local item = self.HG_LootInventory[idx]
    if item.kind == "weapon" and item.class then
        ply:Give(item.class)
        table.remove(self.HG_LootInventory, idx)
        if (#self.HG_LootInventory) == 0 then self:Remove() end
    elseif item.kind == "ammo" then
        local handled = false
        if HG_AddItemToPlayer then handled = HG_AddItemToPlayer(ply, item) or false end
        if not handled then
            local atype = -1
            if item.caliber == "7x62" then atype = game.GetAmmoID("ar2") elseif item.caliber == "9x19" then atype = game.GetAmmoID("pistol") end
            if atype and atype > -1 then ply:GiveAmmo(tonumber(item.amount or 0) or 0, atype, true) handled = true end
        end
        if handled then
            table.remove(self.HG_LootInventory, idx)
            if (#self.HG_LootInventory) == 0 then self:Remove() end
        end
    end
end
