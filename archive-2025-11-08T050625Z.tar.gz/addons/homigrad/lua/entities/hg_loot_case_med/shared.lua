AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "HG Loot Case (Med)"
ENT.Category = "Homigrad"
ENT.Spawnable = false
ENT.RenderGroup = RENDERGROUP_OPAQUE
