include("shared.lua")

-- clientside draw can be default; nothing special needed
