AddCSLuaFile()
AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")
include("shared.lua")

ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Ammo 9x19"
ENT.Category = "Homigrad"
ENT.Spawnable = true
ENT.RenderGroup = RENDERGROUP_OPAQUE

ENT.Model = "models/Items/BoxSRounds.mdl" -- same model as item_ammo_pistol
ENT.DefaultAmount = 20
ENT.Icon = "homigrad/ui/9x19.png"

function ENT:Initialize()
    if SERVER then
        self:SetModel(self.Model)
        self:PhysicsInit(SOLID_VPHYSICS)
        self:SetMoveType(MOVETYPE_VPHYSICS)
        self:SetSolid(SOLID_VPHYSICS)
        self:SetUseType(SIMPLE_USE)
        local phys = self:GetPhysicsObject()
        if IsValid(phys) then phys:Wake() end
        local amt = tonumber(self.AmmoAmount or self.DefaultAmount) or self.DefaultAmount
        self.AmmoAmount = math.max(1, math.floor(amt))
    end
end

function ENT:Use(activator)
    if not SERVER then return end
    local ply = activator
    if not IsValid(ply) or not ply:IsPlayer() then return end

    local item = {
        name = "Патроны 9x19",
        kind = "ammo",
        caliber = "9x19",
        amount = tonumber(self.AmmoAmount or self.DefaultAmount) or self.DefaultAmount,
        icon = self.Icon,
        entClass = "hg_ammo_9x19",
    }

    local handled = false
    if HG_AddItemToPlayer then
        handled = HG_AddItemToPlayer(ply, item) or false
    end
    if not handled then
        -- Fallback: give HL2 pistol ammo when custom inventory is unavailable
        local give = tonumber(item.amount or 0) or 0
        if give > 0 and ply.GiveAmmo then
            ply:GiveAmmo(give, "pistol", true)
            handled = true
        end
    end
    if handled then
        self:Remove()
        -- Send updated inventory snapshot
        if BuildActualInventory then
            local updated = BuildActualInventory(ply)
            net.Start("HG_Inventory_Send")
                net.WriteTable(updated)
            net.Send(ply)
        end
    end
end

-- Helper to set amount when spawned via Lua/Toolgun
function ENT:SetAmmoAmount(n)
    self.AmmoAmount = math.max(1, tonumber(n) or self.DefaultAmount)
end
