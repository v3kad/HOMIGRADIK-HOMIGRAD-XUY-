if SERVER then AddCSLuaFile() end

local inRagdoll = false
local ragdollEnt = nil
local lastPos, lastAng
local baseYaw, basePitch
-- Модель оружия на рэгдолле
local ragdollWeapon = nil
local ragdollWeaponClass = nil
-- Exponential smoothing time constants (seconds)
local POS_TAU = 0.12
local ANG_TAU = 0.10
-- Deadzones to ignore micro jitter
local POS_DEADZONE = 0.08 -- units
local ANG_DEADZONE = 0.25 -- degrees

-- Hide ragdoll head while in first-person
local headBoneNames = {
	["ValveBiped.Bip01_Head1"] = true,
	["ValveBiped.Bip01_Neck1"] = true
}
local hiddenRagBones = {}
local lastRagForRestore = nil

local function hideRagdollHead(rag)
	if not IsValid(rag) then return end
	rag:SetupBones()
	for boneId = 0, (rag:GetBoneCount() or 0) - 1 do
		local name = rag:GetBoneName(boneId)
		if name and (headBoneNames[name] or name:find("head") or name:find("Head")) then
			hiddenRagBones[boneId] = rag:GetManipulateBoneScale(boneId)
			rag:ManipulateBoneScale(boneId, Vector(0, 0, 0))
		end
	end
end

local function restoreRagdollHead(rag)
	if not IsValid(rag) then return end
	for boneId, prev in pairs(hiddenRagBones) do
		rag:ManipulateBoneScale(boneId, prev or Vector(1, 1, 1))
		hiddenRagBones[boneId] = nil
	end
end

net.Receive("hg_ragdoll_state", function()
	local wasInRagdoll = inRagdoll
	inRagdoll = net.ReadBool()
	ragdollEnt = net.ReadEntity()
	local sentAng = net.ReadAngle()
	lastPos, lastAng = nil, nil
	if inRagdoll and sentAng and isangle(sentAng) then
		baseYaw = sentAng.y
		basePitch = sentAng.p
	else
		baseYaw, basePitch = nil, nil
	end
	if not inRagdoll and IsValid(lastRagForRestore) then
		restoreRagdollHead(lastRagForRestore)
		lastRagForRestore = nil
	end
	
	-- Удаляем модель оружия при выходе из рэгдолла
	if wasInRagdoll and not inRagdoll then
		if IsValid(ragdollWeapon) then
			ragdollWeapon:Remove()
			ragdollWeapon = nil
			ragdollWeaponClass = nil
		end
	end
end)

local function getHeadPosAng(rag, _)
    if not IsValid(rag) then return nil, nil end
    local headIdx = rag:LookupBone("ValveBiped.Bip01_Head1") or 0

    -- 0) If server provided networked head transform, use it
    local nwAng = rag:GetNWAngle("hg_head_ang")
    local nwPos = rag:GetNWVector("hg_head_pos")
    if nwAng and isangle(nwAng) and nwPos and isvector(nwPos) and nwPos ~= vector_origin then
        local aim = Angle(nwAng.p, nwAng.y, nwAng.r or 0)
        local pos = nwPos + aim:Forward() * 4 + aim:Up() * 2
        return pos, aim
    end

    -- 1) Prefer physics object for live orientation
    local physIdx = rag:TranslateBoneToPhysBone(headIdx) or 0
    local phys = rag:GetPhysicsObjectNum(physIdx)
    if IsValid(phys) then
        local pang = phys:GetAngles()
        local ppos = phys:GetPos()
        if pang and ppos then
            local aim = Angle(pang.p, pang.y, pang.r)
            return ppos + aim:Forward() * 4 + aim:Up() * 2, aim
        end
    end

    -- 2) Fallback to bone matrix
    rag:SetupBones()
    local m = rag:GetBoneMatrix(headIdx)
    if m then
        local bpos = m:GetTranslation()
        local bang = m:GetAngles()
        if bpos and bang then
            local aim = Angle(bang.p, bang.y, bang.r)
            return bpos + aim:Forward() * 4 + aim:Up() * 2, aim
        end
    end

    -- 3) Last resort: simple bone position/angle
    local bpos2, bang2 = rag:GetBonePosition(headIdx)
    if bpos2 and bpos2 ~= vector_origin then
        local baseAim = EyeAngles()
        local aim = Angle((bang2 and bang2.p) or baseAim.p, (bang2 and bang2.y) or baseAim.y, 0)
        return bpos2 + aim:Forward() * 4 + aim:Up() * 2, aim
    end

    -- 4) Fallback: keep current view with a sensible origin
    local aim = EyeAngles()
    aim = Angle(aim.p, aim.y, 0)
    return rag:GetPos() + aim:Up() * 64, aim
end

local function calcViewRagdoll(ply, origin, angles, fov)
	local nwRag = IsValid(ply) and ply:GetNWEntity("hg_ragdoll_entity") or nil
	if IsValid(nwRag) then
		inRagdoll = true
		ragdollEnt = nwRag
	else
		if not inRagdoll then return end
		if not IsValid(ragdollEnt) then return end
	end
	-- Ensure ragdoll head is hidden from first person
	hideRagdollHead(ragdollEnt)
	lastRagForRestore = ragdollEnt

	local pos, ang = getHeadPosAng(ragdollEnt, angles)
	if not pos then return end
    local tr = util.TraceHull({
		start = pos,
		endpos = pos,
		mins = Vector(-2,-2,-2),
		maxs = Vector(2,2,2),
		filter = { LocalPlayer(), ragdollEnt }
	})
	if tr.Hit then
		pos = tr.HitPos + tr.HitNormal * 2
	end
    -- Use ragdoll head orientation directly (fully synchronized), no free-look clamp

	-- Re-anchor camera position to actual head point but using final view angle for forward offset
	local headPos = ragdollEnt:GetNWVector("hg_head_pos")
	if (not headPos) or (not isvector(headPos)) or headPos == vector_origin then
		local headIdx = ragdollEnt:LookupBone("ValveBiped.Bip01_Head1") or 0
		local physIdx = ragdollEnt:TranslateBoneToPhysBone(headIdx) or 0
		local phys = ragdollEnt:GetPhysicsObjectNum(physIdx)
		if IsValid(phys) then
			headPos = phys:GetPos()
		else
			ragdollEnt:SetupBones()
			local m = ragdollEnt:GetBoneMatrix(headIdx)
			if m then headPos = m:GetTranslation() end
		end
	end
	if headPos and headPos ~= vector_origin then
		pos = headPos + ang:Forward() * 4 + ang:Up() * 2
	end

	-- Camera uses player's aim but clamped to realistic head limits relative to torso yaw
	local lp = LocalPlayer()
	if IsValid(lp) then
		local aim = lp:EyeAngles()
		local torsoYaw = ragdollEnt:GetNWFloat("hg_torso_yaw", ang and ang.y or aim.y)
		local dy = math.AngleDifference(aim.y, torsoYaw)
		local maxYaw = 85
		dy = math.Clamp(dy, -maxYaw, maxYaw)
		local clampedYaw = math.NormalizeAngle(torsoYaw + dy)
		local clampedPitch = math.Clamp(aim.p, -85, 85)
		ang = Angle(clampedPitch, clampedYaw, 0)
		-- While holding USE (E), lift camera slightly along neck
		if lp:KeyDown(IN_USE) then
			pos = pos + ang:Up() * 12
		end
	end

    local ft = FrameTime()
    -- Exponential smoothing factors (stable across framerates)
    local posAlpha = 1 - math.exp(-ft / POS_TAU)
    local angAlpha = 1 - math.exp(-ft / ANG_TAU)

    if lastPos then
        -- Deadzone for tiny movements to remove micro jitter
        if pos:DistToSqr(lastPos) < (POS_DEADZONE * POS_DEADZONE) then
            pos = lastPos
        else
            pos = LerpVector(math.min(posAlpha, 1), lastPos, pos)
        end
    end
    if lastAng then
        local dp = math.abs(math.AngleDifference(ang.p, lastAng.p))
        local dy = math.abs(math.AngleDifference(ang.y, lastAng.y))
        local dr = math.abs(math.AngleDifference(ang.r, lastAng.r))
        if dp < ANG_DEADZONE and dy < ANG_DEADZONE and dr < ANG_DEADZONE then
            ang = Angle(lastAng.p, lastAng.y, lastAng.r)
        else
            ang = LerpAngle(math.min(angAlpha, 1), lastAng, ang)
        end
    end
    lastPos, lastAng = pos, ang
	return {
		origin = pos,
		angles = ang,
		fov = 120,
		drawviewer = false
	}
end

local function registerCalcView()
	hook.Remove("CalcView", "hg_ragdoll_firstperson")
	hook.Add("CalcView", "hg_ragdoll_firstperson", calcViewRagdoll)
end

-- Register late to win over other camera hooks
registerCalcView()

hook.Add("InitPostEntity", "hg_ragdoll_register_calcview", function()
	timer.Simple(0, registerCalcView)
end)

hook.Add("HUDShouldDraw", "hg_ragdoll_hide_crosshair", function(name)
	if inRagdoll and (name == "CHudCrosshair" or name == "CHudWeaponSelection") then return false end
end)

concommand.Add("hg_ragdoll_bind_hint", function()
	chat.AddText(Color(150, 200, 255), "Use console: ", Color(255,255,255), "hg_ragdoll_toggle (alias: fake)",
		Color(150, 200, 255), " or bind a key, e.g.: ", Color(255,255,255), "bind k fake")
end)

-- Функция для создания/обновления модели оружия на рэгдолле
local function updateRagdollWeapon()
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	
	local rag = lp:GetNWEntity("hg_ragdoll_entity")
	if not IsValid(rag) then
		-- Удаляем модель оружия если рэгдолла нет
		if IsValid(ragdollWeapon) then
			ragdollWeapon:Remove()
			ragdollWeapon = nil
			ragdollWeaponClass = nil
		end
		return
	end
	
	local activeWep = lp:GetActiveWeapon()
	local wepClass = IsValid(activeWep) and activeWep:GetClass() or nil
	
	    -- Проверяем, нужно ли показывать предмет в руке рэгдолла
    -- Разрешенные классы: AKM, бинт и обезболивающее
    local allowed = wepClass == "weapon_akm" or wepClass == "weapon_hg_bandage" or wepClass == "weapon_hg_painkiller"
    if allowed then
        local wepModel = IsValid(activeWep) and activeWep.WorldModel or ""
		
		        -- Если модель уже создана и правильная, ничего не делаем (FollowBone сам обновляет)
        if IsValid(ragdollWeapon) and ragdollWeaponClass == wepClass then
            return
        end
		
		-- Удаляем старую модель если класс изменился
		if IsValid(ragdollWeapon) then
			ragdollWeapon:Remove()
			ragdollWeapon = nil
		end
		
		        -- Создаем новую модель предмета/оружия
        local weaponModel = ClientsideModel(wepModel, RENDERGROUP_OPAQUE)
        if IsValid(weaponModel) then
            weaponModel:SetNoDraw(false)
            weaponModel:DrawShadow(true)
			
			            -- Прикрепляем к кости правой руки
            local handBone = rag:LookupBone("ValveBiped.Bip01_R_Hand")
            if handBone and handBone > 0 then
                weaponModel:FollowBone(rag, handBone)
                -- Смещение относительно кости руки (позиция и углы)
                -- Используем настройки из самого оружия/предмета, если они есть, иначе значения по умолчанию
                local weaponPos = activeWep.RagdollWeaponPos or activeWep.WMOffsetPos or Vector(5, 3, -2)
                local weaponAng = activeWep.RagdollWeaponAng or activeWep.WMOffsetAng or Angle(0, 90, 90)
                weaponModel:SetLocalPos(weaponPos)
                weaponModel:SetLocalAngles(weaponAng)
            else
                -- Fallback: прикрепляем к рэгдоллу напрямую
                weaponModel:SetParent(rag)
                weaponModel:AddEffects(EF_PARENT_ANIMATES)
            end
			
			ragdollWeapon = weaponModel
			ragdollWeaponClass = wepClass
		end
	    else
        -- Удаляем модель, если активный предмет не из разрешенного списка
        if IsValid(ragdollWeapon) then
            ragdollWeapon:Remove()
            ragdollWeapon = nil
            ragdollWeaponClass = nil
        end
    end
end

-- Обновляем модель оружия каждый кадр
hook.Add("Think", "hg_ragdoll_weapon_update", function()
	if not inRagdoll then
		if IsValid(ragdollWeapon) then
			ragdollWeapon:Remove()
			ragdollWeapon = nil
			ragdollWeaponClass = nil
		end
		return
	end
	
	updateRagdollWeapon()
end)




