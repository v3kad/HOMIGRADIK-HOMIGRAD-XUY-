do
	local hiddenBones = {}
	local headBoneNames = {
		["ValveBiped.Bip01_Head1"] = true,
		["ValveBiped.Bip01_Neck1"] = true
	}

	local function hideHeadBones(ply)
		if not IsValid(ply) then return end
		ply:SetupBones()
		for boneId = 0, ply:GetBoneCount() - 1 do
			local name = ply:GetBoneName(boneId)
			if name and headBoneNames[name] then
				hiddenBones[boneId] = ply:GetManipulateBoneScale(boneId)
				ply:ManipulateBoneScale(boneId, Vector(0, 0, 0))
			end
		end
	end

	local function restoreBones(ply)
		if not IsValid(ply) then return end
		for boneId, prev in pairs(hiddenBones) do
			ply:ManipulateBoneScale(boneId, prev or Vector(1, 1, 1))
			hiddenBones[boneId] = nil
		end
	end

	-- шлем и голова минус
	local function hideHelmetAndHead(ply)
		if not IsValid(ply) then return end
		
		local helmet = ply:GetNWEntity("Helmet")
		if IsValid(helmet) then
			helmet:SetNoDraw(true)
		end
		
		ply:SetupBones()
		for boneId = 0, ply:GetBoneCount() - 1 do
			local name = ply:GetBoneName(boneId)
			if name and (headBoneNames[name] or name:find("head") or name:find("Head")) then
				hiddenBones[boneId] = ply:GetManipulateBoneScale(boneId)
				ply:ManipulateBoneScale(boneId, Vector(0, 0, 0))
			end
		end
	end

	hook.Add("ShouldDrawLocalPlayer", "Homigrad_DrawOwnBodyFP", function(ply)
		if ply ~= LocalPlayer() then return end
		if not ply:Alive() then return false end
		if ply:GetObserverMode() ~= OBS_MODE_NONE then return false end
		return true
	end)

	hook.Add("PrePlayerDraw", "Homigrad_HideLocalHead", function(ply)
		if ply ~= LocalPlayer() then return end
		if not ply:Alive() then return end
		if ply:GetObserverMode() ~= OBS_MODE_NONE then return end
		hideHeadBones(ply)
		hideHelmetAndHead(ply)
	end)

	hook.Add("PostPlayerDraw", "Homigrad_RestoreLocalHead", function(ply)
		if ply ~= LocalPlayer() then return end
		restoreBones(ply)
		
		local helmet = ply:GetNWEntity("Helmet")
		if IsValid(helmet) then
			helmet:SetNoDraw(false)
		end
	end)

	hook.Add("Think", "HideLocalHelmet", function()
		local ply = LocalPlayer()
		if not IsValid(ply) or not ply:Alive() then return end
		
		local helmet = ply:GetNWEntity("Helmet")
		if IsValid(helmet) then
			helmet:SetNoDraw(true)
		end
	end)
end

do
	HG_UseHeadCam = true

	local bobTime = 0
	-- бобинг упрощенный
	local function getBob(ply, ang, basePos)
		local vel = ply:GetVelocity()
		local speed2D = vel:Length2D()
		
        -- бобинг
		if speed2D < 50 or not ply:OnGround() then return basePos, ang end
		
		bobTime = bobTime + FrameTime() * math.Clamp(speed2D / 200, 0.3, 1.5)
		local isSprint = ply:GetNWBool("HG_IsSprinting", false)
		local strength = (0.1 * math.Clamp(speed2D / 300, 0, 1)) * (isSprint and 1.2 or 0.8) 
		
		local origin = basePos + ang:Up() * (math.sin(bobTime * 6) * 0.3 + math.sin(bobTime * 3) * 0.15) * strength * 2 
		local newAng = Angle(ang.p, ang.y, ang.r)
		newAng.p = newAng.p + math.sin(bobTime * 6) * strength * 1.0
		newAng.y = newAng.y + math.cos(bobTime * 6) * strength * 0.6
		newAng.r = newAng.r + math.sin(bobTime * 12) * strength * 0.8
		
		return origin, newAng
	end

	local function getHeadTransform(ply)
		local headPos = nil
		local eyeID = ply:LookupAttachment("eyes") or 0
		if eyeID > 0 then
			local att = ply:GetAttachment(eyeID)
			if att and att.Pos then
				headPos = att.Pos
			end
		end
		if not headPos then
			local bone = ply:LookupBone("ValveBiped.Bip01_Head1")
			if bone then
				local m = ply:GetBoneMatrix(bone)
				if m then 
					headPos = m:GetTranslation()
				end
			end
		end
		if not headPos then
			headPos = ply:EyePos()
		end
		
		local headAng = ply:EyeAngles()
		
		return headPos, headAng
	end

	local ScopeLerp = 0
	local AimPosLerp = Vector(0, 0, 0)
	local AimAngLerp = Angle(0, 0, 0)

	hook.Remove("CalcView", "HG_CameraBob")
	hook.Remove("CalcView", "Homigrad_HeadCamera")

	hook.Add("CalcView", "Homigrad_HeadCamera", function(ply, pos, ang, fov)
		if ply ~= LocalPlayer() then return end
		if not ply:Alive() then return end
		if ply:GetObserverMode() ~= OBS_MODE_NONE then return end
		-- Skip default camera while controlling ragdoll (use ragdoll first-person view)
		local rag = ply:GetNWEntity("hg_ragdoll_entity")
		if IsValid(rag) then return end
		local viewEnt = ply:GetViewEntity()
		if IsValid(viewEnt) and viewEnt ~= ply then return end

		local wep = ply:GetActiveWeapon()
		local targetFOV = 120
		
		if IsValid(wep) and wep.GetZoomFOV then
			targetFOV = wep:GetZoomFOV()
		end

		local headPos, headAng = getHeadTransform(ply)
		local baseHeadPos = headPos + headAng:Forward() * 1
		
		if IsValid(wep) and wep.Base == "salat_base" and wep:IsScope() then
			ScopeLerp = Lerp(FrameTime() * 8, ScopeLerp, 1) 
			targetFOV = Lerp(ScopeLerp, targetFOV, 75) 
			
			local hand = ply:GetAttachment(ply:LookupAttachment("anim_attachment_rh"))
			if hand then
				local weaponClass = wep:GetClass()
				local vecWep, angWep
				
				if weaponClass == "weapon_glock18" then
					vecWep = hand.Pos + hand.Ang:Up() * 3.85 - hand.Ang:Forward() * 10 + hand.Ang:Right() * 1.45
					angWep = hand.Ang + Angle(5,10,0)
				elseif weaponClass == "weapon_ak74" then
					vecWep = hand.Pos + hand.Ang:Up() * 5.2 - hand.Ang:Forward() * -2 + hand.Ang:Right() * 1.1
					angWep = hand.Ang + Angle(-25,20,-25)
				elseif weaponClass == "weapon_ar15" then
					vecWep = hand.Pos + hand.Ang:Up() * 5.01 - hand.Ang:Forward() * 7 + hand.Ang:Right() * 0.725
					angWep = hand.Ang + Angle(-5,0,0)
				elseif weaponClass == "weapon_mp5" then
					vecWep = hand.Pos + hand.Ang:Up() * 4.17 - hand.Ang:Forward() * 7 + hand.Ang:Right() * 0.79	
					angWep = hand.Ang + Angle(-5,0,0)
				elseif weaponClass == "weapon_deagle" then
					vecWep = hand.Pos + hand.Ang:Up() * 2.7 - hand.Ang:Forward() * 10 + hand.Ang:Right() * 0.4
					angWep = hand.Ang + Angle(-10,0,0)
				elseif weaponClass == "weapon_akm" then
					vecWep = hand.Pos + hand.Ang:Up() * 5.3 - hand.Ang:Forward() * 6.5 + hand.Ang:Right() * 0.35
					angWep = hand.Ang + Angle(-3,-1,0)
				elseif weaponClass == "weapon_ak74u" then
					vecWep = hand.Pos + hand.Ang:Up() * 5.2 - hand.Ang:Forward() * 4 + hand.Ang:Right() * 0.78
					angWep = hand.Ang + Angle(-8,0,0)
				elseif weaponClass == "weapon_rpk" then
					vecWep = hand.Pos + hand.Ang:Up() * 4.75 - hand.Ang:Forward() * 4 + hand.Ang:Right() * 0.8
					angWep = hand.Ang + Angle(-7,0,0)
				elseif weaponClass == "weapon_m4a1" then
					vecWep = hand.Pos + hand.Ang:Up() * 5.05 - hand.Ang:Forward() * 7 + hand.Ang:Right() * 0.725
					angWep = hand.Ang + Angle(-5,0,0)
				elseif weaponClass == "weapon_m249" then
					vecWep = hand.Pos + hand.Ang:Up() * 5.8 - hand.Ang:Forward() * 8 + hand.Ang:Right() * 0.88
					angWep = hand.Ang + Angle(-6,0,0)
				else
					vecWep = hand.Pos + hand.Ang:Up() * 4 - hand.Ang:Forward() * 8 + hand.Ang:Right() * 1
					angWep = hand.Ang + Angle(-10,5,0)
				end
				
				local lerpSpeed = 26 -- интрополяция
				AimPosLerp = LerpVector(FrameTime() * lerpSpeed, AimPosLerp, vecWep)
				AimAngLerp = LerpAngle(FrameTime() * lerpSpeed, AimAngLerp, angWep)
			end
		else
			ScopeLerp = Lerp(FrameTime() * 15, ScopeLerp, 0)
			local lerpSpeed = 11.5
			AimPosLerp = LerpVector(FrameTime() * lerpSpeed, AimPosLerp, baseHeadPos)
			AimAngLerp = LerpAngle(FrameTime() * lerpSpeed, AimAngLerp, headAng)
		end

		HG_CurrentAimingFOV = HG_CurrentAimingFOV or fov
		HG_CurrentAimingFOV = Lerp(FrameTime() * 12, HG_CurrentAimingFOV, targetFOV)

		local finalPos, finalAng
		
		if IsValid(wep) and wep.Base == "salat_base" and wep:IsScope() then
			finalPos = AimPosLerp
			finalAng = AimAngLerp
			
			local mouseDelta = math.abs(ang.y - headAng.y) + math.abs(ang.p - headAng.p)
			if mouseDelta > 0.1 then
				finalAng = Angle(ang.p, ang.y, finalAng.r)
			end
		else
			finalPos, finalAng = getBob(ply, headAng, baseHeadPos)
		end
		
		return { 
			origin = finalPos, 
			angles = finalAng, 
			fov = HG_CurrentAimingFOV, 
			drawviewer = true 
		}
	end)
end