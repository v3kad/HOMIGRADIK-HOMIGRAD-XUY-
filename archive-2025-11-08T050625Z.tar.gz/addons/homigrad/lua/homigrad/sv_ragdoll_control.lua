if CLIENT then return end

util.AddNetworkString("hg_ragdoll_state")
util.AddNetworkString("hg_clear_ragdoll_armor")

-- Tuning cvars for head control response (higher gain = snappier, higher damp = more resistance)
local cvarHeadGain = CreateConVar("hg_ragdoll_head_gain", "5.0", {FCVAR_ARCHIVE}, "Ragdoll head angular gain (mouse-like responsiveness)")
local cvarHeadDamp = CreateConVar("hg_ragdoll_head_damp", "0.8", {FCVAR_ARCHIVE}, "Ragdoll head damping factor (0..2)")

local OWNER_KEY = "hg_ragdoll_owner"

local PLAYER_RAG = {}
local HOOK_STATE = {}
local FORCED_RAGDOLL = {}
local FALL_HEIGHT_UNITS = 105 -- ~2 meters in Source units (1 uu ≈ 1.905 cm)
local UU_TO_M = 0.01905
local PAIN_PER_M = 1 -- pain added per 1 meter of fall
local MAX_FALL_PAIN = 60

local function getPlayerRagdoll(ply)
	return PLAYER_RAG[ply]
end

local function setPlayerRagdoll(ply, rag)
	PLAYER_RAG[ply] = rag
end

local function getHeadPhys(rag)
	if not IsValid(rag) then return nil end
	local headBone = rag:LookupBone("ValveBiped.Bip01_Head1") or 0
	local physIndex = rag:TranslateBoneToPhysBone(headBone) or 0
	return rag:GetPhysicsObjectNum(physIndex)
end

local function getPelvisPhys(rag)
	if not IsValid(rag) then return nil end
	local pelvis = rag:LookupBone("ValveBiped.Bip01_Pelvis") or 0
	local physIndex = rag:TranslateBoneToPhysBone(pelvis) or 0
	return rag:GetPhysicsObjectNum(physIndex)
end

local function getChestPhys(rag)
	if not IsValid(rag) then return nil end
	local chestBone = rag:LookupBone("ValveBiped.Bip01_Spine2") or rag:LookupBone("ValveBiped.Bip01_Spine1") or rag:LookupBone("ValveBiped.Bip01_Spine") or 0
	local physIndex = rag:TranslateBoneToPhysBone(chestBone) or 0
	return rag:GetPhysicsObjectNum(physIndex)
end

local function getHandPhys(rag, isLeft)
	if not IsValid(rag) then return nil end
	local boneName = isLeft and "ValveBiped.Bip01_L_Hand" or "ValveBiped.Bip01_R_Hand"
	local bone = rag:LookupBone(boneName) or 0
	local physIndex = rag:TranslateBoneToPhysBone(bone) or 0
	return rag:GetPhysicsObjectNum(physIndex)
end

local function getArmPhys(rag, isLeft, segment)
	if not IsValid(rag) then return nil end
	local name
	if isLeft then
		name = (segment == "upper") and "ValveBiped.Bip01_L_UpperArm" or "ValveBiped.Bip01_L_Forearm"
	else
		name = (segment == "upper") and "ValveBiped.Bip01_R_UpperArm" or "ValveBiped.Bip01_R_Forearm"
	end
	local bone = rag:LookupBone(name) or 0
	local physIndex = rag:TranslateBoneToPhysBone(bone) or 0
	return rag:GetPhysicsObjectNum(physIndex)
end

local function spawnControlRagdoll(ply)
	local rag = ents.Create("prop_ragdoll")
	if not IsValid(rag) then return NULL end

	rag:SetModel(ply:GetModel())
	rag:SetPos(ply:GetPos())
	rag:SetAngles(Angle(0, ply:EyeAngles().y, 0))
	rag:Spawn()
	rag:Activate()

	rag:SetNWEntity(OWNER_KEY, ply)
	rag:SetCollisionGroup(COLLISION_GROUP_WEAPON)

	local physCount = rag:GetPhysicsObjectCount() or 0
	for i = 0, physCount - 1 do
		local phys = rag:GetPhysicsObjectNum(i)
		if IsValid(phys) then
			phys:Wake()
			phys:SetMaterial("gmod_silent")
		end
	end

	return rag
end

local function enterObserverForRagdoll(ply)
    if not IsValid(ply) then return end
    -- Save previous visual/collision state to restore later
    ply._hgPrevRenderMode = ply:GetRenderMode()
    ply._hgPrevColor = ply:GetColor()
    ply._hgPrevCollisionGroup = ply:GetCollisionGroup()
    ply._hgPrevNotSolid = ply:IsFlagSet(FL_NOTARGET) and ply.m_bWasNotSolid or ply:IsSolid() == false -- best-effort

    -- Make player fully invisible and non-colliding
    ply:DrawWorldModel(false)
    ply:DrawViewModel(false)
    ply:DrawShadow(false)
    ply:SetRenderMode(RENDERMODE_TRANSCOLOR)
    do
        local c = ply._hgPrevColor or Color(255,255,255,255)
        ply:SetColor(Color(c.r or 255, c.g or 255, c.b or 255, 0))
    end
    ply:AddEffects(EF_NODRAW)
    ply:SetNoDraw(true)
    ply:SetNotSolid(true)
    ply:SetCollisionGroup(COLLISION_GROUP_IN_VEHICLE)
    ply:SetNoTarget(true)
    ply:SetMoveType(MOVETYPE_OBSERVER)
    ply:GodEnable()

    -- Hide all player weapons worldmodels too and ensure no collisions
    for _, wep in ipairs(ply:GetWeapons() or {}) do
        if IsValid(wep) then
            wep:SetNoDraw(true)
            wep:DrawShadow(false)
            if wep.SetNotSolid then wep:SetNotSolid(true) end
            if wep.SetCollisionGroup then wep:SetCollisionGroup(COLLISION_GROUP_IN_VEHICLE) end
        end
    end
end

local function leaveObserver(ply)
    if not IsValid(ply) then return end
    ply:DrawWorldModel(true)
    ply:DrawViewModel(true)
    ply:DrawShadow(true)
    ply:RemoveEffects(EF_NODRAW)
    ply:SetNoTarget(false)
    ply:SetNoDraw(false)
    -- Restore render color/mode
    if ply._hgPrevRenderMode ~= nil then ply:SetRenderMode(ply._hgPrevRenderMode) end
    if ply._hgPrevColor ~= nil then ply:SetColor(ply._hgPrevColor) end
    -- Restore collisions
    if ply._hgPrevCollisionGroup ~= nil then
        ply:SetCollisionGroup(ply._hgPrevCollisionGroup)
    else
        ply:SetCollisionGroup(COLLISION_GROUP_PLAYER)
    end
    ply:SetNotSolid(false)

    ply:SetMoveType(MOVETYPE_WALK)
    ply:GodDisable()
    -- Restore weapon draw and collisions
    for _, wep in ipairs(ply:GetWeapons() or {}) do
        if IsValid(wep) then
            wep:SetNoDraw(false)
            wep:DrawShadow(true)
            if wep.SetNotSolid then wep:SetNotSolid(false) end
            if wep.SetCollisionGroup then wep:SetCollisionGroup(COLLISION_GROUP_WEAPON) end
        end
    end
end

local function stopDriving(ply, rag)
    -- Capture ragdoll position and facing before removal
    local targetPos = nil
    local targetYaw = nil
    if IsValid(rag) then
        targetPos = rag:GetPos() + Vector(0, 0, 8)
        local head = getHeadPhys(rag)
        if IsValid(head) then
            local ang = head:GetAngles()
            targetYaw = ang.y
        end
    end

    -- Clear NW ragdoll reference first so clients can detach armor from a valid entity
    ply:SetNWEntity("hg_ragdoll_entity", NULL)

    -- Return armor from ragdoll to player before removal
    -- Note: Player already has armor data, we just copy it back to ensure sync
    if IsValid(rag) and IsValid(ply) then
        if ply:Alive() then
            -- Tell clients to immediately clear armor visuals on this ragdoll
            net.Start("hg_clear_ragdoll_armor")
                net.WriteEntity(rag)
            net.Broadcast()
            if HG_ReturnArmorFromRagdoll then
                HG_ReturnArmorFromRagdoll(ply, rag)
            end
            if HG_ClearArmor then
                HG_ClearArmor(rag)
            end
            -- Delay removal a bit to ensure clients process NW change and clear message
            timer.Simple(0.1, function()
                if IsValid(rag) then rag:Remove() end
            end)
        end
    end
    setPlayerRagdoll(ply, NULL)
    leaveObserver(ply)

    -- Place player where the ragdoll was
    if IsValid(ply) and ply:Alive() then
        if targetPos then ply:SetPos(targetPos) end
        local yaw = targetYaw or ply:EyeAngles().y
        ply:SetEyeAngles(Angle(0, yaw, 0))
        ply:SetLocalVelocity(vector_origin)
    end

    net.Start("hg_ragdoll_state")
        net.WriteBool(false)
        net.WriteEntity(NULL)
        net.WriteAngle(angle_zero)
    net.Send(ply)
end

local function startDriving(ply)
	if not IsValid(ply) or not ply:Alive() then return end
	if IsValid(getPlayerRagdoll(ply)) then return end

	local rag = spawnControlRagdoll(ply)
	if not IsValid(rag) then return end

	-- Copy armor to ragdoll
	if HG_CopyArmorToRagdoll then
		HG_CopyArmorToRagdoll(ply, rag)
	end
	
	enterObserverForRagdoll(ply)
	setPlayerRagdoll(ply, rag)
	ply:SetNWEntity("hg_ragdoll_entity", rag)
	
	-- Don't clear armor from player - let client hide visuals instead
	-- This prevents synchronization issues and floating armor
	-- Client-side code will hide armor on invisible players automatically

	net.Start("hg_ragdoll_state")
		net.WriteBool(true)
		net.WriteEntity(rag)
		net.WriteAngle(ply:EyeAngles())
	net.Send(ply)
end

-- Public API for other modules
function HG_IsRagdolled(ply)
	return IsValid(getPlayerRagdoll(ply))
end

function HG_IsForcedRagdoll(ply)
	return FORCED_RAGDOLL[ply] == true
end

function HG_StartRagdoll(ply, forced)
	startDriving(ply)
	if forced then
		FORCED_RAGDOLL[ply] = true
		if IsValid(ply) then ply:SetNWBool("hg_pain_ragdoll", true) end
	end
end

function HG_StopRagdoll(ply, forceOverride)
    -- Never allow getting up if spine is broken
    if ply.HasHGBrokenSpine and ply:HasHGBrokenSpine() then
        return
    end
	-- Never allow getting up while unconscious
	if ply.GetNWBool and ply:GetNWBool("HG_Blackout", false) then
		return
	end
    if HG_IsForcedRagdoll(ply) and not forceOverride then return end
	local rag = getPlayerRagdoll(ply)
	if IsValid(rag) then
		stopDriving(ply, rag)
	end
	FORCED_RAGDOLL[ply] = nil
	if IsValid(ply) then ply:SetNWBool("hg_pain_ragdoll", false) end
end

concommand.Add("hg_ragdoll_toggle", function(ply)
	if not IsValid(ply) then return end
	-- Block getting up when forced by pain or while pain is high
	if HG_IsRagdolled(ply) then
		-- Broken spine: absolutely cannot get up
		if ply.HasHGBrokenSpine and ply:HasHGBrokenSpine() then
			ply:ChatPrint("Вы не можете встать из за сломного позвоночника.")
			return
		end
		-- Unconscious: cannot get up
		if ply.GetNWBool and ply:GetNWBool("HG_Blackout", false) then
			ply:ChatPrint("Вы без сознания и не можете встать.")
			return
		end
		if HG_IsForcedRagdoll(ply) then
			local pain = ply.GetHGPain and ply:GetHGPain() or 0
			if pain >= 35 then
				ply:ChatPrint("Вы не можете встать из за невыносимой боли.")
				return
			end
			-- pain below threshold: allow
		end
	end
	local rag = getPlayerRagdoll(ply)
	if IsValid(rag) then
		local pain = ply.GetHGPain and ply:GetHGPain() or 0
		local override = HG_IsForcedRagdoll(ply) and (pain < 35)
		HG_StopRagdoll(ply, override)
	else
		HG_StartRagdoll(ply)
	end
end)

-- Alias command: allow binding to "fake" to toggle ragdoll
concommand.Add("fake", function(ply)
	if not IsValid(ply) then return end
	if HG_IsRagdolled(ply) then
		if ply.GetNWBool and ply:GetNWBool("HG_Blackout", false) then
			ply:ChatPrint("Вы без сознания и не можете встать.")
			return
		end
		if ply.HasHGBrokenSpine and ply:HasHGBrokenSpine() then
			ply:ChatPrint("Вы не можете встать: сломан позвоночник.")
			return
		end
		if HG_IsForcedRagdoll(ply) then
			local pain = ply.GetHGPain and ply:GetHGPain() or 0
			if pain >= 35 then
				ply:ChatPrint("Вы не можете встать: слишком сильная боль.")
				return
			end
		end
	end
	local rag = getPlayerRagdoll(ply)
	if IsValid(rag) then
		local pain = ply.GetHGPain and ply:GetHGPain() or 0
		local override = HG_IsForcedRagdoll(ply) and (pain < 35)
		HG_StopRagdoll(ply, override)
	else
		HG_StartRagdoll(ply)
	end
end)

hook.Add("PlayerDisconnected", "hg_ragdoll_cleanup", function(ply)
	local rag = getPlayerRagdoll(ply)
	if IsValid(rag) then rag:Remove() end
	PLAYER_RAG[ply] = nil
	HOOK_STATE[ply] = nil
	FORCED_RAGDOLL[ply] = nil
end)

-- Physics-driven control via head and mouse buttons (no WASD)
hook.Add("SetupMove", "hg_ragdoll_move", function(ply, mv, cmd)
	local rag = getPlayerRagdoll(ply)
	if not IsValid(rag) then return end
	-- Block any control while unconscious
	if ply.GetNWBool and ply:GetNWBool("HG_Blackout", false) then
		return
	end

	-- Per-player transient state
	local st = HOOK_STATE[ply]
	if not st then st = { leftColDisabled = false, rightColDisabled = false } HOOK_STATE[ply] = st end

	local head = getHeadPhys(rag)
    if IsValid(head) then
        local wish = mv:GetAngles()
        -- Network torso yaw every tick for client-side head clamp
        do
            local chest = getChestPhys(rag)
            local pelvis = getPelvisPhys(rag) or rag:GetPhysicsObject()
            local torsoYaw
            if IsValid(chest) then torsoYaw = chest:GetAngles().y end
            if torsoYaw == nil and IsValid(pelvis) then torsoYaw = pelvis:GetAngles().y end
            if torsoYaw ~= nil and IsValid(rag) then rag:SetNWFloat("hg_torso_yaw", torsoYaw) end
        end
		local cur = head:GetAngles()
		-- Determine whether player is actively controlling head/torso
		local diffP = math.abs(math.AngleDifference(wish.p, (st.lastWishAng and st.lastWishAng.p) or wish.p))
		local diffY = math.abs(math.AngleDifference(wish.y, (st.lastWishAng and st.lastWishAng.y) or wish.y))
		local hasAngleInput = (diffP > 0.5) or (diffY > 0.5)
		local usingTorso = mv:KeyDown(IN_USE)
		local activeTorsoControl = usingTorso and (hasAngleInput or mv:KeyDown(IN_ATTACK) or mv:KeyDown(IN_ATTACK2))
		-- We'll only wake/apply when input is present
		if hasAngleInput then
			head:Wake()
			-- Constrain head yaw relative to torso so it cannot rotate behind (toward the back of the head)
			local torso = getChestPhys(rag) or getPelvisPhys(rag) or rag:GetPhysicsObject()
			local torsoYaw = (IsValid(torso) and torso:GetAngles().y) or cur.y
			local dyWish = math.AngleDifference(wish.y, torsoYaw)
			-- Allow wider head yaw while holding E to let camera turn freely
			dyWish = math.Clamp(dyWish, usingTorso and -179 or -90, usingTorso and 179 or 90)
			local targetYaw = math.NormalizeAngle(torsoYaw + dyWish)
			local targetPitch = math.Clamp(wish.p, -85, 85)
			local targetRoll = 0
			local target = Angle(targetPitch, targetYaw, targetRoll)
			local dP = math.AngleDifference(target.p, cur.p)
			local dY = math.AngleDifference(target.y, cur.y)
			local dR = math.AngleDifference(target.r, cur.r)
			local gain = math.max(0.1, (cvarHeadGain and cvarHeadGain:GetFloat()) or 8.0)
			local damp = math.Clamp((cvarHeadDamp and cvarHeadDamp:GetFloat()) or 0.4, 0, 2)
			local desired = Vector(dP, dY, dR) * gain
			local currentAV = head:GetAngleVelocity()
			head:AddAngleVelocity(desired - currentAV * damp)
				-- Minimal vertical assist to avoid sinking only during active control
				if activeTorsoControl then
					local upStrength = head:GetMass() * 10
					head:ApplyForceCenter(Vector(0, 0, upStrength))
					local pelvis = getPelvisPhys(rag) or rag:GetPhysicsObject()
					if IsValid(pelvis) then
						pelvis:ApplyForceCenter(Vector(0, 0, -upStrength * 0.5))
					end
				end
			-- Expose head transform to client for reliable camera following
			local hpos = head:GetPos()
			if IsValid(rag) then
				rag:SetNWAngle("hg_head_ang", cur)
				if hpos then rag:SetNWVector("hg_head_pos", hpos) end
			end
			-- Torso assist only while actively controlling
			if activeTorsoControl then
				local chest = getChestPhys(rag)
				local pelvis = getPelvisPhys(rag) or rag:GetPhysicsObject()
				if IsValid(chest) then chest:Wake() end
				if IsValid(pelvis) then pelvis:Wake() end
				if IsValid(chest) then
					local cav = chest:GetAngleVelocity()
					chest:AddAngleVelocity(Vector(-cav.x * 0.25, -cav.y * 1.2, -cav.z * 1.2))
					local cang = chest:GetAngles()
					local wantPitch = math.Clamp(wish.p - 6, -65, 65)
					local dPitch = math.AngleDifference(wantPitch, cang.p)
					chest:AddAngleVelocity(Vector(dPitch * 1.1, 0, 0))
					if IsValid(pelvis) then
						local pav = pelvis:GetAngleVelocity()
						pelvis:AddAngleVelocity(Vector(-pav.x * 0.25, -pav.y * 1.2, -pav.z * 1.2))
						pelvis:AddAngleVelocity(Vector(-dPitch * 0.8, 0, 0))
					end
				end
			end
		else
			-- No camera input: keep head fully idle to avoid micro jiggle
			-- Do not wake or apply forces; ensure it sleeps but still network its current transform
			head:Sleep()
			local cur = head:GetAngles()
			local hpos = head:GetPos()
			if IsValid(rag) then
				rag:SetNWAngle("hg_head_ang", cur)
				if hpos then rag:SetNWVector("hg_head_pos", hpos) end
			end
		end
		-- Do not teleport the spectator each tick to avoid network stutter; camera follows head clientside
		-- (positioning handled in CalcView)
		st.lastWishAng = Angle(wish.p, wish.y, 0)
	end

	local wep = ply:GetActiveWeapon()
	local usingHands = IsValid(wep) and wep:GetClass() == "wep_hands"
	local usingAKM = IsValid(wep) and wep:GetClass() == "weapon_akm"
	-- Поддержка как рук, так и AKM в рэгдоле
	if not usingHands and not usingAKM then return end


	-- Use the camera angles for arms; when holding E, keep full pitch/yaw control
		local eyeAng = mv:GetAngles()
		local armAimAng = eyeAng
	local function setArmCollision(isLeft, enable)
		local upper = getArmPhys(rag, isLeft, "upper")
		local fore = getArmPhys(rag, isLeft, "fore")
		local hand = getHandPhys(rag, isLeft)
		if IsValid(upper) then upper:EnableCollisions(enable) end
		if IsValid(fore) then fore:EnableCollisions(enable) end
		if IsValid(hand) then hand:EnableCollisions(enable) end
	end

    local function alignBoneToView(obj, pitchScale, yawScale, gain)
		if not IsValid(obj) then return end
		obj:Wake()
		obj:AddAngleVelocity(-obj:GetAngleVelocity() * 0.6)
		local cur = obj:GetAngles()
		-- Optional offsets can be provided via upvalues when needed (see raiseArm)
		local yawOffset = alignBoneToViewYawOffset or 0
		local pitchOffset = alignBoneToViewPitchOffset or 0
        local baseP = math.Clamp(armAimAng.p * pitchScale + pitchOffset, -85, 85)
        local baseY = math.NormalizeAngle(armAimAng.y * yawScale + yawOffset)
		-- include head roll so arms match camera tilt; keep natural roll even when using E
		local headObj = getHeadPhys(rag)
		local baseR = ((IsValid(headObj) and headObj:GetAngles().r) or 0)
        local aim = Angle(baseP, baseY, baseR)
		-- Choose equivalent orientation (flip yaw 180, invert pitch) if it requires less rotation
        local alt = Angle(-baseP, math.NormalizeAngle(baseY + 180), baseR)
		local function cost(a)
			local dp = math.abs(math.AngleDifference(a.p, cur.p))
			local dy = math.abs(math.AngleDifference(a.y, cur.y))
			return dp + dy
		end
		if cost(alt) < cost(aim) then
			aim = alt
		end
        local dp = math.AngleDifference(aim.p, cur.p)
        local dy = math.AngleDifference(aim.y, cur.y)
        local dr = math.AngleDifference(aim.r, cur.r)
        obj:AddAngleVelocity(Vector(dp, dy, dr) * gain)
end

	local function raiseArm(isLeft, bothRaised, makeStraight)
		-- Slight inward yaw bias to keep hands in frame when both raised
		local baseYaw = bothRaised and (isLeft and -14 or 14) or (isLeft and -20 or 20)
		if makeStraight then
			-- Keep arm perfectly straight towards view direction (no side/pitch offsets)
			alignBoneToViewYawOffset = 0
			alignBoneToViewPitchOffset = 0
			alignBoneToView(getArmPhys(rag, isLeft, "upper"), 1.0, 1.0, 4.6)
			alignBoneToView(getArmPhys(rag, isLeft, "fore"), 1.0, 1.0, 4.2)
			alignBoneToView(getHandPhys(rag, isLeft), 1.0, 1.0, 3.8)
			alignBoneToViewYawOffset = nil
			alignBoneToViewPitchOffset = nil
			return
		end
		-- Default: slight tapering to keep a natural bend
		alignBoneToViewYawOffset = baseYaw
		alignBoneToViewPitchOffset = -2
		alignBoneToView(getArmPhys(rag, isLeft, "upper"), 1.0, 1.0, 3.0)
		alignBoneToViewYawOffset = baseYaw * 0.7
		alignBoneToView(getArmPhys(rag, isLeft, "fore"), 0.9, 1.0, 2.2)
		alignBoneToViewYawOffset = baseYaw * 0.5
		alignBoneToView(getHandPhys(rag, isLeft), 0.9, 1.0, 1.6)
		alignBoneToViewYawOffset = nil
		alignBoneToViewPitchOffset = nil
end

	local function pullHandTowardsView(isLeft)
		local upper = getArmPhys(rag, isLeft, "upper")
		local fore = getArmPhys(rag, isLeft, "fore")
		local hand = getHandPhys(rag, isLeft)
		if not (IsValid(upper) and IsValid(fore) and IsValid(hand)) then return end
		upper:Wake(); fore:Wake(); hand:Wake()
		local head = getHeadPhys(rag)
		local aim = Angle(armAimAng.p, armAimAng.y, 0)
		-- Pull hand in front of camera with slight side offset so it appears on screen edges
		local base = (IsValid(head) and head:GetPos() or upper:GetPos())
		local fwd = aim:Forward() * 46
		local side = aim:Right() * (isLeft and -12 or 12)
		local up = aim:Up() * -2
		local target = base + fwd + side + up
		local cur = hand:GetPos()
		local toTarget = target - cur
		local massH = hand:GetMass()
		-- Strong, but damped and clamped pull to avoid oscillations
		local desiredVelH = toTarget * 10
		local addH = (desiredVelH - hand:GetVelocity()) * massH
		local maxForce = massH * 800
		if addH:LengthSqr() > maxForce * maxForce then
			addH = addH:GetNormalized() * maxForce
		end
		hand:ApplyForceCenter(addH)
		-- Apply equal and opposite force to pelvis to avoid dragging whole body
		local pelvis = getPelvisPhys(rag) or rag:GetPhysicsObject()
		if IsValid(pelvis) then
			pelvis:ApplyForceCenter(-addH)
		end
		-- Also align forearm to the same aim to prevent elbow bend, with extra damping
        local curFore = fore:GetAngles()
        local headObj = getHeadPhys(rag)
        local roll = (IsValid(headObj) and headObj:GetAngles().r) or 0
        local aimRoll = Angle(aim.p, aim.y, roll)
        local dp = math.AngleDifference(aimRoll.p, curFore.p)
        local dy = math.AngleDifference(aimRoll.y, curFore.y)
        local dr = math.AngleDifference(aimRoll.r, curFore.r)
		fore:AddAngleVelocity(Vector(dp, dy, dr) * 4 - fore:GetAngleVelocity() * 0.5)
	end

	-- Raise and align arms only when the player holds mouse buttons; keep them straight while raised
	local holdL = mv:KeyDown(IN_ATTACK)
	local holdR = mv:KeyDown(IN_ATTACK2)
	
	-- Для AKM: правая рука держит оружие, левая поддерживает (при прицеливании)
	-- В этом режиме кнопки мыши используются только для стрельбы/прицеливания, не для поднятия рук
	if usingAKM then
		-- Правая рука всегда поднята для удержания оружия (независимо от кнопок)
		setArmCollision(false, true)
		raiseArm(false, false, true)
		pullHandTowardsView(false)
		
		-- Левая рука поднята только при прицеливании (IN_ATTACK2) для поддержки оружия
		-- Левая кнопка мыши (IN_ATTACK) НЕ поднимает левую руку - только стрельба
		setArmCollision(true, true)
		if holdR then
			-- Прицеливание: левая рука поддерживает оружие
			raiseArm(true, false, true)
			pullHandTowardsView(true)
		else
			-- Не прицеливается: левая рука опущена (не вызываем raiseArm/pullHandTowardsView)
			-- Рука остается в естественном положении, не поднимается
		end
	else
		-- Логика для рук (оригинальная) - работает только когда НЕ используется AKM
		local bothRaised = holdL and holdR
		-- Left arm
		if holdL then
			setArmCollision(true, true)
			raiseArm(true, bothRaised, true)
			pullHandTowardsView(true)
		else
			setArmCollision(true, true)
		end
		-- Right arm
		if holdR then
			setArmCollision(false, true)
			raiseArm(false, bothRaised, true)
			pullHandTowardsView(false)
		else
			setArmCollision(false, true)
		end
	end

	-- When any hand is raised (or weapon is held), gently rotate torso/pelvis to face aim yaw
	-- Для AKM торс всегда поворачивается к прицелу
	if usingAKM or (not usingAKM and (holdL or holdR)) then
		local chest = getChestPhys(rag)
		local pelvis = getPelvisPhys(rag) or rag:GetPhysicsObject()
		local targetYaw = math.NormalizeAngle(eyeAng.y)
		if IsValid(chest) then
			chest:Wake()
			local cang = chest:GetAngles()
			local dy = math.AngleDifference(targetYaw, cang.y)
			local cav = chest:GetAngleVelocity()
			-- Yaw toward aim with damping
			chest:AddAngleVelocity(Vector(0, dy * 3.0, 0) - cav * 0.35)
		end
		if IsValid(pelvis) then
			pelvis:Wake()
			local pang = pelvis:GetAngles()
			local dy = math.AngleDifference(targetYaw, pang.y)
			local pav = pelvis:GetAngleVelocity()
			pelvis:AddAngleVelocity(Vector(0, dy * 2.5, 0) - pav * 0.30)
		end
	end

	-- While holding E and actively controlling, keep body prone/level and prevent spinning in place (no yaw torque)
	if activeTorsoControl then
		local chest = getChestPhys(rag)
		local pelvis = getPelvisPhys(rag) or rag:GetPhysicsObject()
		-- Keep body horizontal on stomach: zero pitch and roll
		local target = Angle(0, math.NormalizeAngle(eyeAng.y), 0)
		-- Make chest inherit full camera orientation (pitch/yaw/roll≈0) with clamped AV
		if IsValid(chest) then
			chest:Wake()
			local cang = chest:GetAngles()
			local cav = chest:GetAngleVelocity()
			local dp = math.AngleDifference(target.p, cang.p)
			local dy = math.AngleDifference(target.y, cang.y)
			local dr = math.AngleDifference(0, cang.r)
			local gainP, gainY, gainR = 3.2, 5.0, 3.2
			local damp = 0.65
			local maxAVP, maxAVY, maxAVR = 65, 85, 65
			local wantP = math.Clamp(dp * gainP, -maxAVP, maxAVP)
			-- Suppress yaw torque while E is held to avoid spinning in place
			local wantY = 0
			local wantR = math.Clamp(dr * gainR, -maxAVR, maxAVR)
			-- Extra yaw braking
			local brake = Vector(0, -cav.y * 0.8, 0)
			chest:AddAngleVelocity(Vector(wantP, wantY, wantR) - cav * damp + brake)
		end
		-- Make pelvis follow as well but with slightly lower gains to keep stability
		if IsValid(pelvis) then
			pelvis:Wake()
			local pang = pelvis:GetAngles()
			local pav = pelvis:GetAngleVelocity()
			local dp = math.AngleDifference(target.p, pang.p)
			local dy = math.AngleDifference(target.y, pang.y)
			local dr = math.AngleDifference(0, pang.r)
			local gainP, gainY, gainR = 2.4, 4.2, 2.6
			local damp = 0.62
			local maxAVP, maxAVY, maxAVR = 55, 70, 55
			local wantP = math.Clamp(dp * gainP, -maxAVP, maxAVP)
			-- Suppress yaw torque while E is held to avoid spinning in place
			local wantY = 0
			local wantR = math.Clamp(dr * gainR, -maxAVR, maxAVR)
			-- Extra yaw braking
			local brake = Vector(0, -pav.y * 0.8, 0)
			pelvis:AddAngleVelocity(Vector(wantP, wantY, wantR) - pav * damp + brake)
		end
	end

	-- If camera looks beyond natural head yaw limit relative to torso, rotate torso to follow yaw (no pitch/roll)
	if not activeTorsoControl then
		local chest = getChestPhys(rag)
		local pelvis = getPelvisPhys(rag) or rag:GetPhysicsObject()
		local torsoYaw
		if IsValid(chest) then torsoYaw = chest:GetAngles().y end
		if torsoYaw == nil and IsValid(pelvis) then torsoYaw = pelvis:GetAngles().y end
		if torsoYaw ~= nil then
			local dy = math.AngleDifference(eyeAng.y, torsoYaw)
			local absDy = math.abs(dy)
			local startTurn = 75 -- start rotating torso if head would need to twist too far
			local fullTurn = 110 -- stronger rotation when way beyond limit
			if absDy > startTurn then
				local turnFrac = math.Clamp((absDy - startTurn) / (fullTurn - startTurn), 0, 1)
				local yawGainChest = 3.2 * turnFrac
				local yawGainPelvis = 2.6 * turnFrac
				if IsValid(chest) then
					chest:Wake()
					local cav = chest:GetAngleVelocity()
					local wantY = math.Clamp(dy * yawGainChest, -70, 70)
					chest:AddAngleVelocity(Vector(0, wantY, 0) - cav * 0.35)
				end
				if IsValid(pelvis) then
					pelvis:Wake()
					local pav = pelvis:GetAngleVelocity()
					local wantY = math.Clamp(dy * yawGainPelvis, -60, 60)
					pelvis:AddAngleVelocity(Vector(0, wantY, 0) - pav * 0.30)
				end
			end
		end
	end

	-- Hand latching system: hold Left Shift for left hand, Left Alt for right hand; hold W to pull body forward
	-- Отключаем систему зацепления если игрок держит AKM
	if not usingAKM then
		do
			-- Ensure per-player latch state containers
			st.latchL = st.latchL or { active = false, pos = nil, normal = nil }
			st.latchR = st.latchR or { active = false, pos = nil, normal = nil }
			local function tryStartLatch(isLeft)
				local hand = getHandPhys(rag, isLeft)
				if not IsValid(hand) then return end
				local start = hand:GetPos()
				local dir = mv:GetAngles():Forward()
				local tr = util.TraceLine({ start = start, endpos = start + dir * 64, mask = MASK_SOLID, filter = { ply, rag } })
				if tr.Hit then
					local latch = isLeft and st.latchL or st.latchR
					latch.active = true
					latch.pos = tr.HitPos
					latch.normal = tr.HitNormal
					-- soften immediate velocity to reduce snap
					hand:SetVelocity((latch.pos - start) * 2)
				end
			end
			local function clearLatch(isLeft)
				local latch = isLeft and st.latchL or st.latchR
				latch.active = false
				latch.pos = nil
				latch.normal = nil
			end
			local holdLeft = mv:KeyDown(IN_SPEED)
			local holdRight = mv:KeyDown(IN_WALK)
			if holdLeft and not st.latchL.active then tryStartLatch(true) end
			if holdRight and not st.latchR.active then tryStartLatch(false) end
			if not holdLeft and st.latchL.active then clearLatch(true) end
			if not holdRight and st.latchR.active then clearLatch(false) end

			local function applyLatch(isLeft)
				local latch = isLeft and st.latchL or st.latchR
				if not latch.active or not latch.pos then return end
				local hand = getHandPhys(rag, isLeft)
				if not IsValid(hand) then return end
				hand:Wake()
				local cur = hand:GetPos()
				local to = latch.pos - cur
				-- PD controller toward latch position
				local mass = hand:GetMass()
				local desiredVel = to * 12
				local add = (desiredVel - hand:GetVelocity()) * mass
				local maxForce = mass * 1500
				if add:LengthSqr() > maxForce * maxForce then
					add = add:GetNormalized() * maxForce
				end
				hand:ApplyForceCenter(add)
				-- small counterforce to pelvis to keep overall stability
				local pelvis = getPelvisPhys(rag) or rag:GetPhysicsObject()
				if IsValid(pelvis) then pelvis:ApplyForceCenter(-add * 0.6) end
			end
			if holdLeft then applyLatch(true) end
			if holdRight then applyLatch(false) end

			-- Pull the body toward the latched point(s) when holding W
			if mv:KeyDown(IN_FORWARD) and (st.latchL.active or st.latchR.active) then
				local pelvis = getPelvisPhys(rag) or rag:GetPhysicsObject()
				if IsValid(pelvis) then
					pelvis:Wake()
					local target
					if st.latchL.active and st.latchR.active and st.latchL.pos and st.latchR.pos then
						target = (st.latchL.pos + st.latchR.pos) * 0.5
					else
						target = (st.latchL.pos or st.latchR.pos)
					end
					if target then
						local cur = pelvis:GetPos()
						local to = target - cur
						-- project along plane parallel to surface to avoid pushing into wall too hard
						local n = (st.latchL.normal or st.latchR.normal or Vector(0,0,0))
						if n ~= vector_origin then
							to = to - n * to:Dot(n)
						end
						local mass = pelvis:GetMass()
						local desiredVel = to:GetNormalized() * 90
						local add = (desiredVel - pelvis:GetVelocity()) * mass
						local maxForce = mass * 1800
						if add:LengthSqr() > maxForce * maxForce then
							add = add:GetNormalized() * maxForce
						end
						pelvis:ApplyForceCenter(add)
					end
				end
			end
		end
	else
		-- Если игрок держит AKM, сбрасываем все активные зацепления
		if st.latchL and st.latchL.active then
			st.latchL.active = false
			st.latchL.pos = nil
			st.latchL.normal = nil
		end
		if st.latchR and st.latchR.active then
			st.latchR.active = false
			st.latchR.pos = nil
			st.latchR.normal = nil
		end
	end
end)



-- Forward gunshot damage on ragdoll to the owning player: apply pain and bleeding
hook.Add("EntityTakeDamage", "hg_ragdoll_bullet_forward", function(target, dmginfo)
	if not IsValid(target) or target:GetClass() ~= "prop_ragdoll" then return end
	local owner = target:GetNWEntity(OWNER_KEY)
	if not IsValid(owner) or not owner:IsPlayer() then return end
	if not owner:Alive() then return end

	-- Nullify physical damage on the ragdoll entity itself
	dmginfo:SetDamage(0)

	if dmginfo:IsBulletDamage() then
		local atk = dmginfo.GetAttacker and dmginfo:GetAttacker() or nil
		if IsValid(atk) and atk:IsPlayer() and atk == owner then return end
		-- Armor-aware forwarding: check if hit near head or chest and owner has helmet/vest
		local pos = dmginfo.GetDamagePosition and dmginfo:GetDamagePosition() or nil
		local mitigated = false
		local isHeadshot = false
		if pos and pos ~= vector_origin then
			local function physPos(obj)
				if not IsValid(obj) then return nil end
				return obj:GetPos()
			end
			local head = getHeadPhys(target)
			local chest = getChestPhys(target)
			local headPos = physPos(head)
			local chestPos = physPos(chest)
			if headPos then
				if headPos:DistToSqr(pos) <= (20*20) then
					isHeadshot = true
					if owner:GetNWBool("HG_Helmet", false) then
						mitigated = true
						if HG_Armor_PlayImpact then HG_Armor_PlayImpact(owner, true) end
						if ParticleEffect then ParticleEffect("hs_impact_fx", pos, angle_zero) end
					end
				end
			end
			if (not mitigated) and chestPos and owner:GetNWBool("HG_Vest", false) then
				if chestPos:DistToSqr(pos) <= (28*28) then
					mitigated = true
					if HG_Armor_PlayImpact then HG_Armor_PlayImpact(owner, false) end
					if ParticleEffect then ParticleEffect("hs_impact_fx", pos, angle_zero) end
				end
			end
		end
		if mitigated then
			if owner.AddHGBulletWounds then owner:AddHGBulletWounds(1) end
			if owner.AddHGPain then owner:AddHGPain(8) end
		else
			if owner.GetHGBleedingRate and owner.SetHGBleeding then
				if owner:GetHGBleedingRate() < 2 then
					owner:SetHGBleeding(2)
					owner:ChatPrint("Вы начали сильно кровоточить от огнестрельного ранения!")
				end
			end
			if owner.AddHGBulletWounds then owner:AddHGBulletWounds(1) end
			if owner.AddHGPain then owner:AddHGPain(15) end
		end
		-- Extra headshot pain to reach totals of 30 (no helmet) or 15 (with helmet)
		if isHeadshot and owner.AddHGPain then
			owner:AddHGPain(mitigated and 7 or 15)
		end
	else
		-- Melee or other damage types
		local dt = dmginfo:GetDamageType() or 0
		local isSlash = bit and bit.band(dt, DMG_SLASH) ~= 0
		local isClub = bit and bit.band(dt, DMG_CLUB) ~= 0
		if isSlash or isClub then
			-- Pain from melee while ragdolled
			if owner.AddHGPain then owner:AddHGPain(isSlash and 12 or 10) end
			-- Slashes start light bleeding
			if isSlash and owner.GetHGBleedingRate and owner.SetHGBleeding then
				if owner:GetHGBleedingRate() < 1 then
					owner:SetHGBleeding(1)
					owner:ChatPrint("Вы начали кровоточить!")
				end
			end
		else
			-- Other non-bullet damage should not start bleeding
		end
	end
end)


-- Track fall start and ragdoll on hard landings (> ~2m drop)
hook.Add("SetupMove", "hg_track_fall_start", function(ply, mv)
	if not IsValid(ply) or not ply:Alive() then return end
	if HG_IsRagdolled(ply) then return end
	-- When leaving ground and moving downward, remember Z to compute drop distance
	if not ply:OnGround() and mv:GetVelocity().z < -10 then
		if not ply._hgFallStartZ then
			ply._hgFallStartZ = ply:GetPos().z
		end
	end
end)

hook.Add("OnPlayerHitGround", "hg_ragdoll_on_fall", function(ply, inWater, onFloater, speed)
	if not IsValid(ply) or not ply:Alive() then ply._hgFallStartZ = nil return end
	if inWater then ply._hgFallStartZ = nil return end
	if HG_IsRagdolled(ply) then ply._hgFallStartZ = nil return end
	local startZ = ply._hgFallStartZ
	ply._hgFallStartZ = nil
    if startZ then
        local drop = startZ - ply:GetPos().z
        if drop > FALL_HEIGHT_UNITS then
            -- Pain proportional to total fall height in meters
            local meters = drop * UU_TO_M
            local pain = math.Clamp(meters * PAIN_PER_M, 5, MAX_FALL_PAIN)
            if ply.AddHGPain then ply:AddHGPain(pain) end
            HG_StartRagdoll(ply, true)
            -- Break legs if fall exceeded 10 meters
            if meters >= 10 and ply.SetHGBrokenLeg then
                ply:SetHGBrokenLeg(true)
                ply:ChatPrint("Вы сломали ногу при падении!")
            end
            -- Break spine if fall exceeded 30 meters
            if meters >= 30 and ply.SetHGBrokenSpine then
                ply:SetHGBrokenSpine(true)
                ply:ChatPrint("Критическое падение! Вы сломали позвоночник и не можете встать.")
            end
        end
    end
end)

