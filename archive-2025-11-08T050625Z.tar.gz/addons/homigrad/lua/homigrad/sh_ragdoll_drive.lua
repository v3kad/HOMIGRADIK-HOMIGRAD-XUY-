if not drive then return end

local DRIVE_ID = "hg_ragdoll_drive"
local OWNER_KEY = "hg_ragdoll_owner"

local function getOwner(ent)
	return IsValid(ent) and ent:GetNWEntity(OWNER_KEY) or nil
end

local function getHeadPhys(rag)
	if not IsValid(rag) then return nil end
	local headBone = rag:LookupBone("ValveBiped.Bip01_Head1") or 0
	local physIndex = rag:TranslateBoneToPhysBone(headBone) or 0
	return rag:GetPhysicsObjectNum(physIndex)
end

local function getPelvisPhys(rag)
	if not IsValid(rag) then return nil end
	local pelvis = rag:LookupBone("ValveBiped.Bip01_Pelvis") or 0
	local physIndex = rag:TranslateBoneToPhysBone(pelvis) or 0
	return rag:GetPhysicsObjectNum(physIndex)
end

drive.Register(DRIVE_ID, {
	Start = function(self, cmd)
		self.LastAngles = self.LastAngles or Angle(0, 0, 0)
	end,

	Stop = function(self)
		-- no-op
	end,

	Move = function(self, mv)
		local ply = self.Player
		local rag = self.Entity
		if not IsValid(ply) or not IsValid(rag) then return end

		local wishAngles = mv:GetMoveAngles()
		self.LastAngles = wishAngles

		if CLIENT then return end

		-- Aim the head towards the view angles by applying angular velocity
		local head = getHeadPhys(rag)
		if IsValid(head) then
			head:Wake()
			local cur = head:GetAngles()
			local target = Angle(wishAngles.p, wishAngles.y, 0)
			local diffP = math.AngleDifference(target.p, cur.p)
			local diffY = math.AngleDifference(target.y, cur.y)
			local diffR = math.AngleDifference(target.r, cur.r)
			local desired = Vector(diffP, diffY, diffR) * 4
			local currentAV = head:GetAngleVelocity()
			local add = (desired - currentAV * 0.6)
			head:AddAngleVelocity(add)
		end

		local forward = wishAngles:Forward()
		local right = wishAngles:Right()
		forward.z = 0; right.z = 0
		forward:Normalize(); right:Normalize()

		local wishVel = Vector(0, 0, 0)
		local speed = 200
		local add = mv:GetVelocity()

		if mv:KeyDown(IN_FORWARD) then wishVel = wishVel + forward end
		if mv:KeyDown(IN_BACK) then wishVel = wishVel - forward end
		if mv:KeyDown(IN_MOVERIGHT) then wishVel = wishVel + right end
		if mv:KeyDown(IN_MOVELEFT) then wishVel = wishVel - right end
		if mv:KeyDown(IN_JUMP) then wishVel.z = wishVel.z + 1 end
		if mv:KeyDown(IN_DUCK) then wishVel.z = wishVel.z - 1 end

		if wishVel:IsZero() then return end
		wishVel:Normalize()
		wishVel = wishVel * speed

		local pelvis = getPelvisPhys(rag) or rag:GetPhysicsObject()
		if IsValid(pelvis) then
			local force = (wishVel - pelvis:GetVelocity()) * pelvis:GetMass()
			pelvis:ApplyForceCenter(force)
		end
	end,

	MousePress = function(self, code)
		-- no-op
	end,

	MouseRelease = function(self, code)
		-- no-op
	end,

	Aim = function(self, angles)
		self.LastAngles = angles
		return angles
	end
})



