if SERVER then AddCSLuaFile() end

-- Admin-only context menu action on player's ragdoll: Reset Organism
properties.Add("hg_reset_organism", {
    MenuLabel = "Reset Organism",
    Order = 9999,
    MenuIcon = "icon16/heart_delete.png",

    Filter = function(self, ent, ply)
        if not IsValid(ent) then return false end
        if ent:GetClass() ~= "prop_ragdoll" then return false end
        if not IsValid(ply) or not ply:IsAdmin() then return false end
        local owner = ent:GetNWEntity("hg_ragdoll_owner")
        return IsValid(owner) and owner:IsPlayer()
    end,

    Action = function(self, ent)
        -- Send the ragdoll entity to the server; properties handles networking
        self:MsgStart()
            net.WriteEntity(ent)
        self:MsgEnd()
    end,

    Receive = function(self, len, ply)
        if not IsValid(ply) or not ply:IsAdmin() then return end
        local ent = net.ReadEntity()
        if not IsValid(ent) or ent:GetClass() ~= "prop_ragdoll" then return end
        local owner = ent:GetNWEntity("hg_ragdoll_owner")
        if not (IsValid(owner) and owner:IsPlayer()) then return end
        if HG_ResetOrganism then
            HG_ResetOrganism(owner)
            if IsValid(ply) then ply:ChatPrint("[HG] Reset organism for " .. owner:Nick()) end
        end
    end
})
