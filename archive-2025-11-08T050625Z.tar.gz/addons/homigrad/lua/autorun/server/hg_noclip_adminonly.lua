if SERVER then
    hook.Add("PlayerNoClip", "hg_AdminOnlyNoclip", function(ply, desiredState)
        if not IsValid(ply) then return false end
        if desiredState == false then return true end
        return ply:IsAdmin()
    end)
end
