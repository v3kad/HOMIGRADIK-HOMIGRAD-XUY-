-- Homigrad Armor Base (server)
if not SERVER then return end
util.AddNetworkString("hg_clear_player_armor")

 
local function _localFindHelmetIdByModel(modelPath)
    if not modelPath or modelPath == "" then return nil end
    local needle = string.lower(modelPath)
    for id, data in pairs(HG_ArmorCatalog.helmets or {}) do
        if string.lower(tostring(data.model or "")) == needle then return id end
    end
    return nil
end

local function _localFindVestIdByModel(modelPath)
    if not modelPath or modelPath == "" then return nil end
    local needle = string.lower(modelPath)
    for id, data in pairs(HG_ArmorCatalog.vests or {}) do
        if string.lower(tostring(data.model or "")) == needle then return id end
    end
    return nil
end

local function dropExistingHelmet(ply)
    if not IsValid(ply) then return end
    if not ply:GetNWBool("HG_Helmet", false) then return end
    local model = ply:GetNWString("HG_HelmetModel", "")
    if model == "" then return end
    
    ply:SetNWBool("HG_Helmet", false)
    ply:SetNWString("HG_HelmetModel", "")
    ply:SetNWString("HG_HelmetName", "")
    ply:SetNWInt("HG_HelmetArmorAmount", 0)
    local className
    do
        local id = _localFindHelmetIdByModel and _localFindHelmetIdByModel(model)
        if id and ENT_CLASS_BY_HELMET_ID then className = ENT_CLASS_BY_HELMET_ID[id] end
    end
    local ent = ents.Create(className or "prop_physics")
    if not IsValid(ent) then return end
    if not className then ent:SetModel(model) end
    ent:SetPos(ply:GetShootPos() + ply:GetAimVector() * 20)
    ent:SetAngles(Angle(0, ply:EyeAngles().y, 0))
    ent:Spawn()
    local phys = ent:GetPhysicsObject()
    if IsValid(phys) then
        phys:SetVelocity(ply:GetAimVector() * 200 + Vector(0,0,80))
    end
    HG_Armor_PlayDrop(ply)
end

local function dropExistingVest(ply)
    if not IsValid(ply) then return end
    if not ply:GetNWBool("HG_Vest", false) then return end
    local model = ply:GetNWString("HG_VestModel", "")
    if model == "" then return end
    
    ply:SetNWBool("HG_Vest", false)
    ply:SetNWString("HG_VestModel", "")
    ply:SetNWString("HG_VestName", "")
    ply:SetNWInt("HG_VestArmorAmount", 0)
    local className
    do
        local id = _localFindVestIdByModel and _localFindVestIdByModel(model)
        if id and ENT_CLASS_BY_VEST_ID then className = ENT_CLASS_BY_VEST_ID[id] end
    end
    local ent = ents.Create(className or "prop_physics")
    if not IsValid(ent) then return end
    if not className then ent:SetModel(model) end
    ent:SetPos(ply:GetShootPos() + ply:GetAimVector() * 20)
    ent:SetAngles(Angle(0, ply:EyeAngles().y, 0))
    ent:Spawn()
    local phys = ent:GetPhysicsObject()
    if IsValid(phys) then
        phys:SetVelocity(ply:GetAimVector() * 200 + Vector(0,0,80))
    end
    HG_Armor_PlayDrop(ply)
end

-- Catalog of armor items (IDs -> data)
HG_ArmorCatalog = HG_ArmorCatalog or {
    helmets = {
        fast_ops = {
            name = "Fast Ops Helmet",
            model = "models/eft_props/gear/helmets/helmet_ops_core_fast_tan.mdl",
            icon = "materials/entities/ent_jack_gmod_ezarmor_tackekfastmt.png",
            armor = 25,
            offsetPos = Vector(2.5,2,0),
            offsetAng = Angle(90,270,180) 
        },
        helm_6b47 = {
            name = "6B47 Helmet",
            model = "models/eft_props/gear/helmets/helmet_6b47.mdl",
            icon = "materials/entities/ent_jack_gmod_ezarmor_6b47.png",
            armor = 25,
            offsetPos = Vector(2.5,1,0),
            offsetAng = Angle(90,270,180) 
        },
        helm_6b47_cover = {
            name = "6B47 Cover Helmet",
            model = "models/eft_props/gear/helmets/helmet_6b47_cover.mdl",
            icon = "materials/entities/ent_jack_gmod_ezarmor_6b47chehol.png",
            armor = 25,
            offsetPos = Vector(0,0,0),
            offsetAng = Angle(90,270,180) 
        },
        ssh_68 = {
            name = "SSH-68 Helmet",
            model = "models/eft_props/gear/helmets/helmet_s_sh_68.mdl",
            icon = "materials/entities/ent_jack_gmod_ezarmor_ssh68.png",
            armor = 25,
            offsetPos = Vector(0,0,0),
            offsetAng = Angle(90,270,180) -- x вверх вниз y непон z вверх вниз
        }
    },
    vests = {
        untar = {
            name = "Untar Vest",
            model = "models/eft_props/gear/armor/ar_untar.mdl",
            icon = "materials/entities/ent_jack_gmod_ezarmor_untar.png",
            armor = 50,
            offsetPos = Vector(0,0,0),
            offsetAng = Angle(180,90,270)
        },
        thor = {
            name = "Thor Vest",
            model = "models/eft_props/gear/armor/ar_thor_crv.mdl",
            icon = "materials/entities/ent_jack_gmod_ezarmor_thorcrv.png",
            armor = 65,
            offsetPos = Vector(0,-3,0),
            offsetAng = Angle(180,90,270)
        },
        bagariy = {
            name = "Bagariy Vest",
            model = "models/eft_props/gear/armor/cr/cr_bagarii.mdl",
            icon = "materials/entities/ent_jack_gmod_ezarmor_bagariy.png",
            armor = 55,
            offsetPos = Vector(0,-3,0), -- x y z (x - верх/вниз, y - от себя/на себя, z - от влево/вправо)
            offsetAng = Angle(180,90,270)
        }
    }
}

local SND_EQUIP = "eft_gear_sounds/gear_armor_pickup.wav"
local SND_DROP  = "eft_gear_sounds/gear_armor_drop.wav"
local SND_HIT_VEST = "eft/impact/bodyarmor1_fp.wav"
local SND_HIT_HELM = "eft/impact/impact_helmet_1p_1.wav"

 
ENT_CLASS_BY_HELMET_ID = {
    fast_ops = "ent_hg_helmet_fast_ops",
    helm_6b47 = "ent_hg_helmet_6b47",
    helm_6b47_cover = "ent_hg_helmet_6b47_cover",
    ssh_68 = "ent_hg_helmet_ssh_68",
}

ENT_CLASS_BY_VEST_ID = {
    untar = "ent_hg_vest_untar",
    thor = "ent_hg_vest_thor",
    bagariy = "ent_hg_vest_bagariy",
}

-- Public helpers
function HG_PlayerArmorValue(ply)
    if not IsValid(ply) then return 0 end
    local total = 0
    if ply:GetNWBool("HG_Helmet", false) then total = total + (ply:GetNWInt("HG_HelmetArmorAmount", 0) or 0) end
    if ply:GetNWBool("HG_Vest", false) then total = total + (ply:GetNWInt("HG_VestArmorAmount", 0) or 0) end
    return total
end

local function syncArmorStat(ply)
    local total = 0
    if ply:GetNWBool("HG_Helmet", false) then total = total + ply:GetNWInt("HG_HelmetArmorAmount", 0) end
    if ply:GetNWBool("HG_Vest", false) then total = total + ply:GetNWInt("HG_VestArmorAmount", 0) end
    ply:SetArmor(total)
end

local function equipHelmet(ply, data)
    if not IsValid(ply) then return end
    ply:SetNWBool("HG_Helmet", true)
    ply:SetNWString("HG_HelmetModel", data.model or "")
    ply:SetNWString("HG_HelmetName", data.name or "Helmet")
    ply:SetNWVector("HG_HelmetOffsetPos", data.offsetPos or Vector(0,0,0))
    ply:SetNWAngle("HG_HelmetOffsetAng", data.offsetAng or Angle(0,0,0))
    ply:SetNWInt("HG_HelmetArmorAmount", tonumber(data.armor) or 0)
    syncArmorStat(ply)
    sound.Play(SND_EQUIP, ply:GetPos(), 70, 100, 1)
end

local function equipVest(ply, data)
    if not IsValid(ply) then return end
    ply:SetNWBool("HG_Vest", true)
    ply:SetNWString("HG_VestModel", data.model or "")
    ply:SetNWString("HG_VestName", data.name or "Vest")
    ply:SetNWVector("HG_VestOffsetPos", data.offsetPos or Vector(0,0,0))
    ply:SetNWAngle("HG_VestOffsetAng", data.offsetAng or Angle(0,0,0))
    ply:SetNWInt("HG_VestArmorAmount", tonumber(data.armor) or 0)
    syncArmorStat(ply)
    sound.Play(SND_EQUIP, ply:GetPos(), 70, 100, 1)
end

-- Public API
function HG_EquipHelmet(ply, id)
    local data = HG_ArmorCatalog.helmets[id]
    if not data then return false end
    
    dropExistingHelmet(ply)
    equipHelmet(ply, data)
    return true
end

function HG_EquipVest(ply, id)
    local data = HG_ArmorCatalog.vests[id]
    if not data then return false end
    
    dropExistingVest(ply)
    equipVest(ply, data)
    return true
end

-- Public drop helpers
function HG_DropHelmet(ply)
    if not IsValid(ply) then return end
    dropExistingHelmet(ply)
    -- recalc armor after drop
    local total = 0
    if ply:GetNWBool("HG_Helmet", false) then total = total + ply:GetNWInt("HG_HelmetArmorAmount", 0) end
    if ply:GetNWBool("HG_Vest", false) then total = total + ply:GetNWInt("HG_VestArmorAmount", 0) end
    ply:SetArmor(total)
end

function HG_DropVest(ply)
    if not IsValid(ply) then return end
    dropExistingVest(ply)
    -- recalc armor after drop
    local total = 0
    if ply:GetNWBool("HG_Helmet", false) then total = total + ply:GetNWInt("HG_HelmetArmorAmount", 0) end
    if ply:GetNWBool("HG_Vest", false) then total = total + ply:GetNWInt("HG_VestArmorAmount", 0) end
    ply:SetArmor(total)
end

function HG_ClearArmor(ent)
    if not IsValid(ent) then return end
    ent:SetNWBool("HG_Helmet", false)
    ent:SetNWString("HG_HelmetModel", "")
    ent:SetNWString("HG_HelmetName", "")
    ent:SetNWInt("HG_HelmetArmorAmount", 0)
    ent:SetNWBool("HG_Vest", false)
    ent:SetNWString("HG_VestModel", "")
    ent:SetNWString("HG_VestName", "")
    ent:SetNWInt("HG_VestArmorAmount", 0)
    if ent:IsPlayer() then syncArmorStat(ent) end
end

-- Ragdoll interop called by sv_ragdoll_control.lua (no visuals clientside yet, but keep state)
function HG_CopyArmorToRagdoll(ply, rag)
    if not (IsValid(ply) and IsValid(rag)) then return end
    rag:SetNWBool("HG_Helmet", ply:GetNWBool("HG_Helmet", false))
    rag:SetNWString("HG_HelmetModel", ply:GetNWString("HG_HelmetModel", ""))
    rag:SetNWString("HG_HelmetName", ply:GetNWString("HG_HelmetName", ""))
    rag:SetNWVector("HG_HelmetOffsetPos", ply:GetNWVector("HG_HelmetOffsetPos", Vector(0,0,0)))
    rag:SetNWAngle("HG_HelmetOffsetAng", ply:GetNWAngle("HG_HelmetOffsetAng", Angle(0,0,0)))
    rag:SetNWInt("HG_HelmetArmorAmount", ply:GetNWInt("HG_HelmetArmorAmount", 0))
    rag:SetNWBool("HG_Vest", ply:GetNWBool("HG_Vest", false))
    rag:SetNWString("HG_VestModel", ply:GetNWString("HG_VestModel", ""))
    rag:SetNWString("HG_VestName", ply:GetNWString("HG_VestName", ""))
    rag:SetNWVector("HG_VestOffsetPos", ply:GetNWVector("HG_VestOffsetPos", Vector(0,0,0)))
    rag:SetNWAngle("HG_VestOffsetAng", ply:GetNWAngle("HG_VestOffsetAng", Angle(0,0,0)))
    rag:SetNWInt("HG_VestArmorAmount", ply:GetNWInt("HG_VestArmorAmount", 0))
end

function HG_ReturnArmorFromRagdoll(ply, rag)
    if not (IsValid(ply) and IsValid(rag)) then return end
    if rag:GetNWBool("HG_Helmet", false) then
        ply:SetNWBool("HG_Helmet", true)
        ply:SetNWString("HG_HelmetModel", rag:GetNWString("HG_HelmetModel", ""))
        ply:SetNWString("HG_HelmetName", rag:GetNWString("HG_HelmetName", ""))
        ply:SetNWVector("HG_HelmetOffsetPos", rag:GetNWVector("HG_HelmetOffsetPos", Vector(0,0,0)))
        ply:SetNWAngle("HG_HelmetOffsetAng", rag:GetNWAngle("HG_HelmetOffsetAng", Angle(0,0,0)))
        ply:SetNWInt("HG_HelmetArmorAmount", rag:GetNWInt("HG_HelmetArmorAmount", 0))
    end
    if rag:GetNWBool("HG_Vest", false) then
        ply:SetNWBool("HG_Vest", true)
        ply:SetNWString("HG_VestModel", rag:GetNWString("HG_VestModel", ""))
        ply:SetNWString("HG_VestName", rag:GetNWString("HG_VestName", ""))
        ply:SetNWVector("HG_VestOffsetPos", rag:GetNWVector("HG_VestOffsetPos", Vector(0,0,0)))
        ply:SetNWAngle("HG_VestOffsetAng", rag:GetNWAngle("HG_VestOffsetAng", Angle(0,0,0)))
        ply:SetNWInt("HG_VestArmorAmount", rag:GetNWInt("HG_VestArmorAmount", 0))
    end
    syncArmorStat(ply)
end

-- Round cleanup referenced by manager.lua
function HG_Armor_RoundEndCleanup()
    for _, ply in ipairs(player.GetAll()) do
        if IsValid(ply) then
            HG_ClearArmor(ply)
            if net then
                net.Start("hg_clear_player_armor")
                    net.WriteEntity(ply)
                net.Broadcast()
            end
        end
    end
end

-- Simple console helpers for testing
concommand.Add("hg_give_helmet", function(ply, _, args)
    if not IsValid(ply) then return end
    if not ply:IsAdmin() then return end
    local id = args[1] or "helm_6b47"
    if HG_EquipHelmet(ply, id) then
        ply:ChatPrint("Вы надели: " .. (HG_ArmorCatalog.helmets[id].name or id))
    else
        ply:ChatPrint("Шлем не найден: " .. tostring(id))
    end
end)

-- Ragdoll armor offset adjusters
local function getTargetRagdoll(ply)
    if not IsValid(ply) then return nil end
    local rag = ply:GetNWEntity("hg_ragdoll_entity")
    if IsValid(rag) and rag:GetClass() == "prop_ragdoll" then return rag end
    return nil
end

local function parseVec(args, def)
    def = def or Vector(0,0,0)
    local x = tonumber(args[1]) or def.x
    local y = tonumber(args[2]) or def.y
    local z = tonumber(args[3]) or def.z
    return Vector(x,y,z)
end

local function parseAng(args, def)
    def = def or Angle(0,0,0)
    local p = tonumber(args[1]) or def.p
    local y = tonumber(args[2]) or def.y
    local r = tonumber(args[3]) or def.r
    return Angle(p,y,r)
end

concommand.Add("hg_rag_helmet_offset", function(ply, _, args)
    if not (IsValid(ply) and ply:IsAdmin()) then return end
    local rag = getTargetRagdoll(ply)
    if not IsValid(rag) then ply:ChatPrint("Рэгдолл не найден.") return end
    local cur = rag:GetNWVector("HG_HelmetOffsetPos", Vector(0,0,0))
    local v = parseVec(args, cur)
    rag:SetNWVector("HG_HelmetOffsetPos", v)
end)

concommand.Add("hg_rag_helmet_ang", function(ply, _, args)
    if not (IsValid(ply) and ply:IsAdmin()) then return end
    local rag = getTargetRagdoll(ply)
    if not IsValid(rag) then ply:ChatPrint("Рэгдолл не найден.") return end
    local cur = rag:GetNWAngle("HG_HelmetOffsetAng", Angle(0,0,0))
    local a = parseAng(args, cur)
    rag:SetNWAngle("HG_HelmetOffsetAng", a)
end)

concommand.Add("hg_rag_vest_offset", function(ply, _, args)
    if not (IsValid(ply) and ply:IsAdmin()) then return end
    local rag = getTargetRagdoll(ply)
    if not IsValid(rag) then ply:ChatPrint("Рэгдолл не найден.") return end
    local cur = rag:GetNWVector("HG_VestOffsetPos", Vector(0,0,0))
    local v = parseVec(args, cur)
    rag:SetNWVector("HG_VestOffsetPos", v)
end)

concommand.Add("hg_rag_vest_ang", function(ply, _, args)
    if not (IsValid(ply) and ply:IsAdmin()) then return end
    local rag = getTargetRagdoll(ply)
    if not IsValid(rag) then ply:ChatPrint("Рэгдолл не найден.") return end
    local cur = rag:GetNWAngle("HG_VestOffsetAng", Angle(0,0,0))
    local a = parseAng(args, cur)
    rag:SetNWAngle("HG_VestOffsetAng", a)
end)

concommand.Add("hg_give_vest", function(ply, _, args)
    if not IsValid(ply) then return end
    if not ply:IsAdmin() then return end
    local id = args[1] or "untar"
    if HG_EquipVest(ply, id) then
        ply:ChatPrint("Вы надели: " .. (HG_ArmorCatalog.vests[id].name or id))
    else
        ply:ChatPrint("Бронежилет не найден: " .. tostring(id))
    end
end)

-- Expose hit sounds for other modules
function HG_Armor_PlayImpact(ply, isHelmet)
    if not IsValid(ply) then return end
    local snd = isHelmet and SND_HIT_HELM or SND_HIT_VEST
    sound.Play(snd, ply:GetPos(), 75, 100, 1)
end

-- Unequip sound helper used by loot or others
function HG_Armor_PlayDrop(ply)
    if not IsValid(ply) then return end
    sound.Play(SND_DROP, ply:GetPos(), 70, 100, 1)
end

-- Map model path to catalog IDs and equip helpers
local function _findHelmetIdByModel(modelPath)
    if not modelPath or modelPath == "" then return nil end
    local needle = string.lower(modelPath)
    for id, data in pairs(HG_ArmorCatalog.helmets or {}) do
        if string.lower(tostring(data.model or "")) == needle then return id end
    end
    return nil
end

local function _findVestIdByModel(modelPath)
    if not modelPath or modelPath == "" then return nil end
    local needle = string.lower(modelPath)
    for id, data in pairs(HG_ArmorCatalog.vests or {}) do
        if string.lower(tostring(data.model or "")) == needle then return id end
    end
    return nil
end

function HG_GiveHelmetByModel(ply, modelPath)
    local id = _findHelmetIdByModel(modelPath)
    if not id then return false end
    return HG_EquipHelmet(ply, id)
end

function HG_GiveVestByModel(ply, modelPath)
    local id = _findVestIdByModel(modelPath)
    if not id then return false end
    return HG_EquipVest(ply, id)
end

-- Allow using prop_physics armor models to equip directly (legacy drops/map props)
hook.Add("PlayerUse", "HG_Armor_UsePropToEquip", function(ply, ent)
    if not (IsValid(ply) and IsValid(ent)) then return end
    if ent:GetClass() ~= "prop_physics" then return end
    local mdl = string.lower(tostring(ent:GetModel() or ""))
    if mdl == "" then return end

    local hid = _findHelmetIdByModel and _findHelmetIdByModel(mdl) or nil
    if hid and HG_EquipHelmet and HG_EquipHelmet(ply, hid) then
        ent:Remove()
        return false
    end

    local vid = _findVestIdByModel and _findVestIdByModel(mdl) or nil
    if vid and HG_EquipVest and HG_EquipVest(ply, vid) then
        ent:Remove()
        return false
    end
end)
