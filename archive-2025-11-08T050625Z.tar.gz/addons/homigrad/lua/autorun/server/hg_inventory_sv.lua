if SERVER then
    util.AddNetworkString("HG_Inventory_Request")
    util.AddNetworkString("HG_Inventory_Send")
    util.AddNetworkString("HG_Inventory_DropItem")
    util.AddNetworkString("HG_Inventory_Unequip")
    util.AddNetworkString("HG_Loot_TakeItem")
    util.AddNetworkString("HG_Inventory_UnloadWeapon")
    util.AddNetworkString("HG_Loot_Open")
    util.AddNetworkString("HG_Loot_Close")

    local function GetInventory(ply)
        ply.HG_Inventory = ply.HG_Inventory or {}
        return ply.HG_Inventory
    end

    -- Ensure dropped weapons don't get stuck: reinitialize physics and give a small impulse
    local function HG_SafeDropWeapon(ply, wep)
        if not (IsValid(ply) and IsValid(wep)) then return end
        local forward = ply:GetAimVector()
        local dropPos = ply:GetShootPos() + forward * 20 + Vector(0,0,10)
        local vel = forward * 220 + Vector(0,0,60)
        ply:DropWeapon(wep)
        if not IsValid(wep) then return end
        wep:SetPos(dropPos)
        wep:SetAngles(Angle(0, ply:EyeAngles().y, 0))
        if wep.PhysicsInit then wep:PhysicsInit(SOLID_VPHYSICS) end
        if wep.SetMoveType then wep:SetMoveType(MOVETYPE_VPHYSICS) end
        if wep.SetSolid then wep:SetSolid(SOLID_VPHYSICS) end
        local phys = wep.GetPhysicsObject and wep:GetPhysicsObject() or nil
        if IsValid(phys) then
            phys:Wake()
            phys:SetVelocity(vel)
        end
    end

    local SELF_MAX_SLOTS = 7
    local function BuildInventoryFromPlayer(ply, forLoot)
        local items = {}
        local maxSlots = forLoot and math.huge or SELF_MAX_SLOTS
        -- Weapons first
        for _, wep in ipairs(ply:GetWeapons() or {}) do
            if #items >= maxSlots then break end
            local class = wep:GetClass()
            if not (class == "wep_hands" or class == "weapon_hands") then
                table.insert(items, {
                    kind = "weapon",
                    class = class,
                    name = (wep.PrintName or class)
                })
            end
        end
        if forLoot then
            -- Include equipped armor from NW vars
            if ply:GetNWBool("HG_Helmet", false) then
                table.insert(items, {
                    kind = "helmet",
                    name = ply:GetNWString("HG_HelmetName", "Шлем"),
                    model = ply:GetNWString("HG_HelmetModel", ""),
                })
            end
            if ply:GetNWBool("HG_Vest", false) then
                table.insert(items, {
                    kind = "vest",
                    name = ply:GetNWString("HG_VestName", "Бронежилет"),
                    model = ply:GetNWString("HG_VestModel", ""),
                })
            end
            -- Include ammo by types used by player's weapons
            local seen = {}
            for _, w in ipairs(ply:GetWeapons() or {}) do
                local at = w.GetPrimaryAmmoType and w:GetPrimaryAmmoType() or -1
                if at and at > -1 and not seen[at] then
                    seen[at] = true
                    local cnt = ply:GetAmmoCount(at)
                    if cnt and cnt > 0 then
                        table.insert(items, {
                            kind = "ammo",
                            name = game.GetAmmoName(at) or "Ammo",
                            amount = cnt,
                            ammoType = at
                        })
                    end
                end
            end
        else
            -- Self inventory: show ammo for all carried weapon ammo types (not only active)
            if #items < SELF_MAX_SLOTS then
                local seen = {}
                for _, w in ipairs(ply:GetWeapons() or {}) do
                    if #items >= SELF_MAX_SLOTS then break end
                    local at = w.GetPrimaryAmmoType and w:GetPrimaryAmmoType() or -1
                    if at and at > -1 and not seen[at] then
                        seen[at] = true
                        local cnt = ply:GetAmmoCount(at)
                        if cnt and cnt > 0 then
                            table.insert(items, {
                                kind = "ammo",
                                name = game.GetAmmoName(at) or "Ammo",
                                amount = cnt,
                                ammoType = at
                            })
                        end
                    end
                end
            end
        end
        return items
    end

    local function IsRagdolled(ply)
        if not IsValid(ply) then return false end
        if HG_IsRagdolled and HG_IsRagdolled(ply) then return true end
        if ply.GetNWBool and ply:GetNWBool("hg_pain_ragdoll", false) then return true end
        return false
    end

    net.Receive("HG_Inventory_Request", function(_, ply)
        local inv = BuildInventoryFromPlayer(ply, false)
        net.Start("HG_Inventory_Send")
        net.WriteTable(inv)
        net.Send(ply)
    end)

    net.Receive("HG_Inventory_DropItem", function(_, ply)
        local idx = net.ReadInt(8)
        local inv = BuildInventoryFromPlayer(ply, false)
        if not (isnumber(idx) and idx >= 1 and idx <= #inv) then return end
        local item = inv[idx]
        if not item then return end
        if item.kind == "weapon" and item.class then
            -- find player's weapon by class
            local target
            for _, wep in ipairs(ply:GetWeapons() or {}) do
                if wep:GetClass() == item.class then target = wep break end
            end
            if IsValid(target) then
                -- If active weapon is the one dropped, switch to another to avoid issues
                if ply:GetActiveWeapon() == target then
                    for _, wep in ipairs(ply:GetWeapons() or {}) do
                        if wep ~= target then ply:SelectWeapon(wep:GetClass()) break end
                    end
                end
                HG_SafeDropWeapon(ply, target)
            end
        end
        -- Send updated inventory after action
        local newInv = BuildInventoryFromPlayer(ply, false)
        net.Start("HG_Inventory_Send")
        net.WriteTable(newInv)
        net.Send(ply)
        hook.Run("HG_Inventory_Update", ply)
    end)

    net.Receive("HG_Inventory_Unequip", function(_, ply)
        local which = net.ReadString() or ""
        if which == "helmet" then
            if HG_DropHelmet then
                HG_DropHelmet(ply)
            else
                if ply:GetNWBool("HG_Helmet", false) then
                    ply:SetNWBool("HG_Helmet", false)
                    ply:SetNWString("HG_HelmetModel", "")
                    ply:SetNWString("HG_HelmetName", "")
                    ply:SetNWInt("HG_HelmetArmorAmount", 0)
                    if HG_Armor_PlayDrop then HG_Armor_PlayDrop(ply) end
                end
            end
        elseif which == "vest" then
            if HG_DropVest then
                HG_DropVest(ply)
            else
                if ply:GetNWBool("HG_Vest", false) then
                    ply:SetNWBool("HG_Vest", false)
                    ply:SetNWString("HG_VestModel", "")
                    ply:SetNWString("HG_VestName", "")
                    ply:SetNWInt("HG_VestArmorAmount", 0)
                    if HG_Armor_PlayDrop then HG_Armor_PlayDrop(ply) end
                end
            end
        end
        local total = 0
        if ply:GetNWBool("HG_Helmet", false) then total = total + (ply:GetNWInt("HG_HelmetArmorAmount", 0) or 0) end
        if ply:GetNWBool("HG_Vest", false) then total = total + (ply:GetNWInt("HG_VestArmorAmount", 0) or 0) end
        ply:SetArmor(total)
    end)

    net.Receive("HG_Loot_TakeItem", function(_, ply)
        local src = net.ReadEntity()
        local idx = net.ReadInt(8)
        hook.Run("HG_Loot_TakeItem", ply, src, idx)
    end)

    net.Receive("HG_Inventory_UnloadWeapon", function(_, ply)
        local idx = net.ReadInt(8)
        local inv = BuildInventoryFromPlayer(ply, false)
        if not (isnumber(idx) and idx >= 1 and idx <= #inv) then return end
        local item = inv[idx]
        if not item or item.kind ~= "weapon" or not item.class then return end
        local target
        for _, wep in ipairs(ply:GetWeapons() or {}) do
            if wep:GetClass() == item.class then target = wep break end
        end
        if not IsValid(target) then return end
        -- Unload primary clip into reserve
        local clip = target:Clip1() or 0
        if clip > 0 then
            local atype = target:GetPrimaryAmmoType()
            if atype and atype > -1 then
                ply:GiveAmmo(clip, atype, true)
                target:SetClip1(0)
            end
        end
        -- send updated inventory so clip change and ammo count reflect
        local newInv = BuildInventoryFromPlayer(ply, false)
        net.Start("HG_Inventory_Send")
        net.WriteTable(newInv)
        net.Send(ply)
    end)

    -- Open loot view on using a ragdoll/corpse or loot case
    local LOOT_MAX_DIST = 80
    hook.Add("PlayerUse", "HG_Loot_OpenOnUse", function(ply, ent)
        if not IsValid(ply) or not IsValid(ent) then return end
        if IsRagdolled(ply) then return end
        if ply.HG_IsLooting then return end
        if ply:GetPos():Distance(ent:GetPos()) > LOOT_MAX_DIST then return end
        local cls = ent:GetClass() or ""
        if cls == "prop_ragdoll" then
            local owner = ent:GetNWEntity("hg_ragdoll_owner")
            if not IsValid(owner) or not owner:IsPlayer() then return end
            local inv = ent.HG_LootInventory or BuildInventoryFromPlayer(owner, true)
            net.Start("HG_Loot_Open")
                net.WriteEntity(ent)
                net.WriteString(owner:Nick() or "Игрок")
                net.WriteTable(inv)
            net.Send(ply)
            ply.HG_IsLooting = true
        elseif string.StartWith(cls, "hg_loot_case_") then
            local title = ent.PrintName or "Кейс"
            local inv = ent.HG_LootInventory or {}
            net.Start("HG_Loot_Open")
                net.WriteEntity(ent)
                net.WriteString(title)
                net.WriteTable(inv)
            net.Send(ply)
            ply.HG_IsLooting = true
        end
    end)

    -- Fallback: open loot on E press while looking at ragdoll or loot case
    hook.Add("KeyPress", "HG_Loot_OpenOnKeyPress", function(ply, key)
        if key ~= IN_USE then return end
        if not IsValid(ply) then return end
        if IsRagdolled(ply) then return end
        if ply.HG_IsLooting then return end
        local tr = util.TraceLine({
            start = ply:EyePos(),
            endpos = ply:EyePos() + ply:EyeAngles():Forward() * 100,
            filter = ply
        })
        local ent = tr.Entity
        if not IsValid(ent) then return end
        if ply:GetPos():Distance(ent:GetPos()) > LOOT_MAX_DIST then return end
        local cls = ent:GetClass() or ""
        if cls == "prop_ragdoll" then
            local owner = ent:GetNWEntity("hg_ragdoll_owner")
            if not IsValid(owner) or not owner:IsPlayer() then return end
            local inv = ent.HG_LootInventory or BuildInventoryFromPlayer(owner, true)
            net.Start("HG_Loot_Open")
                net.WriteEntity(ent)
                net.WriteString(owner:Nick() or "Игрок")
                net.WriteTable(inv)
            net.Send(ply)
            ply.HG_IsLooting = true
        elseif string.StartWith(cls, "hg_loot_case_") then
            local title = ent.PrintName or "Кейс"
            local inv = ent.HG_LootInventory or {}
            net.Start("HG_Loot_Open")
                net.WriteEntity(ent)
                net.WriteString(title)
                net.WriteTable(inv)
            net.Send(ply)
            ply.HG_IsLooting = true
        end
    end)

    -- Client notifies server when loot UI closed so we can allow re-open on next E
    net.Receive("HG_Loot_Close", function(_, ply)
        if not IsValid(ply) then return end
        ply.HG_IsLooting = false
    end)

    -- Default loot handler: transfer item from ragdoll owner to looter, or from loot case
    hook.Add("HG_Loot_TakeItem", "HG_DefaultLootHandler", function(looter, src, idx)
        if not IsValid(looter) or not IsValid(src) then return end
        if IsRagdolled(looter) then return end
        if looter:GetPos():Distance(src:GetPos()) > LOOT_MAX_DIST then return end
        local cls = src:GetClass() or ""
        if string.StartWith(cls, "hg_loot_case_") then
            local inv = src.HG_LootInventory or {}
            if not (isnumber(idx) and idx >= 1 and idx <= #inv) then return end
            if src.OnTakeFromCase then src:OnTakeFromCase(looter, idx) end
            -- refresh case loot view
            net.Start("HG_Loot_Open")
                net.WriteEntity(src)
                net.WriteString(src.PrintName or "Кейс")
                net.WriteTable(src.HG_LootInventory or {})
            net.Send(looter)
            -- also refresh looter inventory panel if open
            local looterInv = BuildInventoryFromPlayer(looter, false)
            net.Start("HG_Inventory_Send")
                net.WriteTable(looterInv)
            net.Send(looter)
            hook.Run("HG_Inventory_Update", looter)
            return
        end
        if cls ~= "prop_ragdoll" then return end
        local owner = src:GetNWEntity("hg_ragdoll_owner")
        if not IsValid(owner) or not owner:IsPlayer() then return end

        -- read from ragdoll snapshot if present
        src.HG_LootInventory = src.HG_LootInventory or BuildInventoryFromPlayer(owner, true)
        local inv = src.HG_LootInventory
        if not (isnumber(idx) and idx >= 1 and idx <= #inv) then return end
        local item = inv[idx]
        if not item then return end

        if item.kind == "weapon" and item.class then
            -- remove from owner, give to looter (swap if looter already has)
            if owner:HasWeapon(item.class) then
                -- Avoid dropping; strip and give
                owner:StripWeapon(item.class)
            end
            if looter:HasWeapon(item.class) then
                -- Drop existing weapon to make room
                local target
                for _, wep in ipairs(looter:GetWeapons() or {}) do
                    if wep:GetClass() == item.class then target = wep break end
                end
                if IsValid(target) then
                    -- If active weapon is the one dropped, try switch
                    if looter:GetActiveWeapon() == target then
                        for _, w in ipairs(looter:GetWeapons() or {}) do if w ~= target then looter:SelectWeapon(w:GetClass()) break end end
                    end
                    HG_SafeDropWeapon(looter, target)
                end
            end
            looter:Give(item.class)
            -- remove from snapshot
            table.remove(inv, idx)
        elseif item.kind == "helmet" then
            -- Transfer helmet by model if possible
            local mdl = tostring(item.model or "")
            if mdl ~= "" and HG_GiveHelmetByModel then
                -- Clear from owner
                if owner:GetNWBool("HG_Helmet", false) and owner:GetNWString("HG_HelmetModel", "") == mdl then
                    owner:SetNWBool("HG_Helmet", false)
                    owner:SetNWString("HG_HelmetModel", "")
                    owner:SetNWString("HG_HelmetName", "")
                    owner:SetNWInt("HG_HelmetArmorAmount", 0)
                end
                -- If looter already has a helmet, drop it first
                if looter:GetNWBool("HG_Helmet", false) and HG_DropHelmet then
                    HG_DropHelmet(looter)
                end
                -- Clear from ragdoll so visuals disappear
                if IsValid(src) and src:GetClass() == "prop_ragdoll" then
                    src:SetNWBool("HG_Helmet", false)
                    src:SetNWString("HG_HelmetModel", "")
                    src:SetNWString("HG_HelmetName", "")
                    src:SetNWInt("HG_HelmetArmorAmount", 0)
                end
                HG_GiveHelmetByModel(looter, mdl)
                table.remove(inv, idx)
            end
        elseif item.kind == "vest" then
            -- Transfer vest by model if possible
            local mdl = tostring(item.model or "")
            if mdl ~= "" and HG_GiveVestByModel then
                if owner:GetNWBool("HG_Vest", false) and owner:GetNWString("HG_VestModel", "") == mdl then
                    owner:SetNWBool("HG_Vest", false)
                    owner:SetNWString("HG_VestModel", "")
                    owner:SetNWString("HG_VestName", "")
                    owner:SetNWInt("HG_VestArmorAmount", 0)
                end
                -- If looter already has a vest, drop it first
                if looter:GetNWBool("HG_Vest", false) and HG_DropVest then
                    HG_DropVest(looter)
                end
                -- Clear from ragdoll so visuals disappear
                if IsValid(src) and src:GetClass() == "prop_ragdoll" then
                    src:SetNWBool("HG_Vest", false)
                    src:SetNWString("HG_VestModel", "")
                    src:SetNWString("HG_VestName", "")
                    src:SetNWInt("HG_VestArmorAmount", 0)
                end
                HG_GiveVestByModel(looter, mdl)
                table.remove(inv, idx)
            end
        elseif item.kind == "ammo" then
            -- Transfer ammo by stored ammoType if present, else use owner's active weapon type
            local atype = tonumber(item.ammoType or -1)
            if not atype or atype < 0 then
                local aw = owner:GetActiveWeapon()
                if IsValid(aw) then atype = aw:GetPrimaryAmmoType() or -1 end
            end
            if atype and atype > -1 then
                local have = owner:GetAmmoCount(atype)
                local amount = tonumber(item.amount or 0) or 0
                local take = math.min(have or 0, amount)
                if take > 0 then
                    owner:RemoveAmmo(take, atype)
                    looter:GiveAmmo(take, atype, true)
                end
                -- decrease or remove from snapshot
                amount = amount - take
                if amount > 0 then
                    inv[idx].amount = amount
                else
                    table.remove(inv, idx)
                end
            end
        end

        -- refresh views: send updated loot to looter and update their own inventory
        local newInv = inv
        net.Start("HG_Loot_Open")
            net.WriteEntity(src)
            net.WriteString(owner:Nick() or "Игрок")
            net.WriteTable(newInv)
        net.Send(looter)

        -- also refresh looter inventory panel if open
        local looterInv = BuildInventoryFromPlayer(looter, false)
        net.Start("HG_Inventory_Send")
            net.WriteTable(looterInv)
        net.Send(looter)
        hook.Run("HG_Inventory_Update", looter)
    end)

    hook.Add("PlayerInitialSpawn", "HG_Inventory_Init", function(ply)
        GetInventory(ply)
    end)

    hook.Add("PlayerDisconnected", "HG_Inventory_Cleanup", function(ply)
        ply.HG_Inventory = nil
    end)

    -- Swap-on-pickup for weapons: if player already has the same class, drop theirs first
    hook.Add("PlayerCanPickupWeapon", "HG_SwapDuplicateWeaponPickup", function(ply, wep)
        if not (IsValid(ply) and IsValid(wep)) then return end
        local class = wep:GetClass()
        if not class or class == "" then return end
        if not ply:HasWeapon(class) then return end
        -- find player's current weapon of this class
        local current
        for _, w in ipairs(ply:GetWeapons() or {}) do
            if IsValid(w) and w:GetClass() == class then current = w break end
        end
        if IsValid(current) then
            -- if active, switch away to avoid dropping active weapon glitches
            if ply:GetActiveWeapon() == current then
                for _, w in ipairs(ply:GetWeapons() or {}) do if w ~= current then ply:SelectWeapon(w:GetClass()) break end end
            end
            HG_SafeDropWeapon(ply, current)
        end
        return true
    end)
end


