if not SERVER then return end

HG_LootSpawns = HG_LootSpawns or {}

util.AddNetworkString("HG_LootSpawns_Points")

local function dataPath()
    local map = game.GetMap() or "unknown"
    return "homigrad/loot_spawns_" .. map .. ".json"
end

local function ensureDataDir()
    if not file.IsDir("homigrad", "DATA") then
        file.CreateDir("homigrad")
    end
end

function HG_LootSpawns.Load()
    ensureDataDir()
    local path = dataPath()
    if not file.Exists(path, "DATA") then
        HG_LootSpawns.points = { melee = {}, guns = {}, med = {} }
        return HG_LootSpawns.points
    end
    local raw = file.Read(path, "DATA") or "{}"
    local t = util.JSONToTable(raw) or {}
    t.melee = t.melee or {}
    t.guns  = t.guns  or {}
    t.med   = t.med   or {}
    HG_LootSpawns.points = t
    return t
end

function HG_LootSpawns.Save()
    ensureDataDir()
    local path = dataPath()
    local t = HG_LootSpawns.points or { melee = {}, guns = {}, med = {} }
    file.Write(path, util.TableToJSON(t, true))
end

local CLASS_BY_TYPE = {
    melee = "hg_loot_case_melee",
    guns  = "hg_loot_case_guns",
    med   = "hg_loot_case_med",
}

-- Remove existing cases and spawn fresh ones for mode 'homicide'
function HG_LootSpawns.SpawnForMode(modeId)
    if modeId ~= "homicide" then return end
    -- cleanup any previous cases
    for _, ent in ipairs(ents.FindByClass("hg_loot_case_*")) do
        if IsValid(ent) then ent:Remove() end
    end
    local pts = HG_LootSpawns.points or HG_LootSpawns.Load()
    local function spawnType(tt)
        local cls = CLASS_BY_TYPE[tt]
        if not cls then return end
        for _, p in ipairs(pts[tt] or {}) do
            local ent = ents.Create(cls)
            if not IsValid(ent) then continue end
            ent:SetPos(Vector(p.x, p.y, p.z))
            ent:SetAngles(Angle(p.p, p.yw, p.r))
            ent:Spawn()
            ent:Activate()
        end
    end
    spawnType("melee")
    spawnType("guns")
    spawnType("med")
end

function HG_LootSpawns.Cleanup()
    for _, ent in ipairs(ents.FindByClass("hg_loot_case_*")) do
        if IsValid(ent) then ent:Remove() end
    end
end

-- Utility to add/remove points
local function addPoint(tt, pos, ang)
    HG_LootSpawns.points = HG_LootSpawns.points or HG_LootSpawns.Load()
    local list = HG_LootSpawns.points[tt]
    if not list then return end
    table.insert(list, { x = pos.x, y = pos.y, z = pos.z, p = ang.p, yw = ang.y, r = ang.r })
    HG_LootSpawns.Save()
end

local function removeNearest(tt, pos, dist)
    HG_LootSpawns.points = HG_LootSpawns.points or HG_LootSpawns.Load()
    local list = HG_LootSpawns.points[tt]
    if not list or #list == 0 then return false end
    local bestIdx, bestD = nil, math.huge
    for i, p in ipairs(list) do
        local d = pos:Distance(Vector(p.x, p.y, p.z))
        if d < bestD then bestD = d bestIdx = i end
    end
    if bestIdx and bestD <= (dist or 128) then
        table.remove(list, bestIdx)
        HG_LootSpawns.Save()
        return true
    end
    return false
end

-- Expose for tools
HG_LootSpawns.AddPoint = addPoint
HG_LootSpawns.RemoveNearest = removeNearest

-- Debug console commands for admins
concommand.Add("hg_loot_spawn_homicide", function(ply)
    if IsValid(ply) and not ply:IsSuperAdmin() then return end
    HG_LootSpawns.SpawnForMode("homicide")
end)

-- Networking: allow a superadmin client to request all spawn points for visualization
net.Receive("HG_LootSpawns_Points", function(len, ply)
    if not IsValid(ply) or not ply:IsPlayer() then return end
    if not ply:IsSuperAdmin() then return end
    local pts = HG_LootSpawns.points or HG_LootSpawns.Load()
    net.Start("HG_LootSpawns_Points")
        net.WriteTable(pts)
    net.Send(ply)
end)
