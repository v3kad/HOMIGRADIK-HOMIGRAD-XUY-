if not SERVER then return end

util.AddNetworkString("HG_SpawnEditor_Toggle")
util.AddNetworkString("HG_SpawnEditor_Add")
util.AddNetworkString("HG_SpawnEditor_Remove")

local editorEnabled = editorEnabled or {}

net.Receive("HG_SpawnEditor_Toggle", function(_, ply)
	if not IsValid(ply) or not ply:IsAdmin() then return end
	local on = net.ReadBool()
	editorEnabled[ply] = on and true or nil
	ply:ChatPrint("[HG] Map Pointer " .. (on and "ON" or "OFF"))
end)

net.Receive("HG_SpawnEditor_Add", function(_, ply)
	if not editorEnabled[ply] or not ply:IsAdmin() then return end
	local pos = net.ReadVector()
	local typ = net.ReadString() or "dm"
	local ent = ents.Create("homigrad_spawnpoint")
	if not IsValid(ent) then return end
	ent:SetPos(pos)
	ent:Spawn()
	ent:SetSpawnType(typ)
end)

net.Receive("HG_SpawnEditor_Remove", function(_, ply)
	if not editorEnabled[ply] or not ply:IsAdmin() then return end
	local pos = net.ReadVector()
	local rad = net.ReadFloat() or 32
	local closest, best = nil, math.huge
	for _, ent in ipairs(ents.FindByClass("homigrad_spawnpoint")) do
		if not IsValid(ent) then continue end
		local d = ent:GetPos():DistToSqr(pos)
		if d < best and d <= (rad * rad) then
			best = d
			closest = ent
		end
	end
	if IsValid(closest) then closest:Remove() end
end)

hook.Add("PlayerDisconnected", "HG_SpawnEditor_Cleanup", function(ply)
	editorEnabled[ply] = nil
end)



