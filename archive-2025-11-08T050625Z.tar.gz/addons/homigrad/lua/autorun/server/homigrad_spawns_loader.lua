if SERVER then

local function getDataPath()
	return string.format("homigrad_spawns/%s.json", game.GetMap())
end

local function ensureDataDir()
	if not file.IsDir("homigrad_spawns", "DATA") then
		file.CreateDir("homigrad_spawns")
	end
end

function HOMIGRAD_GetSpawnPoints(spawnType)
	local out = {}
	for _, ent in ipairs(ents.FindByClass("homigrad_spawnpoint")) do
		if IsValid(ent) and ent:GetSpawnType() == spawnType then
			table.insert(out, ent:GetPos())
		end
	end
	return out
end

local function clearAllSpawnEntities()
	for _, ent in ipairs(ents.FindByClass("homigrad_spawnpoint")) do
		if IsValid(ent) then ent:Remove() end
	end
end

local function loadSpawns()
	-- prevent autosave during load
	_isLoadingSpawns = true
	ensureDataDir()
	local path = getDataPath()
	if not file.Exists(path, "DATA") then
		_isLoadingSpawns = false
		return
	end
	local raw = file.Read(path, "DATA") or "{}"
	local ok, data = pcall(util.JSONToTable, raw)
	if not ok or type(data) ~= "table" then
		_isLoadingSpawns = false
		return
	end
	for _, s in ipairs(data) do
		local pos = Vector(s.x or 0, s.y or 0, s.z or 0)
		local typ = tostring(s.t or "dm")
		local ent = ents.Create("homigrad_spawnpoint")
		if not IsValid(ent) then continue end
		ent:SetPos(pos)
		ent:Spawn()
		ent:SetSpawnType(typ)
	end
	_isLoadingSpawns = false
end

local function saveSpawns(ply)
	if IsValid(ply) and not ply:IsAdmin() then return end
	ensureDataDir()
	local list = {}
	for _, ent in ipairs(ents.FindByClass("homigrad_spawnpoint")) do
		if IsValid(ent) then
			local p = ent:GetPos()
			table.insert(list, { x = p.x, y = p.y, z = p.z, t = ent:GetSpawnType() or "dm" })
		end
	end
	file.Write(getDataPath(), util.TableToJSON(list, true))
	if IsValid(ply) then ply:ChatPrint("[Homigrad] Spawn points saved for map " .. game.GetMap()) end
end

-- Expose global saver for other scripts/tools
function HOMIGRAD_SaveSpawns()
	saveSpawns(nil)
end

-- Debounced autosave on changes
local function scheduleAutosave()
	if _isLoadingSpawns then return end
	if timer.Exists("homigrad_spawns_autosave") then
		timer.Adjust("homigrad_spawns_autosave", 1, 1)
		return
	end
	timer.Create("homigrad_spawns_autosave", 1, 1, function()
		HOMIGRAD_SaveSpawns()
		if SERVER then print("[Homigrad] Spawn points autosaved for map " .. game.GetMap()) end
	end)
end

concommand.Add("hg_spawns_save", function(ply)
	saveSpawns(ply)
end)

concommand.Add("hg_spawns_load", function(ply)
	if IsValid(ply) and not ply:IsAdmin() then return end
	clearAllSpawnEntities()
	loadSpawns()
	if IsValid(ply) then ply:ChatPrint("[Homigrad] Spawn points loaded for map " .. game.GetMap()) end
end)

concommand.Add("hg_spawns_clear", function(ply)
	if IsValid(ply) and not ply:IsAdmin() then return end
	clearAllSpawnEntities()
	if IsValid(ply) then ply:ChatPrint("[Homigrad] Spawn entities cleared (not saved)") end
end)

hook.Add("InitPostEntity", "Homigrad_LoadSpawns_OnInit", function()
	loadSpawns()
end)

hook.Add("PostCleanupMap", "Homigrad_LoadSpawns_OnCleanup", function()
	loadSpawns()
end)

-- Track entity changes to autosave
hook.Add("OnEntityCreated", "Homigrad_Spawns_TrackCreate", function(ent)
	if not IsValid(ent) then return end
	if ent:GetClass() ~= "homigrad_spawnpoint" then return end
	-- Delay a tick to ensure position/type set, then schedule save
	timer.Simple(0, scheduleAutosave)
end)

hook.Add("EntityRemoved", "Homigrad_Spawns_TrackRemove", function(ent)
	if not IsValid(ent) then return end
	if ent:GetClass() ~= "homigrad_spawnpoint" then return end
	scheduleAutosave()
end)

-- Save on server shutdown as a safety net
hook.Add("ShutDown", "Homigrad_Spawns_SaveOnShutdown", function()
	HOMIGRAD_SaveSpawns()
end)

end



