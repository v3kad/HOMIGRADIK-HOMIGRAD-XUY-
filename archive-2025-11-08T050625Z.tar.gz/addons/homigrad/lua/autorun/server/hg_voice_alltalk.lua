hook.Add("PlayerCanHearPlayersVoice", "HG_ForceAllTalk", function(listener, talker)
    if not IsValid(listener) or not IsValid(talker) then return end
    if listener:Alive() and not talker:Alive() then
        return false, false
    end
    return true, true
end)
