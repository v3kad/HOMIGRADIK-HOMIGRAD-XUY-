if SERVER then
    print("[Homigrad] addon present. Place in addons/ and select gamemode 'Homigrad' in server settings.")
end

if CLIENT then
    print("[Homigrad] client autorun loaded")
end
