-- Shows an ammo fill bar when pressing R (reload)
-- Does not block reload; purely visual

if SERVER then return end

local SHOW_TIME = 1.6
local lastShowUntil = 0
local barAlpha = 0
local FADE_IN_SPEED = 10    -- higher = faster
local FADE_OUT_SPEED = 4    -- lower than in-speed for nicer tail

local function canShow(ply, wep)
    if not IsValid(ply) or ply ~= LocalPlayer() then return false end
    if not ply:Alive() then return false end
    if not IsValid(wep) then return false end
    if not wep.Clip1 or not wep.GetMaxClip1 then return false end
    local max = wep:GetMaxClip1()
    if not max or max <= 0 then return false end
    return true
end

hook.Add("PlayerBindPress", "HG_ShowAmmoBarOnReload", function(ply, bind, pressed)
    if ply ~= LocalPlayer() then return end
    if not pressed then return end
    if bind ~= "+reload" and bind ~= "reload" then return end

    local wep = ply:GetActiveWeapon()
    if not canShow(ply, wep) then return end

    lastShowUntil = CurTime() + SHOW_TIME
end)

-- Also show when the local player fires any weapon
hook.Add("EntityFireBullets", "HG_ShowAmmoBarOnShoot", function(ent, data)
    if ent ~= LocalPlayer() then return end
    local wep = ent:GetActiveWeapon()
    if not canShow(ent, wep) then return end
    lastShowUntil = CurTime() + SHOW_TIME
end)

local function drawAmmoBar()
    local ply = LocalPlayer()
    local timeLeft = lastShowUntil - CurTime()
    local targetAlpha = timeLeft > 0 and 1 or 0

    -- Smooth alpha
    local speed = (targetAlpha > barAlpha) and FADE_IN_SPEED or FADE_OUT_SPEED
    barAlpha = Lerp(FrameTime() * speed, barAlpha, targetAlpha)
    if barAlpha <= 0.01 then return end

    local wep = IsValid(ply) and ply:GetActiveWeapon() or nil
    if not canShow(ply, wep) then return end

    local clip = math.max(wep:Clip1() or 0, 0)
    local max = math.max(wep:GetMaxClip1() or 0, 0)
    if max <= 0 then return end

    local frac = math.Clamp(clip / max, 0, 1)

    local scrW, scrH = ScrW(), ScrH()
    local width = math.max(math.floor(scrW * 0.12), 50)
    local height = math.max(math.floor(scrH * 0.03), 300)
    local x = math.floor((scrW - width) / 2 + 500)
    local y = math.floor(scrH * 0.85 - 200)

    -- Background
    surface.SetDrawColor(0, 0, 0, math.floor(160 * barAlpha))
    surface.DrawRect(x - 2, y - 2, width + 4, height + 4)

    surface.SetDrawColor(30, 30, 35, math.floor(220 * barAlpha))
    surface.DrawRect(x, y, width, height)

    -- Fill (vertical): decreases from top to bottom
    local fillH = math.floor(height * frac)
    local r, g, b = 60, 180, 255
    -- Low ammo tint to orange/red
    if frac < 0.25 then r, g, b = 255, 90, 60 elseif frac < 0.5 then r, g, b = 255, 170, 60 end

    surface.SetDrawColor(r, g, b, math.floor(240 * barAlpha))
    local fy = y + (height - fillH)
    surface.DrawRect(x, fy, width, fillH)

    -- Outline
    surface.SetDrawColor(0, 0, 0, math.floor(220 * barAlpha))
    surface.DrawOutlinedRect(x, y, width, height, 1)

    -- Extra magazines count
    local reserve = ply:GetAmmoCount(wep:GetPrimaryAmmoType()) or 0
    if reserve > 0 and max > 0 then
        local mags = math.floor(reserve / max)
        if mags > 0 then
            local tx = x + width + 10
            local ty = y + math.floor(height * 0.5)
            local col = Color(255, 255, 255, math.floor(240 * barAlpha))
            draw.SimpleText("+" .. mags, "DermaLarge", tx, ty, col, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        end
    end
end

hook.Add("HUDPaint", "HG_AmmoReloadBar", drawAmmoBar)
