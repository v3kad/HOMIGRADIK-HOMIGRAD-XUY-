-- Ensure HG Armor entities appear in the Spawnmenu (Entities tab)
if not CLIENT then return end

local CATEGORY = "HG Armor"

local ENTS = {
    { class = "ent_hg_helmet_fast_ops",  print = "Fast Ops Helmet",  icon = "entities/ent_jack_gmod_ezarmor_tackekfastmt.png" },
    { class = "ent_hg_helmet_6b47",      print = "6B47 Helmet",      icon = "entities/ent_jack_gmod_ezarmor_6b47.png" },
    { class = "ent_hg_helmet_6b47_cover",print = "6B47 Cover Helmet",icon = "entities/ent_jack_gmod_ezarmor_6b47chehol.png" },
    { class = "ent_hg_helmet_ssh_68",    print = "SSH-68 Helmet",    icon = "entities/ent_jack_gmod_ezarmor_ssh68.png" },
    { class = "ent_hg_vest_untar",       print = "Untar Vest",       icon = "entities/ent_jack_gmod_ezarmor_untar.png" },
    { class = "ent_hg_vest_thor",        print = "Thor Vest",        icon = "entities/ent_jack_gmod_ezarmor_thorcrv.png" },
    { class = "ent_hg_vest_bagariy",     print = "Bagariy Vest",     icon = "entities/ent_jack_gmod_ezarmor_bagariy.png" },
}

hook.Add("PopulateEntities", "HG_Armor_PopulateEntities", function(pnlContent, tree, node)
    local nodeHG = tree:AddNode(CATEGORY, "icon16/shield.png")
    nodeHG.DoPopulate = function(self)
        if self.PropPanel then return end
        self.PropPanel = vgui.Create("ContentContainer", pnlContent)
        self.PropPanel:SetVisible(false)
        self.PropPanel:SetTriggerSpawnlistChange(false)
        for _, info in ipairs(ENTS) do
            spawnmenu.CreateContentIcon("entity", self.PropPanel, {
                nicename = info.print,
                spawnname = info.class,
                icon = info.icon,
                material = info.icon,
                admin = 0
            })
        end
    end
    nodeHG.DoClick = function(self)
        self:DoPopulate()
        pnlContent:SwitchPanel(self.PropPanel)
    end
end)
