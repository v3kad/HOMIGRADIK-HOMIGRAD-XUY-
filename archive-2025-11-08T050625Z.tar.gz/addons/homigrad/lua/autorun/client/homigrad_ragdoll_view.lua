if CLIENT then
	include("homigrad/cl_ragdoll_view.lua")
end


