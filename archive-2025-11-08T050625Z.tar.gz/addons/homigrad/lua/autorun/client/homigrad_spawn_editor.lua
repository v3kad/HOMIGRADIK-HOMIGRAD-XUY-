if not CLIENT then return end

local enabled = false
local types = { "rebels", "police", "homicide", "dm", "jb_guards", "jb_prisoners" }
local currentTypeIndex = 1

local function currentType()
	return types[currentTypeIndex]
end

concommand.Add("hg_spawns_edit", function()
	enabled = not enabled
	chat.AddText(Color(200,200,50), "[HG] Map Pointer: ", Color(255,255,255), enabled and "ON" or "OFF")
	net.Start("HG_SpawnEditor_Toggle")
		net.WriteBool(enabled)
	net.SendToServer()
end)

-- switch type with 1..6
hook.Add("PlayerButtonDown", "HG_SpawnEditor_Shortcuts", function(ply, button)
	if ply ~= LocalPlayer() then return end
	if not enabled then return end
	if button == KEY_1 then currentTypeIndex = 1 end
	if button == KEY_2 then currentTypeIndex = 2 end
	if button == KEY_3 then currentTypeIndex = 3 end
	if button == KEY_4 then currentTypeIndex = 4 end
	if button == KEY_5 then currentTypeIndex = 5 end
	if button == KEY_6 then currentTypeIndex = 6 end
end)

-- place/remove by mouse
hook.Add("PlayerButtonDown", "HG_SpawnEditor_Clicks", function(ply, button)
	if ply ~= LocalPlayer() then return end
	if not enabled then return end
	local tr = ply:GetEyeTrace()
	if not tr or not tr.Hit then return end
	local hit = tr.HitPos
	if button == MOUSE_LEFT then
		net.Start("HG_SpawnEditor_Add")
			net.WriteVector(hit)
			net.WriteString(currentType())
		net.SendToServer()
	elseif button == MOUSE_RIGHT then
		net.Start("HG_SpawnEditor_Remove")
			net.WriteVector(hit)
			net.WriteFloat(32)
		net.SendToServer()
	end
end)

-- hud help and preview
hook.Add("HUDPaint", "HG_SpawnEditor_Help", function()
	if not enabled then return end
	local w, h = ScrW(), ScrH()
	draw.RoundedBox(6, 20, h - 150, 380, 130, Color(0,0,0,160))
	draw.SimpleText("HG Map Pointer (admin)", "DermaLarge", 40, h - 140, Color(255,215,0), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	draw.SimpleText("Тип: " .. currentType(), "Trebuchet24", 40, h - 105, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	draw.SimpleText("ЛКМ - добавить, ПКМ - удалить", "Trebuchet24", 40, h - 80, Color(200,200,200), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	draw.SimpleText("1..6 - смена типа, hg_spawns_edit - вкл/выкл", "Trebuchet24", 40, h - 55, Color(200,200,200), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
end)

hook.Add("PostDrawTranslucentRenderables", "HG_SpawnEditor_Preview", function()
	if not enabled then return end
	local ply = LocalPlayer()
	if not IsValid(ply) then return end
	local tr = ply:GetEyeTrace()
	if not tr or not tr.Hit then return end
	local pos = tr.HitPos
	render.SetColorMaterial()
	render.DrawSphere(pos, 8, 16, 16, Color(0,255,0,80))
end)



