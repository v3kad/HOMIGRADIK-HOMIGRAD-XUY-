-- Клиентский инвентарь Homigrad
if not CLIENT then return end

local iconCache = {}

-- Armor model->icon mapping (Material expects path without "materials/")
local ArmorIconByModel = {
    ["models/eft_props/gear/armor/ar_untar.mdl"] = "entities/ent_jack_gmod_ezarmor_untar.png",
    ["models/eft_props/gear/armor/ar_thor_crv.mdl"] = "entities/ent_jack_gmod_ezarmor_thorcrv.png",
    ["models/eft_props/gear/armor/cr/cr_bagarii.mdl"] = "entities/ent_jack_gmod_ezarmor_bagariy.png",

    ["models/eft_props/gear/helmets/helmet_ops_core_fast_tan.mdl"] = "entities/ent_jack_gmod_ezarmor_tackekfastmt.png",
    ["models/eft_props/gear/helmets/helmet_6b47.mdl"] = "entities/ent_jack_gmod_ezarmor_6b47.png",
    ["models/eft_props/gear/helmets/helmet_6b47_cover.mdl"] = "entities/ent_jack_gmod_ezarmor_6b47chehol.png",
    ["models/eft_props/gear/helmets/helmet_s_sh_68.mdl"] = "entities/ent_jack_gmod_ezarmor_ssh68.png",
}

local function GetArmorIconForModel(modelPath)
    local iconPath = ArmorIconByModel[modelPath or ""]
    if not iconPath then return nil end
    iconCache[iconPath] = iconCache[iconPath] or Material(iconPath, "smooth")
    return iconCache[iconPath]
end

local InventoryPanel = nil
local KEY_CODE = KEY_I -- I
local wasKeyDown_I = false
local isChatOpen = false
local wasKeyDown_E = false

surface.CreateFont("HG_InventoryTitle", {font = "Trebuchet24", size = 28, weight = 1000})
surface.CreateFont("HG_InventoryItem", {font = "Trebuchet24", size = 18, weight = 600})
surface.CreateFont("HG_InventoryArmor", {font = "Trebuchet24", size = 15, weight = 500})
local function GetWepIconForClass(class)
    if not class then return nil end
    local wepT = weapons and weapons.Get and weapons.Get(class)
    if not wepT then return nil end
    local icon = wepT.WepSelectIcon or wepT.Icon or wepT.SelectIcon or wepT.IconMaterial
    if isstring(icon) then
        iconCache[icon] = iconCache[icon] or Material(icon, "smooth")
        return {kind = "material", mat = iconCache[icon]}
    elseif type(icon) == "IMaterial" then
        return {kind = "material", mat = icon}
    elseif isnumber(icon) then
        return {kind = "texture", tex = icon}
    end
    return nil
end

local GRID_ROWS = 5
local GRID_COLS = 6
local SLOT_SIZE = 80    -- px
local SLOT_PADDING = 0 -- слоты без зазоров
local MODEL_W, MODEL_H = 180, 400  -- Модель крупнее и во весь рост
local ARMOR_SLOT_W, ARMOR_SLOT_H = 72, 72
local ARMOR_SLOTS = {
    { name = "Шлем", key = "helmet" },
    { name = "Броня", key = "vest" },
}
-- Общая ширина: модель + полоска брони + сетка предметов
local PANEL_W = MODEL_W + math.max(ARMOR_SLOT_W, SLOT_SIZE) + GRID_COLS * SLOT_SIZE + (GRID_COLS+1) * SLOT_PADDING + 64
local PANEL_H = math.max(MODEL_H + 50, GRID_ROWS * SLOT_SIZE + (GRID_ROWS+1)*SLOT_PADDING + 54)

-- Инвентарь игрока (синхронизируется с сервером)
local inventoryItems = {}
local armorState = {
    helmet = { name = "Шлем", equipped = true },
    vest = { name = "Бронежилет", equipped = false },
}

local HG_LOOT_MAX_DIST = 80
local lootView = {active = false, target = nil, ownerName = "", inventory = {}}

local armorEntities = {}
local function RemoveArmorEntities()
    for _, ent in ipairs(armorEntities) do if IsValid(ent) then ent:Remove() end end
    armorEntities = {}
end

local function AttachArmorToEntity(parentEnt, key, modelPath, offsetPos, offsetAng)
    if not IsValid(parentEnt) then return end
    if not modelPath or modelPath == "" then return end

    local mdl = ClientsideModel(modelPath, RENDERGROUP_OPAQUE)
    if not IsValid(mdl) then return end
    mdl:SetNoDraw(true)
    mdl:DrawShadow(false)
    -- Рендерим вручную по матрице кости как на живом игроке
    mdl:SetParent(nil)
    mdl:SetMoveType(MOVETYPE_NONE)
    mdl:SetSolid(SOLID_NONE)
    mdl.HG_TargetBoneName = (key == "helmet") and "ValveBiped.Bip01_Head1" or "ValveBiped.Bip01_Spine2"
    mdl.HG_TargetBoneId = parentEnt:LookupBone(mdl.HG_TargetBoneName) or 0
    mdl.HG_OffPos = offsetPos or Vector(0,0,0)
    mdl.HG_OffAng = offsetAng or Angle(0,0,0)
    mdl.HG_Owner = parentEnt
    table.insert(armorEntities, mdl)
end

-- Закрытие инвентаря
local function CloseInventory()
    if IsValid(InventoryPanel) then
        InventoryPanel:Remove()
        InventoryPanel = nil
    end
    RemoveArmorEntities()
    -- Выключаем курсор только если нет других открытых меню
    -- Проверяем, есть ли функция для проверки состояния курсора (из gamemode)
    if Homigrad_ShouldEnableCursor then
        if not Homigrad_ShouldEnableCursor() then
            gui.EnableScreenClicker(false)
        end
    else
        gui.EnableScreenClicker(false)
    end
    -- notify server if we were looting
    if lootView.active then
        net.Start("HG_Loot_Close")
        net.SendToServer()
    end
    lootView.active = false
    lootView.target = nil
    lootView.inventory = {}
    hook.Run("HG_LootViewClosed")
end

local activeDropButton = nil
local function RemoveDropButton()
    if IsValid(activeDropButton) then activeDropButton:Remove() end
    activeDropButton = nil
end

local function DropInventoryItem(slotIdx)
    -- Отправляем запрос на сервер о выбросе предмета
    net.Start("HG_Inventory_DropItem")
        net.WriteInt(slotIdx, 8)
    net.SendToServer()
    RemoveDropButton()
end

local isCreatingInventory = false

-- Определение функции CreateInventoryPanel (должна быть объявлена до net.Receive)
local function CreateInventoryPanel()
    local panel = vgui.Create("DFrame")
    panel:SetSize(ScrW(), ScrH())
    panel:SetPos(0, 0)
    panel:SetTitle("")
    panel:ShowCloseButton(false)
    panel:SetDraggable(true)
    panel.Paint = function(self, pw, ph)
        draw.RoundedBox(0, 0, 0, pw, ph, Color(0, 0, 0, 200))
        draw.SimpleText("Инвентарь", "HG_InventoryTitle", pw/2, 18, Color(220,220,240), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
    end
    panel.OnRemove = RemoveArmorEntities
    panel.OnMousePressed = function() RemoveDropButton() end -- клик вне предмета = убрать кнопку

    -- Панель модели игрока (слева, по центру экрана)
    local modelPanel = vgui.Create("DModelPanel", panel)
    local modelW = math.min(math.floor(ScrW() * 0.22), 380)
    local modelH = math.floor(ScrH() * 0.8)
    modelPanel:SetSize(modelW, modelH)
    modelPanel:SetPos( math.floor(ScrW() * 0.08), math.floor((ScrH() - modelH) * 0.5) )
    local ply = LocalPlayer()
    modelPanel:SetModel(ply:GetModel())
    if ply.GetBodyGroups then
        for _, bg in pairs(ply:GetBodyGroups() or {}) do
            modelPanel.Entity:SetBodygroup(bg.id, ply:GetBodygroup(bg.id))
        end
    end
    -- Камера: вид сверху-сбоку, по центру туловища, захватывает ноги и голову
    modelPanel:SetCamPos(Vector(55, 0, 70))
    modelPanel:SetLookAt(Vector(0, 0, 35))
    modelPanel.Entity:SetEyeTarget(Vector(0,0,35))
    modelPanel:SetMouseInputEnabled(true)
    modelPanel.Angles = Angle(0,0,0)
    modelPanel.OnMousePressed = function(self, mc)
        if mc == MOUSE_LEFT then
            self.Dragging = true
            self.LastX, self.LastY = gui.MousePos()
            self:MouseCapture(true)
        end
    end
    modelPanel.OnMouseReleased = function(self, mc)
        if mc == MOUSE_LEFT then
            self.Dragging = false
            self:MouseCapture(false)
        end
    end
    modelPanel.OnCursorMoved = function(self, x, y)
        if not self.Dragging then return end
        local mx, my = gui.MousePos()
        local dx = mx - (self.LastX or mx)
        local dy = my - (self.LastY or my)
        self.LastX, self.LastY = mx, my
        self.Angles.p = math.Clamp((self.Angles.p or 0) + dy * 0.25, -20, 20)
        self.Angles.y = (self.Angles.y or 0) - dx * 0.5
    end
    modelPanel.LayoutEntity = function(self, ent) -- Disable spinning
        ent:SetAngles(self.Angles or Angle(0,0,0))
    end
    modelPanel:SetFOV(36) -- чуть шире
    -- Отрисовываем прикреплённые модели брони внутри панели (как на игроке)
    modelPanel.PostDrawModel = function(self, ent)
        ent:SetupBones()
        for _, aEnt in ipairs(armorEntities) do
            if IsValid(aEnt) then
                local boneId = aEnt.HG_TargetBoneId or 0
                if boneId <= 0 then
                    local name = aEnt.HG_TargetBoneName or ""
                    if name ~= "" then boneId = ent:LookupBone(name) or 0 aEnt.HG_TargetBoneId = boneId end
                end
                local m = (boneId > 0) and ent:GetBoneMatrix(boneId) or nil
                local basePos, baseAng
                if m then
                    basePos = m:GetTranslation()
                    baseAng = m:GetAngles()
                else
                    basePos = ent:GetPos()
                    baseAng = ent:GetAngles()
                end
                local offPos = aEnt.HG_OffPos or vector_origin
                local offAng = aEnt.HG_OffAng or angle_zero
                local pos = basePos
                    + baseAng:Forward() * offPos.x
                    + baseAng:Right()   * offPos.y
                    + baseAng:Up()      * offPos.z
                local ang = Angle(baseAng.p, baseAng.y, baseAng.r)
                ang:RotateAroundAxis(ang:Right(),   offAng.p)
                ang:RotateAroundAxis(ang:Up(),      offAng.y)
                ang:RotateAroundAxis(ang:Forward(), offAng.r)
                aEnt:SetPos(pos)
                aEnt:SetAngles(ang)
                aEnt:SetupBones()
                aEnt:DrawModel()
            end
        end
    end
    -- Присоединяем броню/шлем к модели и обновляем при изменениях
    local function ApplyArmorToModel()
        RemoveArmorEntities()
        if ply:GetNWBool("HG_Helmet", false) then
            local mpath = ply:GetNWString("HG_HelmetModel", "")
            local opos = ply:GetNWVector("HG_HelmetOffsetPos", Vector(0,0,0))
            local oang = ply:GetNWAngle("HG_HelmetOffsetAng", Angle(0,0,0))
            AttachArmorToEntity(modelPanel.Entity, "helmet", mpath, opos, oang)
        end
        if ply:GetNWBool("HG_Vest", false) then
            local mpath = ply:GetNWString("HG_VestModel", "")
            local opos = ply:GetNWVector("HG_VestOffsetPos", Vector(0,0,0))
            local oang = ply:GetNWAngle("HG_VestOffsetAng", Angle(0,0,0))
            AttachArmorToEntity(modelPanel.Entity, "vest", mpath, opos, oang)
        end
    end
    -- первичное применение
    ApplyArmorToModel()
    -- отслеживание изменений сетевых переменных, чтобы обновлять броню в открытом инвентаре
    modelPanel._nextArmorCheck = 0
    modelPanel.Think = function(self)
        if CurTime() < (self._nextArmorCheck or 0) then return end
        self._nextArmorCheck = CurTime() + 0.3
        local hOn  = ply:GetNWBool("HG_Helmet", false)
        local vOn  = ply:GetNWBool("HG_Vest", false)
        local hMod = ply:GetNWString("HG_HelmetModel", "")
        local vMod = ply:GetNWString("HG_VestModel", "")
        if hOn ~= self._hOn or vOn ~= self._vOn or hMod ~= (self._hMod or "") or vMod ~= (self._vMod or "") then
            self._hOn, self._vOn = hOn, vOn
            self._hMod, self._vMod = hMod, vMod
            ApplyArmorToModel()
        end
    end
    -- Синхронизируем состояние слотов брони слева с NW-состоянием игрока
    armorState.helmet = armorState.helmet or {}
    armorState.vest = armorState.vest or {}
    armorState.helmet.equipped = ply:GetNWBool("HG_Helmet", false)
    armorState.vest.equipped = ply:GetNWBool("HG_Vest", false)
    armorState.helmet.name = ply:GetNWString("HG_HelmetName", armorState.helmet.equipped and "Шлем" or nil)
    armorState.vest.name = ply:GetNWString("HG_VestName", armorState.vest.equipped and "Бронежилет" or nil)

    -- Клетки брони: справа (шлем на уровне головы, бронежилет по центру). Слева — рюкзак на уровне бронежилета
    local rightSlots = {
        { name = "Шлем", key = "helmet" },
        { name = "Броня", key = "vest" },
    }
    local rightX = modelPanel.x + modelPanel:GetWide() + 20
    local vestSlotY = math.floor(modelPanel.y + modelPanel:GetTall() * 0.34 - ARMOR_SLOT_H * 0.5)
    local helmetSlotY = math.floor(modelPanel.y + modelPanel:GetTall() * 0.10 - ARMOR_SLOT_H * 0.5)
    for _, slotDef in ipairs(rightSlots) do
        local slotY = (slotDef.key == "helmet") and helmetSlotY or vestSlotY
        local bpanel = vgui.Create("DPanel", panel)
        bpanel:SetSize(ARMOR_SLOT_W, ARMOR_SLOT_H)
        bpanel:SetPos(rightX, slotY)
        bpanel.Paint = function(self,w,h)
            surface.SetDrawColor(0,0,0,220)
            surface.DrawRect(0,0,w,h)
            surface.SetDrawColor(140,140,150,200)
            surface.DrawOutlinedRect(0,0,w,h,1)
            -- armor icon (no text)
            local mdlPath = ""
            if slotDef.key == "helmet" then
                mdlPath = ply:GetNWString("HG_HelmetModel", "")
            else
                mdlPath = ply:GetNWString("HG_VestModel", "")
            end
            local mat = GetArmorIconForModel(mdlPath)
            if mat then
                local pad = 8
                surface.SetMaterial(mat)
                surface.SetDrawColor(255,255,255,255)
                surface.DrawTexturedRect(pad, pad, w - pad*2, h - pad*2)
            end
        end
        bpanel.OnMousePressed = function(self, mc)
            if mc == MOUSE_RIGHT then
                RemoveDropButton()
                if armorState[slotDef.key] and armorState[slotDef.key].equipped then
                    activeDropButton = vgui.Create("DButton", panel)
                    activeDropButton:SetSize(80, 28)
                    activeDropButton:SetPos(self.x + self:GetWide() + 6, self.y + self:GetTall()/2 - 14)
                    activeDropButton:SetText("")
                    activeDropButton:SetFont("HG_InventoryItem")
                    activeDropButton.Paint = function(btn, w, h)
                        if btn:IsHovered() then
                            surface.SetDrawColor(200,60,40,240)
                        else
                            surface.SetDrawColor(100, 30, 33, 230)
                        end
                        surface.DrawRect(0, 0, w, h)
                        draw.SimpleText("Выкинуть", "HG_InventoryItem", w/2, h/2, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                    end
                    activeDropButton.DoClick = function()
                        net.Start("HG_Inventory_Unequip")
                            net.WriteString(slotDef.key)
                        net.SendToServer()
                        RemoveDropButton()
                    end
                end
            end
        end
    end
    -- Слот рюкзака слева от модели, на уровне ячейки бронежилета
    local leftAux = vgui.Create("DPanel", panel)
    leftAux:SetSize(ARMOR_SLOT_W, ARMOR_SLOT_H)
    local leftAuxX = modelPanel.x - ARMOR_SLOT_W - 20
    leftAux:SetPos(leftAuxX, vestSlotY)
    leftAux.Paint = function(self,w,h)
        surface.SetDrawColor(0,0,0,220)
        surface.DrawRect(0,0,w,h)
        surface.SetDrawColor(140,140,150,200)
        surface.DrawOutlinedRect(0,0,w,h,1)
        draw.SimpleText("Рюкзак", "HG_InventoryArmor", w/2, h/2, Color(230,230,240), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    local function RefreshLootUI()
        if IsValid(panel.HG_LootContainer) then panel.HG_LootContainer:Remove() end
        panel.HG_LootContainer = nil
        if not lootView.active then return end
        local GRID_COLS, GRID_ROWS = 8, 5
        local SLOT_SIZE, SLOT_PADDING = 80, 4
        local OUTER_PAD = SLOT_PADDING
        local gridW = GRID_COLS * SLOT_SIZE + (GRID_COLS - 1) * SLOT_PADDING + OUTER_PAD * 2
        local gridH = GRID_ROWS * SLOT_SIZE + (GRID_ROWS - 1) * SLOT_PADDING + OUTER_PAD * 2
        local contW = math.max(gridW, 360)
        local contH = gridH + 70
        local cont = vgui.Create("DPanel", panel)
        cont:SetSize(contW, contH)
        cont:SetPos(
            math.floor(ScrW() * 0.5 - contW * 0.5) + 120, -- чуть правее центра
            math.floor(ScrH() * 0.5 - contH * 0.5) - 30 -- чуть выше центра
        )
        cont.Paint = function(self,w,h)
            surface.SetDrawColor(0,0,0,200)
            surface.DrawRect(0,0,w,h)
            surface.SetDrawColor(140,140,150,200)
            surface.DrawOutlinedRect(0,0,w,h,1)
            draw.SimpleText("Лут: " .. (lootView.ownerName or ""), "HG_InventoryTitle", w/2, 18, Color(220,220,240), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
        end
        panel.HG_LootContainer = cont
        local startX = math.floor((contW - gridW) * 0.5) + OUTER_PAD
        local startY = 50 + OUTER_PAD
        for idx = 1, GRID_COLS * GRID_ROWS do
            local item = lootView.inventory[idx]
            if item then
                local col = ((idx - 1) % GRID_COLS)
                local row = math.floor((idx - 1) / GRID_COLS)
                local x = startX + col * (SLOT_SIZE + SLOT_PADDING)
                local y = startY + row * (SLOT_SIZE + SLOT_PADDING)
                local btn = vgui.Create("DButton", cont)
                btn:SetSize(SLOT_SIZE, SLOT_SIZE)
                btn:SetPos(x, y)
                btn:SetText("")
                btn.Paint = function(self,w,h)
                    surface.SetDrawColor(0,0,0,220)
                    surface.DrawRect(0,0,w,h)
                    -- Icon rendering (similar to bottom inventory slots)
                    local iconData = nil
                    if item.kind == "weapon" and item.class then
                        iconData = GetWepIconForClass(item.class)
                    end
                    -- Armor icons by model
                    if not iconData and (item.kind == "helmet" or item.kind == "vest") then
                        local mdlPath = tostring(item.model or "")
                        if mdlPath ~= "" then
                            local mat = GetArmorIconForModel(mdlPath)
                            if mat then iconData = { kind = "material", mat = mat } end
                        end
                    end
                    if not iconData and isstring(item.icon) and item.icon ~= "" then
                        local path = item.icon
                        iconCache[path] = iconCache[path] or Material(path, "smooth")
                        iconData = { kind = "material", mat = iconCache[path] }
                    end
                    if iconData then
                        local pad = 6
                        local nameH = 16
                        local ih = h - nameH - pad*2
                        local iw = w - pad*2
                        local ix = pad
                        local iy = pad
                        if iconData.kind == "material" and iconData.mat then
                            surface.SetMaterial(iconData.mat)
                            surface.SetDrawColor(255,255,255,255)
                            surface.DrawTexturedRect(ix, iy, iw, ih)
                        elseif iconData.kind == "texture" and iconData.tex then
                            surface.SetTexture(iconData.tex)
                            surface.SetDrawColor(255,255,255,255)
                            surface.DrawTexturedRect(ix, iy, iw, ih)
                        end
                    end
                    -- Amount overlay for ammo
                    if item.kind == "ammo" and tonumber(item.amount or 0) and (item.amount or 0) > 0 then
                        local txt = "x" .. tostring(item.amount)
                        draw.SimpleText(txt, "HG_InventoryItem", w - 6, h - 18, Color(240,240,240), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
                    end
                    -- Name (small) at bottom (hidden for ammo)
                    if item.kind ~= "ammo" then
                        local itemName = item.name or "Предмет"
                        if string.len(itemName) > 18 then
                            itemName = string.sub(itemName, 1, 18) .. "..."
                        end
                        draw.SimpleText(itemName, "HG_InventoryArmor", w/2, h - 2, Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
                    end
                    surface.SetDrawColor(140,140,150,200)
                    surface.DrawOutlinedRect(0,0,w,h,1)
                end
                btn.DoClick = function()
                    if not IsValid(lootView.target) then return end
                    net.Start("HG_Loot_TakeItem")
                        net.WriteEntity(lootView.target)
                        net.WriteInt(idx, 8)
                    net.SendToServer()
                end
            end
        end
    end
    panel.RefreshLootUI = RefreshLootUI

    -- Сетка снизу: 7 слотов по центру
    local bottomSlots = 7
    local totalW = bottomSlots * SLOT_SIZE + (bottomSlots - 1) * SLOT_PADDING
    local startX = math.floor(ScrW() * 0.5 - totalW * 0.5)
    local startY = ScrH() - SLOT_SIZE
    for i = 1, bottomSlots do
        local slotIdx = i
        local slotX = startX + (i-1) * (SLOT_SIZE + SLOT_PADDING)
        local slotY = startY
        local slot = vgui.Create("DButton", panel)
        slot:SetSize(SLOT_SIZE, SLOT_SIZE)
        slot:SetPos(slotX, slotY)
        slot:SetText("")
        slot.Paint = function(self, w, h)
            local item = inventoryItems[slotIdx]
            surface.SetDrawColor(0, 0, 0, 220)
            surface.DrawRect(0, 0, w, h)
            -- icon
            if item then
                local iconData = nil
                -- weapon icon via SWEP
                if item.kind == "weapon" and item.class then
                    iconData = GetWepIconForClass(item.class)
                end
                -- generic item icon material path
                if not iconData and isstring(item.icon) and item.icon ~= "" then
                    local path = item.icon
                    iconCache[path] = iconCache[path] or Material(path, "smooth")
                    iconData = { kind = "material", mat = iconCache[path] }
                end
                -- ammo icon mapping (caliber or HL2 ammo type)
                if not iconData and item.kind == "ammo" then
                    local path
                    if isstring(item.caliber) then
                        if item.caliber == "7x62" then path = "homigrad/ui/7x62.png" end
                        if item.caliber == "9x19" then path = "homigrad/ui/9x19.png" end
                    end
                    if not path then
                        local at = tonumber(item.ammoType or -1)
                        if at and at > -1 then
                            local aname = string.lower(game.GetAmmoName(at) or "")
                            if aname == "ar2" then path = "homigrad/ui/7x62.png" end
                            if aname == "pistol" then path = "homigrad/ui/9x19.png" end
                        end
                    end
                    if path then
                        iconCache[path] = iconCache[path] or Material(path, "smooth")
                        iconData = { kind = "material", mat = iconCache[path] }
                    end
                end
                if iconData then
                    local pad = 6
                    local nameH = 16
                    local ih = h - nameH - pad*2
                    local iw = w - pad*2
                    local ix = pad
                    local iy = pad
                    if iconData.kind == "material" and iconData.mat then
                        surface.SetMaterial(iconData.mat)
                        surface.SetDrawColor(255,255,255,255)
                        surface.DrawTexturedRect(ix, iy, iw, ih)
                    elseif iconData.kind == "texture" and iconData.tex then
                        surface.SetTexture(iconData.tex)
                        surface.SetDrawColor(255,255,255,255)
                        surface.DrawTexturedRect(ix, iy, iw, ih)
                    end
                end
                -- amount overlay for ammo
                if item.kind == "ammo" and tonumber(item.amount or 0) and (item.amount or 0) > 0 then
                    local txt = "x" .. tostring(item.amount)
                    draw.SimpleText(txt, "HG_InventoryItem", w - 6, h - 18, Color(240,240,240), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
                end
                -- name (small) at bottom (hidden for ammo)
                if item.kind ~= "ammo" then
                    local itemName = item.name or "Предмет"
                    if string.len(itemName) > 18 then
                        itemName = string.sub(itemName, 1, 18) .. "..."
                    end
                    draw.SimpleText(itemName, "HG_InventoryArmor", w/2, h - 2, Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
                end
            end
            surface.SetDrawColor(140,140,150,200)
            surface.DrawOutlinedRect(0,0,w,h,1)
        end
        slot.DoRightClick = function(self)
            RemoveDropButton()
            local item = inventoryItems[slotIdx]
            if not item or not item.name then return end

            -- Create a small container to hold context buttons (drop + optional unload)
            local containerW = 90
            local containerH = 28 -- will extend if we add unload button
            local containerX = slotX + SLOT_SIZE + 4
            local containerY = slotY + math.floor(SLOT_SIZE/2 - 14)

            local container = vgui.Create("DPanel", panel)
            container:SetSize(containerW, containerH)
            container:SetPos(containerX, containerY)
            container:SetMouseInputEnabled(true)
            container:SetKeyboardInputEnabled(false)
            container.Paint = function() end -- container is invisible; buttons handle their own paint

            -- No auto-close on hover out; closing handled by outside click via panel.OnMousePressed

            -- Drop button (top)
            local dropBtn = vgui.Create("DButton", container)
            dropBtn:SetSize(containerW, 28)
            dropBtn:SetPos(0, 0)
            dropBtn:SetText("")
            dropBtn:SetFont("HG_InventoryItem")
            dropBtn.Paint = function(btn, w, h)
                if btn:IsHovered() then
                    surface.SetDrawColor(200,60,40,240)
                else
                    surface.SetDrawColor(100, 30, 33, 230)
                end
                surface.DrawRect(0, 0, w, h)
                draw.SimpleText("Выбросить", "HG_InventoryItem", w/2, h/2, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end
            dropBtn.DoClick = function()
                DropInventoryItem(slotIdx)
            end

            -- If this is a firearm (has a clip), add an Unload button under the drop button
            local isFirearm = false
            if item.kind == "weapon" and item.class then
                local sw = weapons and weapons.GetStored and weapons.GetStored(item.class)
                if sw then
                    local p = sw.Primary
                    local s = sw.Secondary
                    local pclip = p and tonumber(p.ClipSize) or -1
                    local sclip = s and tonumber(s.ClipSize) or -1
                    if (pclip and pclip > 0) or (sclip and sclip > 0) then
                        isFirearm = true
                    end
                end
            end
            if isFirearm then
                local unloadBtn = vgui.Create("DButton", container)
                unloadBtn:SetSize(containerW, 26)
                unloadBtn:SetPos(0, 28)
                unloadBtn:SetText("")
                unloadBtn:SetFont("HG_InventoryItem")
                unloadBtn.Paint = function(btn, w, h)
                    -- black transparent background
                    local a = btn:IsHovered() and 180 or 140
                    surface.SetDrawColor(0, 0, 0, a)
                    surface.DrawRect(0, 0, w, h)
                    draw.SimpleText("Разрядить", "HG_InventoryItem", w/2, h/2, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                end
                unloadBtn.DoClick = function()
                    net.Start("HG_Inventory_UnloadWeapon")
                        net.WriteInt(slotIdx, 8)
                    net.SendToServer()
                    RemoveDropButton()
                end

                -- Resize container to fit both buttons
                container:SetTall(28 + 26)
            end

            activeDropButton = container
        end
    end
    InventoryPanel = panel
    -- Включаем курсор для инвентаря (всегда, если инвентарь открыт)
    gui.EnableScreenClicker(true)
    if lootView.active and InventoryPanel.RefreshLootUI then InventoryPanel:RefreshLootUI() end
end

-- Получение инвентаря с сервера
net.Receive("HG_Inventory_Send", function()
    local newInventory = net.ReadTable()
    
    -- Обновляем инвентарь
    inventoryItems = newInventory or {}
    
    -- Обновляем панель если она открыта или если мы ожидаем создания
    if isCreatingInventory then
        isCreatingInventory = false
        if IsValid(InventoryPanel) then
            CloseInventory()
        end
        CreateInventoryPanel()
    elseif IsValid(InventoryPanel) then
        -- Не пересоздаем панель - просто обновляем данные
        -- Панель перерисуется автоматически с новыми данными из inventoryItems
        -- Это предотвращает мигание курсора
    end
end)

-- Открыть окно лута по сообщению с сервера
net.Receive("HG_Loot_Open", function()
    local ent = net.ReadEntity()
    local ownerName = net.ReadString() or ""
    local lootInv = net.ReadTable() or {}
    hook.Run("HG_OpenLootView", ent, ownerName, lootInv)
end)

hook.Add("HG_OpenLootView", "HG_Inventory_ShowLoot", function(target, ownerName, inventory)
    lootView.active = true
    lootView.target = target
    lootView.ownerName = ownerName or ""
    lootView.inventory = inventory or {}
    if IsValid(InventoryPanel) then
        if InventoryPanel.RefreshLootUI then InventoryPanel:RefreshLootUI() end
        gui.EnableScreenClicker(true)
    else
        CreateInventoryPanel()
    end
end)

hook.Add("Think", "HG_Inventory_LootDistance", function()
    if not lootView.active then return end
    local lp = LocalPlayer()
    if not IsValid(lp) or not lp:Alive() then
        net.Start("HG_Loot_Close") net.SendToServer()
        lootView.active = false
        if IsValid(InventoryPanel) and InventoryPanel.RefreshLootUI then InventoryPanel:RefreshLootUI() end
        hook.Run("HG_LootViewClosed")
        return
    end
    if not IsValid(lootView.target) then
        net.Start("HG_Loot_Close") net.SendToServer()
        lootView.active = false
        if IsValid(InventoryPanel) and InventoryPanel.RefreshLootUI then InventoryPanel:RefreshLootUI() end
        hook.Run("HG_LootViewClosed")
        return
    end
    local dist = lp:GetPos():Distance(lootView.target:GetPos())
    if dist > HG_LOOT_MAX_DIST then
        net.Start("HG_Loot_Close") net.SendToServer()
        lootView.active = false
        if IsValid(InventoryPanel) and InventoryPanel.RefreshLootUI then InventoryPanel:RefreshLootUI() end
        hook.Run("HG_LootViewClosed")
    end
end)

local function CreateInventory()
    CloseInventory() -- на всякий случай
    
    -- Запрашиваем актуальный инвентарь с сервера
    isCreatingInventory = true
    net.Start("HG_Inventory_Request")
    net.SendToServer()
    
    -- Панель будет создана после получения данных в net.Receive
end

-- Открытие/закрытие панели по кнопке I через Think (debounce)
hook.Add("Think", "HG_Inventory_KeyOpenClose", function()
    local isKey = input.IsKeyDown(KEY_CODE)
    if isKey and not wasKeyDown_I then
        if isChatOpen then
            wasKeyDown_I = isKey
            return
        end
        local lp = LocalPlayer()
        if not lp:Alive() or lp:GetNWBool("HG_Blackout", false) then
            if IsValid(InventoryPanel) then CloseInventory() end
            wasKeyDown_I = isKey
            return
        end
        if IsValid(InventoryPanel) then
            CloseInventory()
        else
            CreateInventory()
        end
    end
    wasKeyDown_I = isKey
end)

hook.Add("StartChat", "HG_Inventory_BlockWhileChat", function()
    isChatOpen = true
end)

hook.Add("FinishChat", "HG_Inventory_BlockWhileChat", function()
    isChatOpen = false
end)

-- Автоматически закрывать если игрок умер
hook.Add("Think", "HG_Inventory_AutoCloseOnDeath", function()
    local lp = LocalPlayer()
    if IsValid(InventoryPanel) and (not lp:Alive() or lp:GetNWBool("HG_Blackout", false)) then
        CloseInventory()
    end
end)

-- Закрыть инвентарь по ESC
hook.Add("Think", "HG_Inventory_AutoCloseESC", function()
    if IsValid(InventoryPanel) and input.IsKeyDown(KEY_ESCAPE) then
        CloseInventory()
    end
end)

-- Close inventory on E
hook.Add("Think", "HG_Inventory_CloseOnE", function()
    if not IsValid(InventoryPanel) then
        wasKeyDown_E = input.IsKeyDown(KEY_E)
        return
    end
    if isChatOpen then
        wasKeyDown_E = input.IsKeyDown(KEY_E)
        return
    end
    local isE = input.IsKeyDown(KEY_E)
    if isE and not wasKeyDown_E then
        CloseInventory()
    end
    wasKeyDown_E = isE
end)

-- Автоматически обновлять инвентарь после получения предметов из лута
hook.Add("HG_Inventory_Update", "HG_Inventory_Sync", function()
    -- Всегда обновляем инвентарь с сервера
    net.Start("HG_Inventory_Request")
    net.SendToServer()
end)

-- Автоматическое обновление инвентаря при открытии (если уже открыт, обновляем)
hook.Add("Think", "HG_Inventory_AutoRefresh", function()
    if IsValid(InventoryPanel) then
        -- Раз в секунду проверяем, не нужно ли обновить инвентарь
        if not InventoryPanel.lastRefresh or CurTime() - InventoryPanel.lastRefresh > 1 then
            InventoryPanel.lastRefresh = CurTime()
            -- Запрашиваем актуальный инвентарь с сервера
            net.Start("HG_Inventory_Request")
            net.SendToServer()
        end
    end
end)

-- Обновляем инвентарь сразу после спавна
hook.Add("PlayerSpawn", "HG_Inventory_SpawnRefresh", function(ply)
    if ply == LocalPlayer() and ply:Alive() then
        timer.Simple(0.5, function()
            if IsValid(ply) and ply:Alive() then
                net.Start("HG_Inventory_Request")
                net.SendToServer()
            end
        end)
    end
end)
