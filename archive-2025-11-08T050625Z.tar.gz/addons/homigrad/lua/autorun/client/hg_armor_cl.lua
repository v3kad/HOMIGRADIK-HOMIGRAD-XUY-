if not CLIENT then return end

local PL_ARM = {}
local RAG_ARM = {}

local function removeAll(tbl)
    for k, ent in pairs(tbl) do
        if istable(ent) then
            for _, e in pairs(ent) do if IsValid(e) then e:Remove() end end
        elseif IsValid(ent) then
            ent:Remove()
        end
        tbl[k] = nil
    end
end

local function removeArmorOn(ent)
    local t = ent:IsPlayer() and PL_ARM or RAG_ARM
    local key = ent
    local pack = t[key]
    if pack then
        if IsValid(pack.helmet) then pack.helmet:Remove() end
        if IsValid(pack.vest) then pack.vest:Remove() end
        t[key] = nil
    end
end

local function attach(ent, which, modelPath, offsetPos, offsetAng)
    if not IsValid(ent) then return nil end
    if not modelPath or modelPath == "" then return nil end
    local mdl = ClientsideModel(modelPath, RENDERGROUP_OPAQUE)
    if not IsValid(mdl) then return nil end
    mdl:SetNoDraw(false)
    mdl:DrawShadow(false)
    -- Do not parent; we will fully control world transform to avoid interpolation glitches
    mdl:SetParent(nil)
    mdl:SetMoveType(MOVETYPE_NONE)
    mdl:SetSolid(SOLID_NONE)
    mdl.HG_TargetBoneName = (which == "helmet") and "ValveBiped.Bip01_Head1" or "ValveBiped.Bip01_Spine2"
    mdl.HG_TargetBoneId = ent:LookupBone(mdl.HG_TargetBoneName) or 0
    mdl.HG_OffPos = offsetPos or Vector(0,0,0)
    mdl.HG_OffAng = offsetAng or Angle(0,0,0)
    mdl.HG_Owner = ent
    return mdl
end

local function updateAttachedEntity(ent, mdl)
    if not (IsValid(ent) and IsValid(mdl)) then return end
    ent:SetupBones()
    local boneId = mdl.HG_TargetBoneId or 0
    if boneId <= 0 then
        local name = mdl.HG_TargetBoneName or ""
        if name ~= "" then boneId = ent:LookupBone(name) or 0 mdl.HG_TargetBoneId = boneId end
    end
    local m = (boneId > 0) and ent:GetBoneMatrix(boneId) or nil
    local basePos, baseAng
    if m then
        basePos = m:GetTranslation()
        baseAng = m:GetAngles()
    else
        basePos = ent:GetPos()
        baseAng = ent:GetAngles()
    end
    local offPos = mdl.HG_OffPos or vector_origin
    local offAng = mdl.HG_OffAng or angle_zero
    local pos = basePos
        + baseAng:Forward() * offPos.x
        + baseAng:Right()   * offPos.y
        + baseAng:Up()      * offPos.z
    local ang = Angle(baseAng.p, baseAng.y, baseAng.r)
    ang:RotateAroundAxis(ang:Right(),   offAng.p)
    ang:RotateAroundAxis(ang:Up(),      offAng.y)
    ang:RotateAroundAxis(ang:Forward(), offAng.r)
    mdl:SetPos(pos)
    mdl:SetAngles(ang)
end

local function updateArmor(ent)
    local store = ent:IsPlayer() and PL_ARM or RAG_ARM
    local pack = store[ent]
    if not pack then return end
    if IsValid(pack.helmet) then
        local isLocalPlayer = ent:IsPlayer() and ent == LocalPlayer()
        local isLocalRagdoll = (not ent:IsPlayer()) and ent:GetClass() == "prop_ragdoll" and ent == (IsValid(LocalPlayer()) and LocalPlayer():GetNWEntity("hg_ragdoll_entity") or nil)
        if isLocalPlayer or isLocalRagdoll then
            pack.helmet:SetNoDraw(true)
        else
            pack.helmet:SetNoDraw(false)
        end
        updateAttachedEntity(ent, pack.helmet)
    end
    if IsValid(pack.vest) then updateAttachedEntity(ent, pack.vest) end
end

local function syncArmor(ent)
    if not IsValid(ent) then return end
    local isPlayer = ent:IsPlayer()
    local store = isPlayer and PL_ARM or RAG_ARM
    local pack = store[ent]
    if not pack then pack = {} store[ent] = pack end

    local hasHelm = ent:GetNWBool("HG_Helmet", false)
    local hasVest = ent:GetNWBool("HG_Vest", false)

    do
        local isLocalPlayer = isPlayer and ent == LocalPlayer()
        local isLocalRagdoll = (not isPlayer) and ent:GetClass() == "prop_ragdoll" and ent == (IsValid(LocalPlayer()) and LocalPlayer():GetNWEntity("hg_ragdoll_entity") or nil)
        local suppressLocal = isLocalPlayer or isLocalRagdoll
        local wantModel = (hasHelm and not suppressLocal) and ent:GetNWString("HG_HelmetModel", "") or ""
        local wantPos = ent:GetNWVector("HG_HelmetOffsetPos", Vector(0,0,0))
        local wantAng = ent:GetNWAngle("HG_HelmetOffsetAng", Angle(0,0,0))
        local cur = pack.helmet
        if wantModel ~= "" then
            local needNew = (not IsValid(cur)) or (cur:GetModel() ~= wantModel) or (cur.HG_Owner ~= ent)
            if needNew then
                if IsValid(cur) then cur:Remove() end
                pack.helmet = attach(ent, "helmet", wantModel, wantPos, wantAng)
            else
                if IsValid(cur) then cur.HG_OffPos = wantPos cur.HG_OffAng = wantAng end
            end
        else
            if IsValid(cur) then cur:Remove() pack.helmet = nil end
        end
    end

    do
        local wantModel = hasVest and ent:GetNWString("HG_VestModel", "") or ""
        local wantPos = ent:GetNWVector("HG_VestOffsetPos", Vector(0,0,0))
        local wantAng = ent:GetNWAngle("HG_VestOffsetAng", Angle(0,0,0))
        local cur = pack.vest
        if wantModel ~= "" then
            local needNew = (not IsValid(cur)) or (cur:GetModel() ~= wantModel) or (cur.HG_Owner ~= ent)
            if needNew then
                if IsValid(cur) then cur:Remove() end
                pack.vest = attach(ent, "vest", wantModel, wantPos, wantAng)
            else
                if IsValid(cur) then cur.HG_OffPos = wantPos cur.HG_OffAng = wantAng end
            end
        else
            if IsValid(cur) then cur:Remove() pack.vest = nil end
        end
    end

    if not hasHelm and not hasVest then
        if (not IsValid(pack.helmet)) and (not IsValid(pack.vest)) then
            store[ent] = nil
        end
    end
end

hook.Add("Think", "HG_Armor_Client_Sync", function()
    for _, ply in ipairs(player.GetAll()) do
        if IsValid(ply) then
            local rag = ply:GetNWEntity("hg_ragdoll_entity")
            if IsValid(rag) then
                -- Player is ragdolled: ensure player-attached armor is removed so it doesn't float
                removeArmorOn(ply)
            else
                -- Normal state: keep player armor in sync
                syncArmor(ply)
                -- Ensure local player's helmet is hidden in first-person even when PostPlayerDraw doesn't run
                if ply == LocalPlayer() then
                    local pack = PL_ARM[ply]
                    if pack and IsValid(pack.helmet) then
                        pack.helmet:SetNoDraw(not ply:ShouldDrawLocalPlayer())
                    end
                end
            end
        end
    end
    for _, rag in ipairs(ents.FindByClass("prop_ragdoll")) do
        local owner = rag:GetNWEntity("hg_ragdoll_owner")
        if IsValid(rag) and IsValid(owner) then
            if rag:GetNWBool("HG_Helmet", false) or rag:GetNWBool("HG_Vest", false) then
                syncArmor(rag)
            else
                removeArmorOn(rag)
            end
        end
    end
end)

hook.Add("PostPlayerDraw", "HG_Armor_Update_Player", function(ply)
    if not IsValid(ply) then return end
    updateArmor(ply)
end)

hook.Add("PostDrawOpaqueRenderables", "HG_Armor_Update_Ragdolls", function()
    for _, rag in ipairs(ents.FindByClass("prop_ragdoll")) do
        local owner = rag:GetNWEntity("hg_ragdoll_owner")
        if IsValid(rag) and IsValid(owner) and (rag:GetNWBool("HG_Helmet", false) or rag:GetNWBool("HG_Vest", false)) then
            updateArmor(rag)
        end
    end
end)

net.Receive("hg_clear_player_armor", function()
    local ent = net.ReadEntity()
    if IsValid(ent) then removeArmorOn(ent) end
end)

net.Receive("hg_clear_ragdoll_armor", function()
    local ent = net.ReadEntity()
    if IsValid(ent) then removeArmorOn(ent) end
end)

hook.Add("EntityRemoved", "HG_Armor_Client_Cleanup", function(ent)
    removeArmorOn(ent)
end)
