if CLIENT then
    local hidden = {
        ["CHudHealth"] = true,
        ["CHudBattery"] = true,
        ["CHudSuitPower"] = true,
        ["CHudAmmo"] = true,
        ["CHudSecondaryAmmo"] = true,
    }

    hook.Add("HUDShouldDraw", "homigrad_hide_default_hud", function(name)
        if hidden[name] then return false end
    end)
end
