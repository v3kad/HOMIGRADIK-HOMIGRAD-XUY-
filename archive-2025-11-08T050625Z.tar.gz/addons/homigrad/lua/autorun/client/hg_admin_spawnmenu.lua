hook.Add("SpawnMenuOpen", "hg_admin_only_spawnmenu", function()
    local ply = LocalPlayer()
    if not IsValid(ply) then return false end

    -- Always allow admins
    if ply:IsAdmin() or ply:IsSuperAdmin() then return end

    -- Allow guards in JailBreak submode
    local submodeName = tostring(ply.HomigradSubmode or "")
    local teamName = ply:GetNWString("HomigradTeam", "")
    if submodeName == "JailBreak" and teamName == "guards" then return end

    -- Otherwise block
    return false
end)
