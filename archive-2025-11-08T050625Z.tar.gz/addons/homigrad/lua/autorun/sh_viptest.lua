if SERVER then
    util.AddNetworkString("hg_viptest_show")

    hook.Add("PlayerSay", "HG_VIPTest_Command", function(ply, text)
        if not IsValid(ply) then return end
        if string.lower(string.Trim(text)) == "!viptest" then
            net.Start("hg_viptest_show")
            net.Send(ply)
            return ""
        end
    end)

    return
end

-- CLIENT
local showUntil = 0
local mat
local FONT_NAME = "HG_VIP_Font"

if CLIENT then
    surface.CreateFont(FONT_NAME, {
        font = "Trebuchet MS",
        size = 48,
        weight = 800,
        antialias = true,
        additive = false,
        extended = true
    })
end

net.Receive("hg_viptest_show", function()
    showUntil = CurTime() + 5
    if not mat then
        mat = Material("homigrad/ui/default.png", "smooth")
    end
end)

hook.Add("HUDPaint", "HG_VIPTest_Draw", function()
    if CurTime() > showUntil then return end

    local scrW, scrH = ScrW(), ScrH()
    local imgW, imgH = math.floor(scrW * 0.25), math.floor(scrH * 0.25)
    local x = (scrW - imgW) / 2
    local y = (scrH - imgH) / 2 - 40

    if mat then
        surface.SetDrawColor(255, 255, 255, 255)
        surface.SetMaterial(mat)
        surface.DrawTexturedRect(x, y, imgW, imgH)
    end

    local text = "ХУЙ ТЕБЕ"
    surface.SetFont(FONT_NAME)
    local ok, tw, th = pcall(surface.GetTextSize, text)
    tw = tonumber(tw) or 0
    th = tonumber(th) or 0
    local tx = math.floor(scrW / 2 - tw / 2)
    local ty = math.floor(y + imgH + 20)
    -- outline
    surface.SetTextColor(0, 0, 0, 200)
    surface.SetTextPos(tx - 2, ty)
    surface.DrawText(text)
    surface.SetTextPos(tx + 2, ty)
    surface.DrawText(text)
    surface.SetTextPos(tx, ty - 2)
    surface.DrawText(text)
    surface.SetTextPos(tx, ty + 2)
    surface.DrawText(text)
    -- main text
    surface.SetTextColor(255, 50, 50)
    surface.SetTextPos(tx, ty)
    surface.DrawText(text)
end)
