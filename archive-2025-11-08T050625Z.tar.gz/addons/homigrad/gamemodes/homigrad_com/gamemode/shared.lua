DeriveGamemode("sandbox")
GM.Name = "HOMIGRADCOM"
GM.Author 		= "uhh"
GM.Email 		= ""
GM.Website 		= ""
GM.TeamBased = false


function GM:PlayerInitialSpawn(ply)
    ply:SetTeam(1)
    ply:SendLua([[chat.AddText(Color(0,200,200), "Добро пожаловать в Homigrad!")]])
end

hook.Add("PlayerSpawn", "GiveWeaponOnSpawn", function(ply)
    timer.Simple(1, function() --задержка перед раундом
        if IsValid(ply) then
            ply:Give("wep_hands") 
            ply:SelectWeapon("wep_hands") --сразу берется
        end
    end)
end)

--удаление монтировки
function StripCrowbar(ply)
    ply:StripWeapon("weapon_crowbar")
end