AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
AddCSLuaFile("config.lua")
AddCSLuaFile("modules/organism.lua")
AddCSLuaFile("modules/cl_camerabob.lua")

include("shared.lua")
include("config.lua")
include("modules/manager.lua")
include("modules/organism.lua")

-- Регистрируем сетевые сообщения (только на сервере)
util.AddNetworkString("Homigrad_SubmodeUpdate")
util.AddNetworkString("Homigrad_RoundEnd")
util.AddNetworkString("Homigrad_ObserverMode")
util.AddNetworkString("Homigrad_WaitingForPlayers")
util.AddNetworkString("Homigrad_PoliceArrival")
util.AddNetworkString("Homigrad_NextMode")
util.AddNetworkString("Homigrad_ScoreboardData")
util.AddNetworkString("Homigrad_MutePlayer")
util.AddNetworkString("Homigrad_SpectatorSwitch")
util.AddNetworkString("Homigrad_SpectatorPlayerSwitch")
util.AddNetworkString("Homigrad_AdminEndRound")
util.AddNetworkString("Homigrad_AdminSelectNextMode")
util.AddNetworkString("Homigrad_AdminGetAvailableModes")
util.AddNetworkString("Homigrad_SelectTeam")
util.AddNetworkString("Homigrad_SetCustomPlayermodel")

local submodeFiles = file.Find("gamemodes/homigrad_com/gamemode/modules/submodes/*.lua", "GAME")
for _, f in ipairs(submodeFiles) do
    include("modules/submodes/" .. f)
end

if SubmodeManager and SubmodeManager.Initialize then
    hook.Add("Initialize", "Homigrad_Init_Manager", function()
        SubmodeManager:Initialize()
    end)
end

-- Белый список моделей для кастомизации (должен совпадать с клиентским списком)
local CustomModelsWhitelist = {
    ["models/mug/ncfom/anton_chigurh.mdl"] = true,
    ["models/zenlesszonezero/Corin Wickes.mdl"] = true,
    ["models/dark_donald.mdl"] = true,
    ["models/kaneki_white/Kaneki_white.mdl"] = true,
    ["models/mellstroy/mellstroy.mdl"] = true,
    ["models/player/pissbaby.mdl"] = true,
    ["models/lyn/lynplayermodel.mdl"] = true
}

-- Разрешённые режимы для смены модели
local AllowedCustomizationModes = {
    jailbreak = true,
    dm = true,
    homicide = true
}

-- Обработчик выбора модели от клиента
net.Receive("Homigrad_SetCustomPlayermodel", function(len, ply)
    if not IsValid(ply) then return end
    local mdl = string.Trim(net.ReadString() or "")
    if mdl == "" then return end
    if not CustomModelsWhitelist[mdl] then
        print("[Homigrad|Server] Rejected model from " .. ply:Nick() .. ": " .. tostring(mdl))
        ply:ChatPrint("Эта модель недоступна для выбора.")
        return
    end

    ply:SetNWString("HG_CustomModel", mdl)
    if SubmodeManager and SubmodeManager.isRoundStart then
        util.PrecacheModel(mdl)
        ply:SetModel(mdl)
        if ply.SetupHands then ply:SetupHands() end
        print("[Homigrad|Server] Set model for " .. ply:Nick() .. ": " .. mdl)
        ply:ChatPrint("Модель установлена!")
    else
        print("[Homigrad|Server] Saved model for " .. ply:Nick() .. ": " .. mdl)
        ply:ChatPrint("Модель будет применена в начале следующего раунда.")
    end
end)

hook.Add("Think", "Homigrad_Think", function()
    SubmodeManager:Think()
end)

-- Применяем сохранённую кастомную модель при спавне
hook.Add("PlayerSpawn", "Homigrad_ApplyCustomModel", function(ply)
    local mdl = ply:GetNWString("HG_CustomModel", "")
    if mdl ~= "" and SubmodeManager and SubmodeManager.isRoundStart then
        util.PrecacheModel(mdl)
        ply:SetModel(mdl)
        if ply.SetupHands then ply:SetupHands() end
    end
end)

function GM:PlayerSpawn(ply)
    -- Всегда оставляем в наблюдателях тех, кто выбрал команду наблюдателей
    do
        local teamId = ply:GetNWString("HomigradTeam", "")
        if teamId == "spectators" then
            ply:Spectate(OBS_MODE_ROAMING)
            ply:SetMoveType(MOVETYPE_OBSERVER)
            ply:SetNWBool("HomigradObserverMode", true)
            net.Start("Homigrad_ObserverMode")
                net.WriteBool(true)
            net.Send(ply)
            return
        end
    end

    -- Проверяем количество игроков на сервере
    local playerCount = #player.GetAll()
    local waitingForPlayers = SubmodeManager and SubmodeManager.waitingForPlayers

    -- Если игроков меньше 2 — всё равно удерживаем в наблюдателях
    if playerCount < 2 then
        ply:Spectate(OBS_MODE_ROAMING)
        ply:SetMoveType(MOVETYPE_OBSERVER)
        ply:SetNWBool("HomigradObserverMode", true)
        net.Start("Homigrad_ObserverMode")
            net.WriteBool(true)
        net.Send(ply)
        ply:ChatPrint("Вы переведены в режим наблюдателя")
        if waitingForPlayers then
            ply:ChatPrint("Для начала игры необходимо минимум 2 игрока")
        else
            ply:ChatPrint("Ожидайте начала следующего раунда")
        end
        return
    end

    -- Выходим из режима наблюдателя только для тех, кто не spectator
    ply:SetNWBool("HomigradObserverMode", false)
    net.Start("Homigrad_ObserverMode")
        net.WriteBool(false)
    net.Send(ply)
    ply:UnSpectate()
    ply:SetMoveType(MOVETYPE_WALK)

    -- Safety reset: ensure player is fully visible after previous ragdoll/observer
    if SERVER then
        ply:RemoveEffects(EF_NODRAW)
        ply:SetNoDraw(false)
        ply:DrawWorldModel(true)
        ply:DrawViewModel(true)
        ply:DrawShadow(true)
        -- Restore render mode/color (alpha 255)
        local c = ply:GetColor() or Color(255,255,255,255)
        ply:SetRenderMode(RENDERMODE_NORMAL)
        ply:SetColor(Color(c.r or 255, c.g or 255, c.b or 255, 255))
        -- Restore collisions
        ply:SetNotSolid(false)
        ply:SetCollisionGroup(COLLISION_GROUP_PLAYER)
        ply:SetNoTarget(false)
        -- Restore weapons draw/collision
        for _, wep in ipairs(ply:GetWeapons() or {}) do
            if IsValid(wep) then
                wep:SetNoDraw(false)
                wep:DrawShadow(true)
                if wep.SetNotSolid then wep:SetNotSolid(false) end
                if wep.SetCollisionGroup then wep:SetCollisionGroup(COLLISION_GROUP_WEAPON) end
            end
        end
        -- Clear ragdoll network ref if any
        if ply.SetNWEntity then ply:SetNWEntity("hg_ragdoll_entity", NULL) end
        if ply.SetNWBool then ply:SetNWBool("hg_pain_ragdoll", false) end
    end

    -- Проверяем, это начало раунда или обычный спавн
    if SubmodeManager and SubmodeManager.isRoundStart then
        -- В начале раунда игроки спавнятся живыми
        print("[Homigrad] Round start spawn - player will be alive")
    else
        -- При обычном спавне игроки остаются мертвыми
        ply:Spectate(OBS_MODE_ROAMING)
        ply:SetMoveType(MOVETYPE_OBSERVER)
        ply:ChatPrint("Вы мертвы! Ожидайте начала следующего раунда.")
        ply:ChatPrint("Нажмите [R] для смены режима наблюдения.")
    end
    
    -- Передаем управление спавном текущему суб-режиму для настройки позиции
    if SubmodeManager.current and SubmodeManager.current.PlayerSpawn then
        local ok, res = pcall(function() return SubmodeManager.current:PlayerSpawn(ply) end)
        if ok and res ~= nil then return res end
    else
        -- Запасная позиция, если что-то пошло не так
        ply:SetPos(Vector(0,0,100))
    end
    
    return
end

function GM:PlayerDeath(ply, inflictor, attacker)
    -- Снимок лута до удаления оружия
    local lootSnapshot = {}
    do
        local items = {}
        for _, wep in ipairs(ply:GetWeapons() or {}) do
            local class = IsValid(wep) and wep:GetClass() or nil
            if class and not (class == "wep_hands" or class == "weapon_hands") then
                table.insert(items, { kind = "weapon", class = class, name = (wep.PrintName or class) })
            end
        end
        local aw = ply:GetActiveWeapon()
        if IsValid(aw) then
            local atype = aw:GetPrimaryAmmoType()
            if atype and atype > -1 then
                local count = ply:GetAmmoCount(atype)
                if count and count > 0 then
                    table.insert(items, { kind = "ammo", name = game.GetAmmoName(atype) or "Ammo", amount = count, ammoType = atype })
                end
            end
        end
        lootSnapshot = items
    end
    -- Сохраняем снимок лута на игроке, чтобы применить его в CreateEntityRagdoll
    ply._hgLootSnapshot = lootSnapshot or {}
    do
        local existing = ply.GetNWEntity and ply:GetNWEntity("hg_ragdoll_entity") or NULL
        if IsValid(existing) and existing:GetClass() == "prop_ragdoll" then
            existing:SetNWEntity("hg_ragdoll_owner", ply)
            existing:SetCollisionGroup(COLLISION_GROUP_WEAPON)
            if ply.GetSkin then existing:SetSkin(ply:GetSkin() or 0) end
            if ply.GetNumBodyGroups then
                for i = 0, (ply:GetNumBodyGroups() or 0) - 1 do
                    existing:SetBodygroup(i, ply:GetBodygroup(i) or 0)
                end
            end
            existing.HG_LootInventory = lootSnapshot or {}
            if HG_CopyArmorToRagdoll then
                HG_CopyArmorToRagdoll(ply, existing)
            end
            -- Не очищаем ссылку NW здесь; это труп игрока
        else
            -- Не создаем рэгдолл вручную. Дождемся engine CreateEntityRagdoll и обработаем там.
            -- На всякий случай попытаемся применить после небольшого задержки, если рэгдолл уже появится
            timer.Simple(0, function()
                if not IsValid(ply) then return end
                local rag = ply.GetNWEntity and ply:GetNWEntity("hg_ragdoll_entity") or NULL
                if IsValid(rag) and rag:GetClass() == "prop_ragdoll" then
                    rag:SetNWEntity("hg_ragdoll_owner", ply)
                    rag:SetCollisionGroup(COLLISION_GROUP_WEAPON)
                    if ply.GetSkin then rag:SetSkin(ply:GetSkin() or 0) end
                    if ply.GetNumBodyGroups then
                        for i = 0, (ply:GetNumBodyGroups() or 0) - 1 do
                            rag:SetBodygroup(i, ply:GetBodygroup(i) or 0)
                        end
                    end
                    rag.HG_LootInventory = ply._hgLootSnapshot or {}
                    if HG_CopyArmorToRagdoll then
                        HG_CopyArmorToRagdoll(ply, rag)
                    end
                end
            end)
        end
    end
    ply:StripWeapons()
    
    -- Система наблюдения
    timer.Simple(0.5, function() 
        if IsValid(ply) then
            ply:Spectate(OBS_MODE_ROAMING)
            ply:ChatPrint("Вы мертвы! Ожидайте следующего раунда.")
            ply:ChatPrint("Нажмите [R] для смены режима наблюдения.")
        end
    end)
    
    return
end

function GM:PlayerDeathThink(ply)
    return false -- Запретить респавн
end


-- Хук для проверки количества игроков при подключении/отключении
hook.Add("PlayerDisconnected", "Homigrad_PlayerDisconnected", function(ply)
    -- Проверяем количество оставшихся игроков
    timer.Simple(0.1, function()
        local playerCount = #player.GetAll()
        if playerCount < 2 then
            -- Если остался только один игрок, переводим его в режим наблюдателя
            for _, remainingPly in ipairs(player.GetAll()) do
                if IsValid(remainingPly) then
                    remainingPly:Spectate(OBS_MODE_ROAMING)
                    remainingPly:SetMoveType(MOVETYPE_OBSERVER)
                    remainingPly:SetNWBool("HomigradObserverMode", true)
                    
                    net.Start("Homigrad_ObserverMode")
                        net.WriteBool(true)
                    net.Send(remainingPly)
                    
                    remainingPly:ChatPrint("Вы переведены в режим наблюдателя")
                    remainingPly:ChatPrint("Для начала игры необходимо минимум 2 игрока")
                end
            end
        end
    end)
end)

hook.Add("PlayerInitialSpawn", "Homigrad_PlayerInitialSpawn", function(ply)
    -- Сразу же помещаем нового игрока в режим наблюдателя
    timer.Simple(0.1, function()
        if not IsValid(ply) then return end
        
        -- Убиваем игрока чтобы ScoreBoard показывал его как мёртвого
        ply:KillSilent()
        
        -- Переводим в режим наблюдателя
        ply:Spectate(OBS_MODE_ROAMING)
        ply:SetMoveType(MOVETYPE_OBSERVER)
        ply:SetNWBool("HomigradObserverMode", true)
        -- По умолчанию считаем всех наблюдателями, пока игрок сам не выйдет
        ply:SetNWString("HomigradTeam", "spectators")
        ply:SetNWString("CurrentTeamDisplay", "Наблюдатели")
        
        net.Start("Homigrad_ObserverMode")
            net.WriteBool(true)
        net.Send(ply)
        
        ply:ChatPrint("Вы подключены к серверу")
        ply:ChatPrint("Ожидайте начала следующего раунда")
    end)
end)

hook.Add("ShutDown", "Homigrad_Shutdown", function()
    if SubmodeManager and SubmodeManager.Shutdown then
        SubmodeManager:Shutdown()
    end
end)

-- ScoreBoard система
local PlayerPlaytime = {} -- Хранилище времени игры для каждого игрока
local PlayerMutes = {} -- Хранилище мутированных игроков

-- Функция для получения времени игры игрока
local function GetPlayerPlaytime(ply)
    local steamid = ply:SteamID()
    if not PlayerPlaytime[steamid] then
        PlayerPlaytime[steamid] = {
            totalTime = 0,
            sessionStart = CurTime()
        }
    end
    return PlayerPlaytime[steamid]
end

-- Обновление времени игры
hook.Add("Think", "Homigrad_PlaytimeUpdate", function()
    for _, ply in ipairs(player.GetAll()) do
        if IsValid(ply) then
            local playtimeData = GetPlayerPlaytime(ply)
            playtimeData.totalTime = playtimeData.totalTime + FrameTime()
        end
    end
end)

-- Отправка данных ScoreBoard клиенту
local function SendScoreboardData(ply)
    if not IsValid(ply) then return end
    
    local players = player.GetAll()
    local scoreboardData = {}
    
    -- Проверяем, находимся ли мы в режиме Homicide
    local isHomicideMode = false
    if SubmodeManager and SubmodeManager.current then
        isHomicideMode = (SubmodeManager.current.__homigrad_id == "homicide")
    end
    
    for _, targetPly in ipairs(players) do
        if IsValid(targetPly) then
            local playtimeData = GetPlayerPlaytime(targetPly)
            local totalHours = math.floor(playtimeData.totalTime / 3600)
            local totalMinutes = math.floor((playtimeData.totalTime % 3600) / 60)
            
            -- В режиме Homicide показываем команду только себе
            local teamDisplay = targetPly:GetNWString("CurrentTeamDisplay", "НЕИЗВЕСТНО")
            if isHomicideMode and targetPly ~= ply then
                -- Для других игроков в режиме Homicide показываем "Неизвестно"
                teamDisplay = "Неизвестно"
            end
            
            table.insert(scoreboardData, {
                steamid = targetPly:SteamID(),
                name = targetPly:Nick(),
                team = targetPly:GetNWString("HomigradTeam", "unknown"),
                teamDisplay = teamDisplay,
                playtime = string.format("%dч %dм", totalHours, totalMinutes),
                ping = targetPly:Ping(),
                alive = targetPly:Alive(),
                muted = PlayerMutes[targetPly:SteamID()] or false
            })
        end
    end

    -- Сортируем так, чтобы наблюдатели были внизу списка
    table.sort(scoreboardData, function(a, b)
        local aSpec = (a.team == "spectators")
        local bSpec = (b.team == "spectators")
        if aSpec ~= bSpec then
            return not aSpec and bSpec == true
        end
        return a.name < b.name
    end)
    
    net.Start("Homigrad_ScoreboardData")
        net.WriteTable(scoreboardData)
    net.Send(ply)
end

-- Обработчик запроса данных ScoreBoard
net.Receive("Homigrad_ScoreboardData", function(len, ply)
    SendScoreboardData(ply)
end)

-- Обработчик запроса смены команды в JailBreak
net.Receive("Homigrad_SelectTeam", function(len, ply)
    if not IsValid(ply) then return end
    
    local requestedTeam = net.ReadString()
    if requestedTeam ~= "guards" and requestedTeam ~= "prisoners" and requestedTeam ~= "spectators" and requestedTeam ~= "players" then return end

    -- Обработка выбора наблюдателей доступна в любом режиме
    if requestedTeam == "spectators" then
        ply:SetNWString("HomigradTeam", "spectators")
        ply:SetNWString("CurrentTeamDisplay", "Наблюдатели")
        ply:StripWeapons()
        ply:KillSilent()
        ply:Spectate(OBS_MODE_ROAMING)
        ply:SetMoveType(MOVETYPE_OBSERVER)
        ply:SetNWBool("HomigradObserverMode", true)
        net.Start("Homigrad_ObserverMode")
            net.WriteBool(true)
        net.Send(ply)
        ply:ChatPrint("Вы присоединились к наблюдателям. Вы не будете спавниться в начале раунда.")
        return
    end

    -- Общая обработка выхода из наблюдателей на не-JailBreak режимах
    if requestedTeam == "players" then
        -- Разрешаем только вне JailBreak
        if not SubmodeManager or not SubmodeManager.current or SubmodeManager.current.__homigrad_id ~= "jailbreak" then
            ply:SetNWString("HomigradTeam", "players")
            ply:SetNWString("CurrentTeamDisplay", "Игрок")
            ply:SetNWBool("HomigradObserverMode", false)
            ply:UnSpectate()
            ply:SetMoveType(MOVETYPE_WALK)
            if SubmodeManager and SubmodeManager.isRoundStart then
                timer.Simple(0.1, function() if IsValid(ply) then ply:Spawn() end end)
            else
                ply:ChatPrint("Вы выйдете из наблюдателей в начале следующего раунда.")
            end
        end
        return
    end

    -- Ниже — логика только для JailBreak команд
    if not SubmodeManager or not SubmodeManager.current then return end
    if SubmodeManager.current.__homigrad_id ~= "jailbreak" then return end
    
    local currentTeam = ply:GetNWString("HomigradTeam", "")
    
    -- Если игрок уже в этой команде, ничего не делаем
    if currentTeam == requestedTeam then
        ply:ChatPrint("Вы уже находитесь в этой команде!")
        return
    end
    
    -- Подсчитываем количество игроков в каждой команде (всех, не только живых)
    local guardsCount = 0
    local prisonersCount = 0
    for _, p in ipairs(player.GetAll()) do
        if IsValid(p) then
            local team = p:GetNWString("HomigradTeam", "")
            if team == "guards" then
                guardsCount = guardsCount + 1
            elseif team == "prisoners" then
                prisonersCount = prisonersCount + 1
            end
        end
    end
    
    -- Вычисляем максимальное количество охранников
    local totalPlayers = #player.GetAll()
    local maxGuards = 1
    if totalPlayers <= 6 then
        maxGuards = 1
    elseif totalPlayers <= 12 then
        maxGuards = 2
    elseif totalPlayers <= 18 then
        maxGuards = 3
    else
        maxGuards = 4
    end
    
    -- Проверяем, можно ли стать охранником
    if requestedTeam == "guards" then
        -- Если игрок уже охранник, разрешаем остаться
        if currentTeam ~= "guards" and guardsCount >= maxGuards then
            ply:ChatPrint("Нет свободных мест для охранников! Максимум: " .. maxGuards)
            return
        end
    end
    
    -- Меняем команду игрока
    local jailbreakMode = SubmodeManager.current
    local wasGuardBefore = (currentTeam == "guards")
    
    if requestedTeam == "guards" then
        -- Проверяем, был ли до этого хотя бы один охранник (не считая текущего игрока)
        local hadGuardsBefore = false
        if not wasGuardBefore then
            for _, p in ipairs(player.GetAll()) do
                if IsValid(p) and p ~= ply then
                    local team = p:GetNWString("HomigradTeam", "")
                    if team == "guards" then
                        hadGuardsBefore = true
                        break
                    end
                end
            end
        else
            hadGuardsBefore = true -- Если игрок уже был охранником, значит охранники были
        end
        
        ply:SetTeam(2)
        ply:SetNWString("HomigradTeam", "guards")
        ply:SetNWString("CurrentTeamDisplay", "Охранник")
        if jailbreakMode and jailbreakMode.GuardModels then
            ply:SetModel(table.Random(jailbreakMode.GuardModels))
        end
        ply:StripWeapons()
        
        -- Выдаём броню
        if HG_GiveVestByModel then
            HG_GiveVestByModel(ply, "models/eft_props/gear/armor/ar_thor_crv.mdl")
        end
        
        ply:ChatPrint("Вы присоединились к команде охранников!")
        
        -- Перезапуск раунда теперь обрабатывается в manager.lua в Think()
        -- Здесь мы просто обновляем команду игрока
    elseif requestedTeam == "prisoners" then
        ply:SetTeam(1)
        ply:SetNWString("HomigradTeam", "prisoners")
        ply:SetNWString("CurrentTeamDisplay", "Заключённый")
        if jailbreakMode and jailbreakMode.PrisonerModels then
            ply:SetModel(table.Random(jailbreakMode.PrisonerModels))
        end
        ply:StripWeapons()
        
        -- Убираем броню
        if HG_Armor_RoundEndCleanup then
            -- Удаляем текущую броню через очистку (если есть такая функция)
            local armorEnts = ents.FindByClass("hg_armor_*")
            for _, ent in ipairs(armorEnts) do
                if IsValid(ent) and ent:GetOwner() == ply then
                    ent:Remove()
                end
            end
        end
        
        ply:ChatPrint("Вы присоединились к команде заключённых!")
    end
    
    -- Респавним игрока на новых точках спавна
    local spawnType = requestedTeam == "guards" and "jb_guards" or "jb_prisoners"
    local spawns = HOMIGRAD_GetSpawnPoints(spawnType)
    if #spawns > 0 then
        ply:Spectate(OBS_MODE_ROAMING)
        ply:SetMoveType(MOVETYPE_OBSERVER)
        timer.Simple(0.1, function()
            if IsValid(ply) then
                ply:Spawn()
            end
        end)
    end
    
    print("[Homigrad|JailBreak] Player " .. ply:Nick() .. " switched to team: " .. requestedTeam)
end)

-- Обработчик мута игрока
net.Receive("Homigrad_MutePlayer", function(len, ply)
    local targetSteamID = net.ReadString()
    local muteAction = net.ReadBool() -- true = мутить, false = размутить
    
    -- Проверяем права (только админы могут мутить)
    if not ply:IsAdmin() then
        ply:ChatPrint("У вас нет прав для мута игроков!")
        return
    end
    
    local targetPly = nil
    for _, p in ipairs(player.GetAll()) do
        if p:SteamID() == targetSteamID then
            targetPly = p
            break
        end
    end
    
    if not IsValid(targetPly) then
        ply:ChatPrint("Игрок не найден!")
        return
    end
    
    if muteAction then
        PlayerMutes[targetSteamID] = true
        ply:ChatPrint("Игрок " .. targetPly:Nick() .. " замьючен!")
        targetPly:ChatPrint("Вы замьючены администратором!")
    else
        PlayerMutes[targetSteamID] = false
        ply:ChatPrint("Игрок " .. targetPly:Nick() .. " размьючен!")
        targetPly:ChatPrint("Вы размьючены администратором!")
    end
    
    -- Отправляем обновленные данные всем игрокам
    for _, p in ipairs(player.GetAll()) do
        SendScoreboardData(p)
    end
end)

-- Обработчик смены режима наблюдения
net.Receive("Homigrad_SpectatorSwitch", function(len, ply)
    if not IsValid(ply) then return end
    
    -- Проверяем, что игрок мертв и является наблюдателем
    if ply:Alive() then return end
    
    local currentMode = ply:GetObserverMode()
    if not currentMode or currentMode == OBS_MODE_NONE then return end
    
    local currentTarget = ply:GetObserverTarget()
    
    local nextTarget = nil
    local nextMode = OBS_MODE_ROAMING
    
    if currentMode == OBS_MODE_ROAMING then
        nextMode = OBS_MODE_IN_EYE
        for _, p in ipairs(player.GetAll()) do
            if p:Alive() and p ~= ply then
                nextTarget = p
                break
            end
        end
        if not IsValid(nextTarget) then
            nextMode = OBS_MODE_ROAMING
        end

    elseif currentMode == OBS_MODE_IN_EYE then
        nextMode = OBS_MODE_CHASE
        nextTarget = currentTarget
        if not IsValid(nextTarget) or not nextTarget:Alive() then
            for _, p in ipairs(player.GetAll()) do
                if p:Alive() and p ~= ply then
                    nextTarget = p
                    break
                end
            end
            if not IsValid(nextTarget) then
                nextMode = OBS_MODE_ROAMING
            end
        end

    elseif currentMode == OBS_MODE_CHASE then
        nextMode = OBS_MODE_ROAMING
        nextTarget = nil
    end
    
    -- Применяем новый режим на сервере
    ply:Spectate(nextMode)
    
    if IsValid(nextTarget) then
        ply:SpectateEntity(nextTarget)
    end
end)

-- Обработчик переключения между игроками
net.Receive("Homigrad_SpectatorPlayerSwitch", function(len, ply)
    if not IsValid(ply) then return end
    
    -- Проверяем, что игрок мертв и находится в режиме наблюдения
    if ply:Alive() then return end
    
    local obsMode = ply:GetObserverMode()
    if not obsMode or obsMode == OBS_MODE_NONE or obsMode == OBS_MODE_ROAMING then return end
    
    -- Получаем новую цель от клиента
    local newTarget = net.ReadEntity()
    if not IsValid(newTarget) or not newTarget:IsPlayer() or not newTarget:Alive() then return end
    
    -- Переключаемся на нового игрока
    ply:SpectateEntity(newTarget)
end)

-- Очистка данных при отключении игрока
hook.Add("PlayerDisconnected", "Homigrad_CleanupScoreboard", function(ply)
    local steamid = ply:SteamID()
    PlayerPlaytime[steamid] = nil
    PlayerMutes[steamid] = nil
end)

-- Обработчики для админ-меню
net.Receive("Homigrad_AdminEndRound", function(len, ply)
    if not IsValid(ply) then return end
    
    -- Проверяем права администратора
    if not ply:IsAdmin() then
        ply:ChatPrint("У вас нет прав администратора!")
        return
    end
    
    -- Завершаем текущий раунд
    if SubmodeManager and SubmodeManager.current then
        -- Определяем режим по ID (riot или homicide)
        local currentModeID = "unknown"
        for id, mode in pairs(SubmodeManager.submodes) do
            if mode == SubmodeManager.current then
                currentModeID = id
                break
            end
        end
        
        -- Вызываем End() у текущего режима
        if SubmodeManager.current.End then
            pcall(function() SubmodeManager.current:End() end)
        end
        
        -- Отправляем информацию о завершении всем клиентам
        net.Start("Homigrad_RoundEnd")
            net.WriteString(currentModeID)
            net.WriteString("Ничья")
            net.WriteString("")
        net.Broadcast()
        if HG_Armor_RoundEndCleanup then HG_Armor_RoundEndCleanup() end
        
        -- Принудительно выводим всех игроков из рэгдолла и очищаем состояния, чтобы они могли нормально заспавниться в следующем раунде
        for _, p in ipairs(player.GetAll()) do
            if IsValid(p) then
                if p.SetNWBool then
                    p:SetNWBool("HG_Blackout", false)
                    p:SetNWBool("hg_pain_ragdoll", false)
                end
                if p.SetHGBrokenSpine then p:SetHGBrokenSpine(false) end
                if p.SetHGBrokenLeg then p:SetHGBrokenLeg(false) end
                if HG_StopRagdoll then HG_StopRagdoll(p, true) end
            end
        end
        
        ply:ChatPrint("Раунд завершен администратором!")
        
        -- Запускаем следующий раунд через 7 секунд
        timer.Simple(7, function()
            if SubmodeManager and SubmodeManager.StartNext then
                SubmodeManager.isEnding = false
                SubmodeManager:StartNext()
            end
        end)
    end
end)

net.Receive("Homigrad_AdminSelectNextMode", function(len, ply)
    if not IsValid(ply) then return end
    
    -- Проверяем права администратора
    if not ply:IsAdmin() then
        ply:ChatPrint("У вас нет прав администратора!")
        return
    end
    
    local modeID = net.ReadString()
    
    if not modeID or modeID == "" then return end
    
    -- Проверяем, что режим существует
    if not SubmodeManager.submodes[modeID] then
        ply:ChatPrint("Режим '" .. modeID .. "' не найден!")
        return
    end
    
    -- Сохраняем следующий режим в SubmodeManager
    SubmodeManager.nextModeID = modeID
    -- Также обновляем планируемый следующий режим, чтобы клиент видел актуальный выбор
    SubmodeManager.scheduledNextID = modeID
    -- Найдем длительность из order, если возможно
    do
        SubmodeManager.scheduledNextDuration = nil
        for _, entry in ipairs(SubmodeManager.order or {}) do
            if entry.id == modeID then
                SubmodeManager.scheduledNextDuration = entry.duration
                break
            end
        end
    end
    
    -- Уведомляем игрока
    ply:ChatPrint("Следующий раунд будет: " .. (SubmodeManager.submodes[modeID].Name or modeID))
    ply:ChatPrint("Текущий раунд продолжится...")
    
    -- Отправляем информацию о следующем режиме всем клиентам
    local nextMode = SubmodeManager.submodes[modeID]
    local nextModeName = nextMode and (nextMode.Name or modeID) or "Unknown"
    
    net.Start("Homigrad_NextMode")
        net.WriteString(nextModeName)
    net.Broadcast()
end)

net.Receive("Homigrad_AdminGetAvailableModes", function(len, ply)
    if not IsValid(ply) then return end
    
    -- Проверяем права администратора
    if not ply:IsAdmin() then
        return
    end
    
    -- Отправляем список доступных режимов
    local modes = {}
    for k, v in pairs(SubmodeManager.submodes) do
        table.insert(modes, {
            id = k,
            name = v.Name or k
        })
    end
    
    net.Start("Homigrad_AdminGetAvailableModes")
        net.WriteTable(modes)
    net.Send(ply)
end)