include("shared.lua")
include("modules/organism.lua")
include("modules/cl_camerabob.lua")

-- Убираем стандартный HUD
do
	local hidden = {
		["CHudHealth"] = true,
		["CHudBattery"] = true,
		["CHudAmmo"] = true,
		["CHudSecondaryAmmo"] = true,
		["CHudCrosshair"] = true,
		["CHudWeaponSelection"] = false,
		["CHudSuitPower"] = true,
		["CHudPoisonDamageIndicator"] = true,
		["CHudSquadStatus"] = true,
		["CHudZoom"] = true,
		["CHudHistoryResource"] = true,
		["CHudDamageIndicator"] = true,
		["CHudGeiger"] = true,
		["CHudTrain"] = true,
		["CHudVehicle"] = true,
		["CHudTargetID"] = true,
	}

	hook.Add("HUDShouldDraw", "Homigrad_HideDefaultHUD", function(name)
		if hidden[name] then return false end
	end)
end
-- Устанавливаем FOV 120 для режима наблюдателя
hook.Add("CalcView", "Homigrad_ObserverFOV", function(ply, pos, ang, fov)
	if ply ~= LocalPlayer() then return end
	if ply:Alive() then return end -- Пропускаем живых игроков
	local obsMode = ply:GetObserverMode()
	if not obsMode or obsMode == OBS_MODE_NONE then return end
	
	-- Устанавливаем FOV 120 для всех режимов наблюдения
	return { origin = pos, angles = ang, fov = 120 }
end)

surface.CreateFont("HomigradLarge", {font = "Arial", size = 24, weight = 700})
surface.CreateFont("RiotWinner", {font = "Arial", size = 48, weight = 700})
surface.CreateFont("DermaLarge", {font = "Trebuchet MS", size = 32, weight = 500})

-- Шрифты для ScoreBoard
surface.CreateFont("ScoreboardTitle", {font = "Arial", size = 28, weight = 700})
surface.CreateFont("ScoreboardPlayerName", {font = "HudDefault", size = 16, weight = 600})
surface.CreateFont("ScoreboardInfo", {font = "HudDefault", size = 18, weight = 600})
surface.CreateFont("ScoreboardButton", {font = "Arial", size = 12, weight = 600})

-- Настраиваемые шрифты для HUD
-- Для изменения размера текста измените параметр 'size' ниже:
-- PoliceTimerFont: размер 28 (можно изменить на любое значение, например 32, 36, 40)
-- ModeInfoFont: размер 16 (можно изменить на любое значение, например 18, 20, 24)
surface.CreateFont("CustomPoliceTimer", {font = "HudDefault", size = 18, weight = 700})
surface.CreateFont("CustomModeInfo", {font = "CloseCaption_Bold", size = 26, weight = 600})
surface.CreateFont("CustomMenu", {font = "CloseCaption_Bold", size = 20, weight = 1100})

-- Переменные для отображения результатов
local RoundEndTimer = 0
local RoundEndWinner = ""
local RoundEndMode = ""
local RoundEndTraitorNames = ""
local IsObserverMode = false
local WaitingForPlayers = false

-- Переменные для отображения информации при зажатии Tab
local TabHudAlpha = 0
local TabHudTargetAlpha = 0
local TabHudFadeSpeed = 3
local PoliceArrivalTime = 0
local NextModeName = ""

-- Заголовок режима в начале раунда
local ModeStartName = nil
local ModeStartUntil = 0



-- Цель игрока в начале раунда (снизу по центру)
local ObjectiveText = nil
local ObjectiveUntil = 0

-- Генерация текста задачи по режиму и роли игрока
local function Homigrad_GenerateObjective(modeLower)
	local ply = LocalPlayer()
	if not IsValid(ply) then return nil end

	modeLower = tostring(modeLower or ""):lower()
	if modeLower == "riot" then
		local team = ply:GetNWString("HomigradTeam", "")
		if team == "police" then
			return "Ликвидируйте или нейтрализуйте бунтующих"
		else
			return "Уничтожте полицию и удержите контроль"
		end

	elseif modeLower == "homicide" then
		local role = ply:GetNWString("HomicideRole", "citizen")
		local team = ply:GetNWString("HomigradTeam", "")
		if role == "traitor" then
			return "Убейте всех до приезда полиции"
		elseif role == "sheriff" then
			return "У вас есть огнестрельное оружие, устраните предателя"
		elseif team == "citizen" then
			return "Вычислите предателя или дождитесь приезда полиции"
		end
	elseif modeLower == "dm" then
		return "Убейте всех. Побеждает последний выживший"
	end

	return nil
end

-- Функция для проверки, нужно ли включать/выключать курсор
-- Возвращает true, если курсор должен быть включен
function Homigrad_ShouldEnableCursor()
    -- Если открыт scoreboard или меню выбора команды, курсор должен быть включен
    if (ScoreboardTargetAlpha or 0) > 0 or (TeamSelectMenuTargetAlpha or 0) > 0 then
        return true
    end
    -- Проверяем админ-меню
    if (AdminMenuTargetAlpha or 0) > 0 or (ModeListTargetAlpha or 0) > 0 then
        return true
    end
    return false
end
-- Переменные для ScoreBoard
local ScoreboardData = {}
local ScoreboardAlpha = 0
local ScoreboardTargetAlpha = 0
local ScoreboardFadeSpeed = 5
local PlayerAvatars = {} -- Кэш аватарок игроков
local LastMuteClick = 0 -- Защита от спама кликов
local ScoreboardScrollOffset = 0 -- Текущее смещение прокрутки списка игроков
local ScoreboardScrollTarget = 0 -- Целевое смещение прокрутки для плавной анимации
local ScoreboardScrollSpeed = 15 -- Скорость плавной прокрутки

-- Кастомизация: панель и модели
local CustomizationPanel = nil
local LastCustomizationClick = 0
local AllowedCustomizationModes = {
    jailbreak = true,
    dm = true,
    homicide = true
}
local CustomModels = {
    "models/mug/ncfom/anton_chigurh.mdl",
    "models/zenlesszonezero/Corin Wickes.mdl",
    "models/dark_donald.mdl",
    "models/kaneki_white/Kaneki_white.mdl",
    "models/mellstroy/mellstroy.mdl",
    "models/player/pissbaby.mdl",
    "models/lyn/lynplayermodel.mdl"
}
local SelectedCustomModel = ""

local function CloseCustomizationPanel()
    if IsValid(CustomizationPanel) then
        CustomizationPanel:Remove()
    end
    CustomizationPanel = nil
end

local function OpenCustomizationPanel(boardX, boardY, boardWidth, boardHeight)
    CloseCustomizationPanel()
    if not vgui or not vgui.Create then return end

    -- При открытии кастомизации всегда скрываем меню выбора команды
    TeamSelectMenuOpen = false
    TeamSelectMenuTargetAlpha = 0
    TeamSelectMenuAlpha = 0
    TeamSelectMenuCursorEnabled = false -- Флаг для отслеживания состояния курсора
    TeamButtonWasDown = false -- Для корректного определения единичного клика по кнопке команды

    local ply = LocalPlayer()
    local modeLower = string.lower(ply.HomigradSubmode or "")
    SelectedCustomModel = (IsValid(ply) and ply.GetNWString and ply:GetNWString("HG_CustomModel", "")) or ""
    -- Панель теперь открывается в любом режиме; ограничение функционала можно делать внутри вкладок при необходимости

    local root = vgui.Create("EditablePanel")
    root:SetSize(boardWidth, boardHeight)
    root:SetPos(boardX, boardY)
    root:SetMouseInputEnabled(true)
    root:SetKeyboardInputEnabled(true)
    if root.MakePopup then root:MakePopup() end
    if root.SetZPos then root:SetZPos(10000) end
    if gui and gui.EnableScreenClicker then gui.EnableScreenClicker(true) end
    root.Paint = function(_, w, h)
        surface.SetDrawColor(0, 0, 0, 180)
        surface.DrawRect(0, 0, w, h)
    end

    local sheet = vgui.Create("DPropertySheet", root)
    sheet:Dock(FILL)
    function sheet:Paint(w, h)
        surface.SetDrawColor(0, 0, 0, 180)
        surface.DrawRect(0, 0, w, h)
    end
    sheet:SetFadeTime(0)
    if IsValid(sheet.tabScroller) then
        function sheet.tabScroller:Paint(w, h)
            surface.SetDrawColor(0, 0, 0, 160)
            surface.DrawRect(0, 0, w, h)
        end
    end

    -- Вкладка 1: Модели
    local modelsScroll = vgui.Create("DScrollPanel", sheet)
    modelsScroll:Dock(FILL)

    -- Сетка карточек моделей
    local grid = vgui.Create("DIconLayout", modelsScroll)
    grid:Dock(FILL)
    grid:SetSpaceY(8)
    grid:SetSpaceX(8)

    local function setupModelCard(parent, mdlPath)
        local card = parent:Add("DPanel")
        card:SetSize(320, 480)
        function card:Paint(w, h)
            surface.SetDrawColor(30, 30, 30, 200)
            surface.DrawRect(0, 0, w, h)
            surface.SetDrawColor(100, 100, 100, 220)
            surface.DrawOutlinedRect(0, 0, w, h)
        end

        local m = card:Add("DModelPanel")
        m:Dock(FILL)
        m:DockMargin(8, 8, 8, 48)
        m:SetModel(mdlPath)
        m:SetFOV(36)
        function m:LayoutEntity(ent) ent:SetAngles(Angle(0, CurTime() * 10 % 360, 0)) end
        timer.Simple(0, function()
            if not IsValid(m) then return end
            local ent = m.Entity
            if not IsValid(ent) then return end
            local mn, mx = ent:GetRenderBounds()
            local sizeX = mx.x - mn.x
            local sizeY = mx.y - mn.y
            local sizeZ = mx.z - mn.z
            local size = math.max(sizeX, sizeY, sizeZ)
            local center = (mn + mx) * 0.5
            m:SetLookAt(center)
            local dist = size * 1.2
            m:SetCamPos(center + Vector(dist, dist * 0.25, dist * 0.9))
        end)

        local pick = card:Add("DButton")
        pick:Dock(BOTTOM)
        pick:DockMargin(8, 8, 8, 8)
        pick:SetTall(36)
        pick:SetText("ВЫБРАТЬ")
        pick:SetFont("CustomMenu")
        pick:SetTextColor(Color(255,255,255))
        local lastAppliedState = nil
        local function applyButtonState()
            local isSelected = (SelectedCustomModel ~= "" and SelectedCustomModel == mdlPath)
            if isSelected then
                pick:SetText("ВЫБРАНО")
                pick.Paint = function(_, w, h)
                    surface.SetDrawColor(120, 120, 120, 255)
                    surface.DrawRect(0, 0, w, h)
                    surface.SetDrawColor(80, 80, 80, 255)
                    surface.DrawOutlinedRect(0, 0, w, h)
                end
            else
                pick:SetText("ВЫБРАТЬ")
                pick.Paint = function(_, w, h)
                    surface.SetDrawColor(40, 150, 40, 255)
                    surface.DrawRect(0, 0, w, h)
                    surface.SetDrawColor(20, 100, 20, 255)
                    surface.DrawOutlinedRect(0, 0, w, h)
                end
            end
        end
        applyButtonState()

        function pick:Think()
            local current = SelectedCustomModel
            if lastAppliedState ~= current then
                lastAppliedState = current
                applyButtonState()
            end
        end
        pick.DoClick = function()
            if net and net.Start then
                net.Start("Homigrad_SetCustomPlayermodel")
                net.WriteString(mdlPath)
                net.SendToServer()
            end
            SelectedCustomModel = mdlPath
            surface.PlaySound("buttons/button9.wav")
        end
    end

    for _, mdl in ipairs(CustomModels) do
        setupModelCard(grid, mdl)
    end

    local tabModels = sheet:AddSheet("Модели", modelsScroll, nil, false, false, "Выбор модели")
    if tabModels and IsValid(tabModels.Tab) then
        function tabModels.Tab:Paint(w, h)
            local isActive = (sheet:GetActiveTab() == self)
            surface.SetDrawColor(0, 0, 0, isActive and 200 or 140)
            surface.DrawRect(0, 0, w, h)
            surface.SetDrawColor(166, 166, 166, 220)
            surface.DrawOutlinedRect(0, 0, w, h)
        end
    end

    -- Вкладка 2: В разработке
    local wip = vgui.Create("DPanel", sheet)
    wip:Dock(FILL)
    function wip:Paint(w, h)
        draw.SimpleText("В РАЗРАБОТКЕ", "DermaLarge", w/2, h/2, Color(255, 0, 0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    local tabOther = sheet:AddSheet("Другое", wip, nil, false, false, "В РАЗРАБОТКЕ")
    if tabOther and IsValid(tabOther.Tab) then
        function tabOther.Tab:Paint(w, h)
            local isActive = (sheet:GetActiveTab() == self)
            surface.SetDrawColor(0, 0, 0, isActive and 200 or 140)
            surface.DrawRect(0, 0, w, h)
            surface.SetDrawColor(166, 166, 166, 220)
            surface.DrawOutlinedRect(0, 0, w, h)
        end
    end

    CustomizationPanel = root
end

-- Переменные для меню выбора команды в JailBreak
local TeamSelectMenuOpen = false
local TeamSelectMenuAlpha = 0
local TeamSelectMenuTargetAlpha = 0
local TeamSelectMenuFadeSpeed = 8
local LastTeamSelectClick = 0
local TeamSelectMenuCursorEnabled = false -- Флаг для отслеживания состояния курсора
local TeamButtonWasDown = false -- Для корректного определения единичного клика по кнопке команды

-- Переменные для графика FPS
local FPSHistory = {}
local MaxFPSHistoryPoints = 60 -- Количество точек на графике
local SmoothFPSHistory = {} -- Сглаженные значения FPS для анимации
local LastFPSUpdate = 0 -- Время последнего обновления FPS
local FPSUpdateInterval = 10 -- Обновление каждые 10 секунд

-- Настройки плавного исчезновения для таймера полиции
-- PoliceTimerFadeSpeed: скорость исчезновения (1 = медленно, 3 = быстро)
-- Чем меньше значение, тем медленнее исчезает текст
local PoliceTimerAlpha = 0
local PoliceTimerTargetAlpha = 0
local PoliceTimerFadeSpeed = 0.3 -- Медленнее чем основной HUD

-- Настройки размера текста
-- Доступные шрифты: "DermaDefault", "DermaLarge", "HomigradLarge", "RiotWinner", "Trebuchet24", "CustomPoliceTimer", "CustomModeInfo"
-- Для изменения размера отредактируйте параметр 'size' в surface.CreateFont выше
local PoliceTimerFont = "CustomPoliceTimer" -- Шрифт для таймера полиции (размер: 28)
local ModeInfoFont = "CustomModeInfo" -- Шрифт для информации о режиме (размер: 16)

net.Receive("Homigrad_SubmodeUpdate", function()
    LocalPlayer().HomigradSubmode = net.ReadString()
    LocalPlayer().HomigradSecondsLeft = net.ReadInt(32)
end)

-- Получаем информацию о завершении раунда
net.Receive("Homigrad_RoundEnd", function()
    local success, err = pcall(function()
        RoundEndMode = net.ReadString()
        RoundEndWinner = net.ReadString()
        RoundEndTraitorNames = net.ReadString() or ""
        RoundEndTimer = CurTime() + 7 -- Показываем 7 секунд
        
        print("[Homigrad|Client] Received round end message:")
        print("[Homigrad|Client] Mode: " .. RoundEndMode)
        print("[Homigrad|Client] Winner: " .. RoundEndWinner)
        print("[Homigrad|Client] Timer set to: " .. RoundEndTimer)
    end)
    
    if not success then
        print("[Homigrad|Client] ERROR processing round end message: " .. tostring(err))
    end
end)

-- Получаем информацию о режиме наблюдателя
net.Receive("Homigrad_ObserverMode", function()
    IsObserverMode = net.ReadBool()
end)

-- Получаем состояние ожидания игроков (присылается сервером, когда игроков < MIN_PLAYERS)
net.Receive("Homigrad_WaitingForPlayers", function()
    WaitingForPlayers = net.ReadBool()
end)

-- Получаем информацию о времени приезда полиции
net.Receive("Homigrad_PoliceArrival", function()
    PoliceArrivalTime = net.ReadFloat()
end)

-- Получаем информацию о следующем режиме
net.Receive("Homigrad_NextMode", function()
    NextModeName = net.ReadString()
end)

-- Переменная для хранения состояния предупреждения об отсутствии охранников
local NoGuardsWarningTimer = 0

-- Получаем предупреждение об отсутствии охранников
net.Receive("Homigrad_NoGuardsWarning", function()
    NoGuardsWarningTimer = CurTime() + 2 -- Показываем 2 секунды
end)

-- Плавное затемнение экрана в начале каждого раунда
local RoundFadeStart = 0
local RoundFadeDuration = 7 -- секунд
local RoundFadeDelay = 3 -- сек. ожидания перед началом плавного исчезновения
local RoundFadeDelayCvar = CreateClientConVar("hg_roundfade_delay", "0", true, false, "Seconds to wait before starting round fade out", 0, 60)

-- Получаем сигнал о старте подрежима (раунда)
net.Receive("Homigrad_SubmodeStart", function()
    local name = net.ReadString()
    local duration = net.ReadInt(32) -- не используется здесь, но читаем для синхронизации

	-- Нормализуем отображаемое имя
	local lname = string.lower(name or "")
	if lname == "riot" then
		name = "RIOT"
	elseif lname == "homicide" then
		name = "HOMICIDE"
	elseif lname == "dm" then
		name = "DM"
	elseif lname == "jailbreak" then
		name = "JailBreak"
	end

    -- Сброс ожидания игроков при начале раунда
    WaitingForPlayers = false

	-- Устанавливаем текущий режим для клиента (используем оригинальное имя для проверки)
	local ply = LocalPlayer()
	if IsValid(ply) then
		ply.HomigradSubmode = name or ""
	end

	ModeStartName = name or ""
	ModeStartUntil = CurTime() + 5 -- показываем 5 секунд вверху по центру

	-- Запускаем общее экранное затемнение на старте раунда
	RoundFadeStart = CurTime()
	-- Фиксируем задержку из cvar на момент старта, чтобы не скакало во время эффекта
	RoundFadeDelay = math.max(0, RoundFadeDelayCvar:GetFloat() or 0)

	if lname == "homicide" then
		local snds = {
			"snd_jack_hmcd_psycho.mp3",
			"snd_jack_hmcd_disaster.mp3",
			"snd_jack_hmcd_shining.mp3"
		}
		surface.PlaySound(table.Random(snds))
	end

	-- Показать персональную задачу игрока снизу по центру
	local lname_for_objective = lname
	ObjectiveText = nil
	ObjectiveUntil = 0
	-- Небольшая задержка, чтобы успели установиться NWStrings роли/команды
	timer.Simple(0.1, function()
		local text = Homigrad_GenerateObjective(lname_for_objective)
		if text and text ~= "" then
			ObjectiveText = text
			ObjectiveUntil = CurTime() + 8
		end
	end)
end)

-- Предварительное объявление для функции загрузки аватаров, т.к. она используется ниже до определения
local LoadPlayerAvatar

-- Получаем данные ScoreBoard
net.Receive("Homigrad_ScoreboardData", function()
    ScoreboardData = net.ReadTable()
    
    -- Загружаем аватарки для новых игроков
    for _, playerData in ipairs(ScoreboardData) do
        if not PlayerAvatars[playerData.steamid] then
            PlayerAvatars[playerData.steamid] = {
                material = nil,
                loaded = false,
                loading = false
            }
        end
        if playerData.steamid then
            LoadPlayerAvatar(playerData.steamid)
        end
    end
end)

-- Отрисовка общего чёрного экрана с плавным исчезновением на старте раунда
hook.Add("HUDPaint", "Homigrad_RoundStartFade", function()
	if RoundFadeStart <= 0 then return end
	local dt = CurTime() - RoundFadeStart
	if dt < 0 then return end
	-- Полностью чёрный экран до наступления задержки
	if dt < RoundFadeDelay then
		draw.RoundedBox(0, 0, 0, ScrW(), ScrH(), Color(0, 0, 0, 255))
		return
	end
	-- Переходим к плавному исчезновению после задержки
	local fadeDt = dt - RoundFadeDelay
	if fadeDt > RoundFadeDuration then return end

	-- Квадратичная кривая для более мягкого начала
	local t = math.Clamp(fadeDt / RoundFadeDuration, 0, 1)
	local alpha = math.floor(255 * (1 - t) * (1 - t))

	draw.RoundedBox(0, 0, 0, ScrW(), ScrH(), Color(0, 0, 0, alpha))
end)

-- Функция для загрузки аватарки игрока
LoadPlayerAvatar = function(steamid)
    if PlayerAvatars[steamid] and PlayerAvatars[steamid].loading then return end
    if PlayerAvatars[steamid] and PlayerAvatars[steamid].loaded then return end

    PlayerAvatars[steamid] = PlayerAvatars[steamid] or {}
    PlayerAvatars[steamid].loading = true
    PlayerAvatars[steamid].retry = (PlayerAvatars[steamid].retry or 0)

    -- Пытаемся найти локальный Player и взять его SteamID64 напрямую (надежнее)
    local steamid64 = nil
    for _, p in ipairs(player.GetAll()) do
        if IsValid(p) and p:SteamID() == steamid then
            steamid64 = p:SteamID64()
            break
        end
    end
    -- Фолбэк конвертации, если игрок не найден по сущности
    steamid64 = steamid64 or util.SteamIDTo64(steamid)
    if not steamid64 or steamid64 == "0" then
        -- Не-стим игрок (бот) или конвертация не удалась
        PlayerAvatars[steamid].material = Material("icon16/user.png", "noclamp smooth")
        PlayerAvatars[steamid].loaded = true
        PlayerAvatars[steamid].loading = false
        return
    end

    -- Гарантируем, что скрытая AvatarImage создана заранее, чтобы можно было рисовать live даже до готового материала
    if vgui and vgui.Create then
        if not IsValid(PlayerAvatars[steamid].panel) then
            local pnl = vgui.Create("AvatarImage")
            pnl:SetSize(64, 64)
            pnl:SetVisible(true)
            if pnl.SetPaintedManually then pnl:SetPaintedManually(true) end
            if pnl.SetAlpha then pnl:SetAlpha(255) end
            pnl:SetMouseInputEnabled(false)
            pnl:SetKeyboardInputEnabled(false)
            if pnl.SetPos then pnl:SetPos(-2000, -2000) end
            local ent = nil
            for _, ep in ipairs(player.GetAll()) do
                if IsValid(ep) and ep:SteamID() == steamid then ent = ep break end
            end
            if IsValid(ent) and pnl.SetPlayer then
                pnl:SetPlayer(ent, 64)
            else
                pnl:SetSteamID(steamid64, 64)
            end
            -- Панель сама будет обновляться вне экрана, материал появится в GetMaterial()
            PlayerAvatars[steamid].panel = pnl
        end
    end

    -- Сначала пробуем через steamworks (самый надёжный способ получить иконку профиля)
    if steamworks and steamworks.RequestPlayerInfo and steamworks.GetPlayerIcon then
        steamworks.RequestPlayerInfo(steamid64, function()
            if not PlayerAvatars[steamid] then return end
            local icon = steamworks.GetPlayerIcon(steamid64)
            if icon and not icon:IsError() then
                PlayerAvatars[steamid].material = icon
                PlayerAvatars[steamid].loaded = true
                PlayerAvatars[steamid].loading = false
                return
            end

            -- Если иконка пока не готова, немного подождём и повторим, ограничив кол-во попыток
            if PlayerAvatars[steamid].retry < 5 then
                PlayerAvatars[steamid].retry = PlayerAvatars[steamid].retry + 1
                timer.Simple(0.5, function()
                    if not PlayerAvatars[steamid] or PlayerAvatars[steamid].loaded then return end
                    LoadPlayerAvatar(steamid)
                end)
                return
            end

            -- Фолбэк на AvatarImage ниже
            PlayerAvatars[steamid].retry = 0

            -- Продолжаем к фолбэку
            if vgui and vgui.Create then
                -- Создаем скрытую панель только один раз на игрока
                if not IsValid(PlayerAvatars[steamid].panel) then
                    local pnl = vgui.Create("AvatarImage")
                    pnl:SetSize(64, 64)
                    pnl:SetVisible(true)
                    if pnl.SetPaintedManually then pnl:SetPaintedManually(true) end
                    if pnl.SetAlpha then pnl:SetAlpha(255) end
                    pnl:SetMouseInputEnabled(false)
                    pnl:SetKeyboardInputEnabled(false)
                    if pnl.SetPos then pnl:SetPos(-2000, -2000) end
                    -- Если есть валидная сущность игрока - используем SetPlayer, иначе SetSteamID
                    local ent = nil
                    for _, ep in ipairs(player.GetAll()) do
                        if IsValid(ep) and ep:SteamID() == steamid then ent = ep break end
                    end
                    if IsValid(ent) and pnl.SetPlayer then
                        pnl:SetPlayer(ent, 64)
                    else
                        pnl:SetSteamID(steamid64, 64)
                    end
                    -- Материал инициализируется автоматически
                    PlayerAvatars[steamid].panel = pnl
                end

                timer.Simple(0, function()
                    if not PlayerAvatars[steamid] then return end
                    local pnl = PlayerAvatars[steamid].panel
                    local mat = IsValid(pnl) and pnl.GetMaterial and pnl:GetMaterial() or nil
                    if mat and not mat:IsError() then
                        PlayerAvatars[steamid].material = mat
                        PlayerAvatars[steamid].loaded = true
                        PlayerAvatars[steamid].loading = false
                        return
                    end

                    -- Последняя попытка чуть позже
                    timer.Simple(0.3, function()
                        if not PlayerAvatars[steamid] then return end
                        local pnl2 = PlayerAvatars[steamid].panel
                        local mat2 = IsValid(pnl2) and pnl2.GetMaterial and pnl2:GetMaterial() or nil
                        if mat2 and not mat2:IsError() then
                            PlayerAvatars[steamid].material = mat2
                            PlayerAvatars[steamid].loaded = true
                            PlayerAvatars[steamid].loading = false
                            return
                        end
                        -- Не удалось мгновенно получить материал — отпускаем загрузку, попробуем позже
                        PlayerAvatars[steamid].loading = false
                    end)
                end)
                return
            end

            -- Если vgui недоступен
            PlayerAvatars[steamid].material = Material("icon16/user.png", "noclamp smooth")
            PlayerAvatars[steamid].loaded = true
            PlayerAvatars[steamid].loading = false
        end)
        return
    end

    -- Фолбэк: получаем через скрытую AvatarImage, если steamworks недоступен
    if not vgui or not vgui.Create then
        PlayerAvatars[steamid].material = Material("icon16/user.png", "noclamp smooth")
        PlayerAvatars[steamid].loaded = true
        PlayerAvatars[steamid].loading = false
        return
    end

    if not IsValid(PlayerAvatars[steamid].panel) then
        local pnl = vgui.Create("AvatarImage")
        pnl:SetSize(64, 64)
        pnl:SetVisible(true)
        if pnl.SetPaintedManually then pnl:SetPaintedManually(true) end
        if pnl.SetAlpha then pnl:SetAlpha(255) end
        pnl:SetMouseInputEnabled(false)
        pnl:SetKeyboardInputEnabled(false)
        if pnl.SetPos then pnl:SetPos(-2000, -2000) end
        local ent = nil
        for _, ep in ipairs(player.GetAll()) do
            if IsValid(ep) and ep:SteamID() == steamid then ent = ep break end
        end
        if IsValid(ent) and pnl.SetPlayer then
            pnl:SetPlayer(ent, 64)
        else
            pnl:SetSteamID(steamid64, 64)
        end
        -- Панель обновляется сама вне экрана
        PlayerAvatars[steamid].panel = pnl
    end

    timer.Simple(0, function()
        if not PlayerAvatars[steamid] then return end
        local pnl = PlayerAvatars[steamid].panel
        local mat = IsValid(pnl) and pnl.GetMaterial and pnl:GetMaterial() or nil
        if mat and not mat:IsError() then
            PlayerAvatars[steamid].material = mat
            PlayerAvatars[steamid].loaded = true
            PlayerAvatars[steamid].loading = false
            return
        end

        timer.Simple(0.2, function()
            if not PlayerAvatars[steamid] then return end
            local pnl2 = PlayerAvatars[steamid].panel
            if IsValid(pnl2) and pnl2.PaintAt then
                pnl2:PaintAt(-10000, -10000, 2, 2)
            end
            local mat2 = IsValid(pnl2) and pnl2.GetMaterial and pnl2:GetMaterial() or nil
            if mat2 and not mat2:IsError() then
                PlayerAvatars[steamid].material = mat2
                PlayerAvatars[steamid].loaded = true
                PlayerAvatars[steamid].loading = false
                return
            end
            -- Оставляем без финального фолбэка: повторим попытку при следующем рендере
            PlayerAvatars[steamid].loading = false
        end)
    end)
end

-- Обработчик нажатия клавиши Tab
hook.Add("PlayerBindPress", "Homigrad_TabHud", function(ply, bind, pressed)
    if ply ~= LocalPlayer() then return end
    
    if bind == "+showscores" then
        if pressed then
            TabHudTargetAlpha = 1
            PoliceTimerTargetAlpha = 1
            ScoreboardTargetAlpha = 1
            -- Показываем курсор при открытии ScoreBoard
            gui.EnableScreenClicker(true)
            -- Сбрасываем смещение прокрутки при открытии
            ScoreboardScrollOffset = 0
            ScoreboardScrollTarget = 0
            -- Запрашиваем актуальные данные ScoreBoard
            net.Start("Homigrad_ScoreboardData")
            net.SendToServer()
        else
            TabHudTargetAlpha = 0
            PoliceTimerTargetAlpha = 0
            ScoreboardTargetAlpha = 0
            -- Закрываем меню выбора команды при отпускании TAB
            TeamSelectMenuOpen = false
            TeamSelectMenuTargetAlpha = 0
            -- Закрываем панель кастомизации при отпускании TAB и отключаем курсор
            CloseCustomizationPanel()
            gui.EnableScreenClicker(false)
            -- Сбрасываем смещение прокрутки при закрытии
            ScoreboardScrollOffset = 0
            ScoreboardScrollTarget = 0
        end
        return true -- Блокируем стандартное поведение Tab
    end
end)

-- Обновление альфа-канала для плавного появления/исчезновения
hook.Add("Think", "Homigrad_TabHudFade", function()
    local diff = TabHudTargetAlpha - TabHudAlpha
    TabHudAlpha = TabHudAlpha + diff * FrameTime() * TabHudFadeSpeed
    
    -- Отдельная логика для таймера полиции с более медленным исчезновением
    local policeDiff = PoliceTimerTargetAlpha - PoliceTimerAlpha
    PoliceTimerAlpha = PoliceTimerAlpha + policeDiff * FrameTime() * PoliceTimerFadeSpeed
    
    -- Обновление альфа-канала для ScoreBoard
    local scoreboardDiff = ScoreboardTargetAlpha - ScoreboardAlpha
    ScoreboardAlpha = ScoreboardAlpha + scoreboardDiff * FrameTime() * ScoreboardFadeSpeed
    
    -- Плавная анимация прокрутки ScoreBoard
    local scrollDiff = ScoreboardScrollTarget - ScoreboardScrollOffset
    ScoreboardScrollOffset = ScoreboardScrollOffset + scrollDiff * FrameTime() * ScoreboardScrollSpeed
    
    -- Плавное появление/исчезновение меню выбора команды
    local menuDiff = TeamSelectMenuTargetAlpha - TeamSelectMenuAlpha
    TeamSelectMenuAlpha = TeamSelectMenuAlpha + menuDiff * FrameTime() * TeamSelectMenuFadeSpeed
    
    -- Сбор данных FPS для графика (обновление каждые 10 секунд)
    if (CurTime() - LastFPSUpdate) >= FPSUpdateInterval then
        local fps = math.floor(1 / FrameTime())
        table.insert(FPSHistory, fps)
        
        -- Ограничиваем историю
        if #FPSHistory > MaxFPSHistoryPoints then
            table.remove(FPSHistory, 1)
        end
        
        LastFPSUpdate = CurTime()
    end
    
    -- Сглаживаем данные FPS для анимации
    while #SmoothFPSHistory < #FPSHistory do
        table.insert(SmoothFPSHistory, FPSHistory[#SmoothFPSHistory + 1] or 0)
    end
    
    -- Применяем сглаживание к значениям графика (плавная анимация)
    for i = 1, #FPSHistory do
        local diff = FPSHistory[i] - SmoothFPSHistory[i]
        SmoothFPSHistory[i] = SmoothFPSHistory[i] + diff * FrameTime() * 10 -- Скорость сглаживания
    end
end)

-- Убираем постоянное отображение - теперь все появляется только при нажатии Tab

-- Отображение сообщения о необходимости минимум 2 игроков
hook.Add("HUDPaint", "Homigrad_ObserverMessage", function()
    return
end)


-- Удаляем старый, не работавший хук
hook.Remove("KeyPress", "Homigrad_SpectatorSwitch")

--[[
    ИСПРАВЛЕНО: Смена режима наблюдения
    Используем 'PlayerBindPress' вместо 'KeyPress', т.к. 'reload' - это игровой бинд.
]]
hook.Add("PlayerBindPress", "Homigrad_SpectatorSwitch", function(ply, bind, pressed)
    -- Срабатываем только на 'нажатие' (pressed = true)
    if not pressed then return end
    
    -- Проверяем, что это локальный игрок
    if (ply ~= LocalPlayer()) then return end
    
    -- Получаем локального игрока и проверяем его валидность
    local localPly = LocalPlayer()
    if not IsValid(localPly) then return end
    
    -- Проверяем, что нажали 'reload' (R)
    if (bind ~= "+reload" and bind ~= "reload") then return end
    
    -- Проверяем, что игрок мертв и является наблюдателем
    if localPly:Alive() then return end
    
    -- Проверяем, что игрок действительно находится в режиме наблюдения
    local obsMode = localPly:GetObserverMode()
    if not obsMode or obsMode == OBS_MODE_NONE then return end
    
    -- Отладочная информация о бинде
    print("[Spectator] Bind pressed: " .. tostring(bind))
    print("[Spectator] Observer mode: " .. tostring(obsMode))
    print("[Spectator] Switching spectator mode...")
    
    -- Отправляем запрос на сервер для смены режима наблюдения
    -- Сервер выполнит все вычисления и команды Spectate/SpectateEntity
    net.Start("Homigrad_SpectatorSwitch")
    net.SendToServer()
    
    -- Мы обработали нажатие, не передаем его дальше
    return true 
end)

hook.Add("PlayerBindPress", "Homigrad_BlockContextMenuForNonAdmins", function(ply, bind, pressed)
    if ply ~= LocalPlayer() then return end
    if bind == "+menu_context" then
        if not (ply:IsAdmin() or ply:IsSuperAdmin()) then
            return true
        end
    end
end)

-- Отключаем стандартный TargetID полностью
hook.Add("HUDDrawTargetID", "Homigrad_DisableDefaultTargetID", function()
    return false
end)

-- Отображение ника смотримого игрока только вблизи (< ~1 метр) с плавным затуханием
hook.Add("HUDPaint", "Homigrad_CloseNameTargetID", function()
    local ply = LocalPlayer()
    if not IsValid(ply) then return end
    if not ply:Alive() then return end
    if ply:GetObserverMode() ~= OBS_MODE_NONE then return end
	if not IsValid(ply) then return end
	if not ply:Alive() then return end
	if ply:GetObserverMode() ~= OBS_MODE_NONE then return end

	local tr = ply:GetEyeTrace()
	if not tr or not tr.Hit then return end

	local ent = tr.Entity
	if not IsValid(ent) or not ent:IsPlayer() or ent == ply then return end

	-- Source: 1 unit ≈ 1 inch, 1 meter ≈ 39.37 units → используем 40
	local maxDistanceUnits = 80
	local minDistanceUnits = 60 -- На этом расстоянии начинается затухание
	
	local distance = ply:GetPos():Distance(ent:GetPos())
	if distance >= maxDistanceUnits then return end

	-- Вычисляем альфа-канал на основе расстояния с плавным затуханием
	local alpha = 255
	if distance > minDistanceUnits then
		-- Плавное затухание от minDistanceUnits до maxDistanceUnits
		local fadeRange = maxDistanceUnits - minDistanceUnits
		local fadeDistance = distance - minDistanceUnits
		local fadePercent = 1 - (fadeDistance / fadeRange) -- От 1 (полная видимость) до 0 (полная прозрачность)
		alpha = math.Clamp(fadePercent * 255, 0, 255)
	end

	-- Рисуем белым цветом у прицела с плавным затуханием
	draw.SimpleText(ent:Nick(), "HomigradLarge", ScrW() / 2, ScrH() / 2 + 30, Color(255, 255, 255, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end)

-- Белый кружок-"прицел" при приближении к стене, с плавным появлением/затуханием
hook.Add("HUDPaint", "Homigrad_CloseWallDot", function()
	local ply = LocalPlayer()
	if not IsValid(ply) then return end
	if not ply:Alive() then return end
	if ply:GetObserverMode() ~= OBS_MODE_NONE then return end

	local eyePos = ply:EyePos()
	local forward = ply:EyeAngles():Forward()
	local maxDistanceUnits = 60 -- ~1 метр

	local tr = util.TraceLine({
		start = eyePos,
		endpos = eyePos + forward * maxDistanceUnits,
		filter = ply,
		mask = MASK_SOLID
	})

	if not tr.Hit then return end

	-- Расстояние до препятствия (0..maxDistanceUnits)
	local hitDistance = eyePos:Distance(tr.HitPos)
	if hitDistance > maxDistanceUnits then return end

	-- Альфа от 0 (далеко) до 255 (вплотную)
	local alpha = math.Clamp((1 - (hitDistance / maxDistanceUnits)) * 255, 0, 255)
	if alpha <= 0 then return end

	local cx, cy = ScrW() / 2, ScrH() / 2
	local radius = 3
	local segments = 16

	-- Рисуем заполненный кружок треугольниками
	draw.NoTexture()
	surface.SetDrawColor(255, 255, 255, alpha)
	for i = 0, segments - 1 do
		local a1 = (i / segments) * math.pi * 2
		local a2 = ((i + 1) / segments) * math.pi * 2
		local tri = {
			{ x = cx, y = cy },
			{ x = cx + math.cos(a1) * radius, y = cy + math.sin(a1) * radius },
			{ x = cx + math.cos(a2) * radius, y = cy + math.sin(a2) * radius }
		}
		surface.DrawPoly(tri)
	end
end)

-- Отображение информации о цели наблюдения
hook.Add("HUDPaint", "Homigrad_SpectatorInfo", function()
    local ply = LocalPlayer()
    if not IsValid(ply) then return end
    
    -- Проверяем, что игрок мертв и находится в режиме наблюдения
    if ply:Alive() then return end
    
    local obsMode = ply:GetObserverMode()
    if not obsMode or obsMode == OBS_MODE_NONE or obsMode == OBS_MODE_ROAMING then return end
    
    -- Получаем цель наблюдения
    local target = ply:GetObserverTarget()
    if not IsValid(target) or not target:IsPlayer() then return end
    
    -- Отображаем текст внизу по центру экрана
    local text = "Наблюдение за: " .. target:Nick()
    local textY = ScrH() - 80
    local centerX = ScrW() / 2
    
    -- Полупрозрачный фон для текста
    local textWidth = 400
    local textHeight = 40
    draw.RoundedBox(8, centerX - textWidth/2, textY - textHeight/2, textWidth, textHeight, Color(0, 0, 0, 150))
    
    -- Рамка
    surface.SetDrawColor(255, 255, 255, 100)
    surface.DrawOutlinedRect(centerX - textWidth/2, textY - textHeight/2, textWidth, textHeight)
    
    -- Текст с именем игрока
    draw.SimpleText(text, "HomigradLarge", centerX, textY, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end)

-- Переключение между игроками при наблюдении
hook.Add("PlayerButtonDown", "Homigrad_SpectatorPlayerSwitch", function(ply, button)
    if ply ~= LocalPlayer() then return end
    
    local localPly = LocalPlayer()
    if not IsValid(localPly) then return end
    
    -- Проверяем, что игрок мертв и находится в режиме наблюдения
    if localPly:Alive() then return end
    
    local obsMode = localPly:GetObserverMode()
    if not obsMode or obsMode == OBS_MODE_NONE or obsMode == OBS_MODE_ROAMING then return end
    
    -- Проверяем нажатие ЛКМ или ПКМ
    local direction = nil
    if button == MOUSE_LEFT then
        direction = -1 -- Предыдущий игрок
    elseif button == MOUSE_RIGHT then
        direction = 1 -- Следующий игрок
    else
        return
    end
    
    -- Получаем список живых игроков
    local alivePlayers = {}
    for _, p in ipairs(player.GetAll()) do
        if p:Alive() and p ~= localPly then
            table.insert(alivePlayers, p)
        end
    end
    
    if #alivePlayers == 0 then return end
    
    -- Получаем текущую цель
    local currentTarget = localPly:GetObserverTarget()
    local currentIndex = 1
    
    -- Находим индекс текущей цели
    if IsValid(currentTarget) and currentTarget:IsPlayer() then
        for i, p in ipairs(alivePlayers) do
            if p == currentTarget then
                currentIndex = i
                break
            end
        end
    end
    
    -- Вычисляем индекс следующей цели
    local nextIndex = currentIndex + direction
    if nextIndex < 1 then
        nextIndex = #alivePlayers
    elseif nextIndex > #alivePlayers then
        nextIndex = 1
    end
    
    -- Отправляем запрос на сервер
    net.Start("Homigrad_SpectatorPlayerSwitch")
        net.WriteEntity(alivePlayers[nextIndex])
    net.SendToServer()
    
    print("[Spectator] Switching to: " .. alivePlayers[nextIndex]:Nick())
end)

-- Отображение затемнения экрана в начале раунда
hook.Add("HUDPaint", "Homigrad_SpawnScreen", function()
    local ply = LocalPlayer()
    if not IsValid(ply) then return end
    
    local spawnTime = ply:GetNWFloat("SpawnTime", 0)
    if spawnTime == 0 then return end
    
	local timeSinceSpawn = CurTime() - spawnTime
	local fadeDuration = 7 -- длительность затемнения
	if timeSinceSpawn > fadeDuration then return end -- показываем только время затухания
    
    local teamDisplay = ply:GetNWString("CurrentTeamDisplay", "")
    if teamDisplay == "" then return end
    
	-- Определяем цвет текста команды (будет затухать вместе с фоном)
	local teamColor = Color(255, 255, 255, 255)
	if teamDisplay == "Бунтующие" then
		teamColor = Color(255, 100, 10, 255)
	elseif teamDisplay == "Полиция" then
		teamColor = Color(16, 0, 255, 255)
	elseif teamDisplay == "Спецназ" then
		teamColor = Color(0, 185, 255, 255)
	elseif teamDisplay == "Террористы" then
		teamColor = Color(255, 0, 0, 255)
	elseif teamDisplay == "Жертвы" then
		teamColor = Color(0, 255, 29, 255)
	elseif teamDisplay == "Стрелки" then
		teamColor = Color(255, 0, 0, 255)
	elseif teamDisplay == "Охранник" then
		teamColor = Color(16, 0, 255, 255)
	elseif teamDisplay == "Заключённый" then
		teamColor = Color(255, 100, 10, 255)
	elseif teamDisplay == "Предатель" then
		teamColor = Color(255, 0, 0, 255)
	elseif teamDisplay == "Вооружённый" then
		teamColor = Color(161, 0, 255, 255)
	elseif teamDisplay == "Невиновный" then
		teamColor = Color(0, 185, 255, 255)
	elseif teamDisplay == "Боец" then
		teamColor = Color(255, 0, 0, 255)
	elseif teamDisplay == "Ивент" then
		teamColor = Color(242, 0, 255, 255)
	elseif teamDisplay == "Админ" then
		teamColor = Color(255, 0, 0, 255)
	end

	-- Полностью чёрный фон с быстрым затуханием
	local t = math.Clamp(timeSinceSpawn / fadeDuration, 0, 1)
	-- плавное затухание (квадратичная кривая)
	local alpha = math.floor(255 * (1 - t) * (1 - t))
	teamColor.a = alpha
    
	-- Рисуем полностью чёрное затемнение
	draw.RoundedBox(0, 0, 0, ScrW(), ScrH(), Color(0, 0, 0, alpha))
    
    -- Рисуем большой текст с командой
    local x = ScrW() / 2
    local y = ScrH() / 2 - 30
    
    draw.SimpleText("Вы:", "DermaLarge", x, y - 40, Color(255, 255, 255, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    draw.SimpleText(teamDisplay, "RiotWinner", x, y + 20, teamColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end)

-- Отображение названия режима в начале раунда (сверху по центру)
hook.Add("HUDPaint", "Homigrad_ModeStartTitle", function()
	if not ModeStartName or ModeStartName == "" then return end
	if CurTime() > ModeStartUntil then return end

	local x = ScrW() / 2
	local y = 30

	-- Плавное угасание к концу интервала
	local remain = math.max(0, ModeStartUntil - CurTime())
	local alpha = 255
	if remain < 1.0 then
		alpha = math.floor(remain * 255)
	end

	local textColor = Color(255, 215, 0, alpha)
	-- Тень
	draw.SimpleText(ModeStartName, "RiotWinner", x + 2, y + 2, Color(0, 0, 0, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	-- Основной текст
	draw.SimpleText(ModeStartName, "RiotWinner", x, y, textColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end)

-- Отображение задачи игрока в начале раунда (снизу по центру)
hook.Add("HUDPaint", "Homigrad_ModeStartObjective", function()
	if not ObjectiveText or ObjectiveText == "" then return end
	if CurTime() > ObjectiveUntil then return end

	local w, h = ScrW(), ScrH()
	local centerX = w / 2
	local textY = h - 90

	-- Плавное угасание за последнюю секунду
	local remain = math.max(0, ObjectiveUntil - CurTime())
	local alpha = 255
	if remain < 1.0 then
		alpha = math.floor(remain * 255)
	end

	surface.SetFont("DermaLarge")
	local tw, th = surface.GetTextSize(ObjectiveText)
	local padX, padY = 30, 14
	local boxW = math.max(420, tw + padX * 2)
	local boxH = th + padY * 2

	-- Фон
	draw.RoundedBox(8, centerX - boxW / 2, textY - boxH / 2, boxW, boxH, Color(0, 0, 0, math.floor(alpha * 0.7)))
	-- Рамка
	surface.SetDrawColor(255, 255, 255, math.floor(alpha * 0.5))
	surface.DrawOutlinedRect(centerX - boxW / 2, textY - boxH / 2, boxW, boxH)
	-- Текст
	draw.SimpleText(ObjectiveText, "DermaLarge", centerX, textY, Color(255, 255, 255, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end)

-- Отображение информации при зажатии Tab
hook.Add("HUDPaint", "Homigrad_TabHud", function()
    if TabHudAlpha <= 0 then return end
    
    local ply = LocalPlayer()
    if not IsValid(ply) or not ply.HomigradSubmode then return end
    
    local alpha = math.floor(TabHudAlpha * 255)
    local textColor = Color(255, 255, 255, alpha)
    local yellowColor = Color(255, 215, 0, alpha)
    
    -- Информация о режиме в левом верхнем углу
    local currentModeName = ply.HomigradSubmode
    if currentModeName == "Riot" then
        currentModeName = "RIOT"
    elseif currentModeName == "Homicide" then
        currentModeName = "HOMICIDE"
    end
    
    local nextModeName = NextModeName
    -- Нормализуем любые варианты регистра ("Riot"/"riot")
    local lname = string.lower(nextModeName or "")
    if lname == "riot" then
        nextModeName = "RIOT"
    elseif lname == "homicide" then
        nextModeName = "HOMICIDE"
    end
    
    local timeLeft = ply.HomigradSecondsLeft or 0
    local minutes = math.floor(timeLeft / 60)
    local seconds = math.floor(timeLeft % 60)
    local timeText
    if string.lower(ply.HomigradSubmode or "") == "event" then
        timeText = "∞"
    else
        timeText = string.format("%02d:%02d", minutes, seconds)
    end
    
    -- Отображение информации о режимах
    draw.SimpleText("Режим: " .. currentModeName, ModeInfoFont, 10, 10, yellowColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
    draw.SimpleText("Следующий режим: " .. nextModeName, ModeInfoFont, 10, 35, textColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
    draw.SimpleText("Время до конца режима: " .. timeText, ModeInfoFont, 10, 60, textColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
    
    -- Таймер до приезда полиции в центре экрана снизу (только для Homicide)
    if ply.HomigradSubmode == "Homicide" and PoliceArrivalTime > 0 then
        local policeTimeLeft = PoliceArrivalTime - CurTime()
        if policeTimeLeft > 0 then
            local policeMinutes = math.floor(policeTimeLeft / 60)
            local policeSeconds = math.floor(policeTimeLeft % 60)
            local policeText = string.format("Полиция приедет через: %02d:%02d", policeMinutes, policeSeconds)
            
            local centerX = ScrW() / 2
            local bottomY = ScrH() - 50
            
            -- Используем отдельный альфа-канал для более медленного исчезновения
            local policeAlpha = math.floor(PoliceTimerAlpha * 255)
            local policeTextColor = Color(255, 255, 255, policeAlpha)
            
            -- Простой белый текст без фона и рамок (настраиваемый размер)
            draw.SimpleText(policeText, PoliceTimerFont, centerX, bottomY, policeTextColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
    end
end)

-- Отображение прямоугольника с победителем для всех режимов
hook.Add("HUDPaint", "Homigrad_RoundEndDisplay", function()
    -- Проверяем, что переменные инициализированы
    if not RoundEndTimer or RoundEndTimer == 0 then return end
    if not RoundEndMode or RoundEndMode == "" then return end
    if not RoundEndWinner or RoundEndWinner == "" then return end
    
    if CurTime() >= RoundEndTimer then return end
    
    local remainingTime = RoundEndTimer - CurTime()
    if remainingTime <= 0 then return end
    
    -- Отладочная информация (только для первых 2 секунд)
    if remainingTime > 5 then
        print("[Homigrad|Client] Drawing round end display - Mode: " .. RoundEndMode .. ", Winner: " .. RoundEndWinner .. ", Time left: " .. math.floor(remainingTime))
    end
    
    -- Параметры прямоугольника
    local w, h = ScrW(), ScrH()
    local rectWidth = 600
    local rectHeight = 150
    local rectX = (w - rectWidth) / 2
    local rectY = 100
    
    -- Определяем цвет фона и текст в зависимости от режима и победителя
    local bgColor = Color(40, 40, 40, 230)
    local textColor = Color(255, 255, 255, 255)
    local titleText = ""
    local winnerText = ""
    
	if RoundEndMode == "riot" then
        titleText = "RIOT ЗАВЕРШЕН"
        
        if RoundEndWinner == "Бунтующие" then
            bgColor = Color(180, 20, 20, 250) -- Ярко-красный для бунтующих
            winnerText = "БУНТУЮЩИЕ ВЫИГРАЛИ!"
            textColor = Color(255, 200, 200, 255) -- Светло-красный текст
        elseif RoundEndWinner == "Полиция" then
            bgColor = Color(20, 40, 180, 250) -- Темно-синий для полиции
            winnerText = "ПОЛИЦИЯ ВЫИГРАЛА!"
            textColor = Color(200, 200, 255, 255) -- Светло-синий текст
        else
            bgColor = Color(60, 60, 60, 240) -- Серый для ничьи
            winnerText = "НИЧЬЯ!"
            textColor = Color(200, 200, 200, 255) -- Серый текст
        end
		
	elseif RoundEndMode == "dm" then
		titleText = "DM ЗАВЕРШЕН"
		bgColor = Color(255, 215, 0, 240) -- Жёлтый фон
		textColor = Color(30, 30, 30, 255) -- Тёмный текст для контраста
		if RoundEndWinner == "Ничья" then
			winnerText = "НИЧЬЯ"
		elseif RoundEndWinner == "Никто" then
			winnerText = "Победителя нет"
		else
			winnerText = "Победил: " .. RoundEndWinner
		end

    elseif RoundEndMode == "homicide" then
        titleText = "HOMICIDE ЗАВЕРШЕН"
        
        if RoundEndWinner == "Предатель" then
            bgColor = Color(200, 40, 40, 240) -- Красный для предателя
            winnerText = "Предатель выиграл!"
        else
            bgColor = Color(40, 200, 40, 240) -- Зеленый для мирных
            winnerText = "Мирные жители выиграли!"
        end
    else
        -- Неизвестный режим или завершено администратором
        titleText = "РАУНД ЗАВЕРШЕН"
        bgColor = Color(60, 60, 60, 240) -- Серый для неизвестного
        textColor = Color(255, 255, 255, 255) -- Белый текст
        if RoundEndWinner == "Ничья" then
            winnerText = "Завершено администратором"
        else
            winnerText = RoundEndWinner or "Завершено администратором"
        end
    end
    
    -- Рисуем прямоугольник
    draw.RoundedBox(8, rectX, rectY, rectWidth, rectHeight, bgColor)
    
    -- Рамка (цвет зависит от команды)
	local borderColor = Color(255, 255, 255, 150)
    if RoundEndMode == "riot" then
        if RoundEndWinner == "Бунтующие" then
            borderColor = Color(255, 100, 100, 200) -- Красная рамка
        elseif RoundEndWinner == "Полиция" then
            borderColor = Color(100, 150, 255, 200) -- Синяя рамка
        else
            borderColor = Color(200, 200, 200, 150) -- Серая рамка
        end
	elseif RoundEndMode == "dm" then
		borderColor = Color(255, 200, 0, 220) -- Жёлтая рамка для DM
    end
    surface.SetDrawColor(borderColor)
    surface.DrawOutlinedRect(rectX, rectY, rectWidth, rectHeight)
    
    -- Дополнительная внутренняя рамка для эффекта
    surface.SetDrawColor(borderColor.r, borderColor.g, borderColor.b, 80)
    surface.DrawOutlinedRect(rectX + 2, rectY + 2, rectWidth - 4, rectHeight - 4)
    
    -- Заголовок с эффектом пульсации
    local pulseAlpha = math.sin(CurTime() * 4) * 0.3 + 0.7 -- Пульсация от 0.4 до 1.0
    local titleColor = Color(255, 215, 0, 255 * pulseAlpha)
    draw.SimpleText(titleText, "RiotWinner", rectX + rectWidth / 2, rectY + 20, titleColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
    
    -- Текст победителя
    draw.SimpleText(winnerText, "DermaLarge", rectX + rectWidth / 2, rectY + 70, textColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
    
    -- Дополнительная информация для Homicide (имя трейтора)
    if RoundEndMode == "homicide" and RoundEndTraitorNames ~= "" then
        draw.SimpleText("Предателем был: " .. RoundEndTraitorNames, "HomigradLarge", rectX + rectWidth / 2, rectY + 110, Color(255, 200, 0, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
    end
end)

-- Функция для мута игрока
local function MutePlayer(steamid, muteAction)
    net.Start("Homigrad_MutePlayer")
        net.WriteString(steamid)
        net.WriteBool(muteAction)
    net.SendToServer()
end

-- Отображение ScoreBoard
-- Отображение предупреждения об отсутствии охранников
hook.Add("HUDPaint", "Homigrad_NoGuardsWarning", function()
    -- Проверяем, нужно ли показывать предупреждение
    local shouldShow = false
    
    -- Если таймер активен (получено сетевое сообщение), показываем
    if NoGuardsWarningTimer and CurTime() < NoGuardsWarningTimer then
        shouldShow = true
    end
    
    -- Также проверяем локально для режима JailBreak
    if not shouldShow then
        local submode = LocalPlayer().HomigradSubmode or ""
        if string.lower(submode) == "jailbreak" then
            -- Подсчитываем охранников
            local guardsCount = 0
            for _, ply in ipairs(player.GetAll()) do
                if IsValid(ply) then
                    local team = ply:GetNWString("HomigradTeam", "")
                    if team == "guards" then
                        guardsCount = guardsCount + 1
                    end
                end
            end
            
            -- Показываем предупреждение если нет охранников
            if guardsCount < 1 then
                shouldShow = true
            end
        end
    end
    
    if shouldShow then
        local alpha = 255
        -- Если это таймерное сообщение, делаем плавное исчезновение
        if NoGuardsWarningTimer and CurTime() < NoGuardsWarningTimer then
            local remainingTime = NoGuardsWarningTimer - CurTime()
            alpha = math.min(255, remainingTime * 127.5)
        end
        
        local centerX = ScrW() / 2
        local centerY = ScrH() / 2
        
        -- Фон для текста (полупрозрачный черный)
        local bgWidth = 800
        local bgHeight = 80
        local bgX = centerX - bgWidth / 2
        local bgY = centerY - bgHeight / 2
        
        draw.RoundedBox(8, bgX, bgY, bgWidth, bgHeight, Color(20, 20, 20, alpha * 0.8))
        
        -- Основной текст
        draw.SimpleText("РАУНД НЕ МОЖЕТ НАЧАТЬСЯ", "RiotWinner", centerX, centerY - 20, Color(255, 100, 100, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        
        -- Подтекст
        draw.SimpleText("Пока не будет минимум 1 охранника", "DermaLarge", centerX, centerY + 20, Color(255, 200, 200, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
end)

hook.Add("HUDPaint", "Homigrad_Scoreboard", function()
    -- Не показываем основной ScoreBoard, если меню выбора команды АКТИВНО открыто
    -- (но не блокируем, когда оно уже закрывается и просто догорает альфа)
    if TeamSelectMenuOpen and TeamSelectMenuAlpha > 0 then 
        -- Но кнопки справа всё равно показываем
        local ply = LocalPlayer()
        if not IsValid(ply) then return end
        
        local scrW, scrH = ScrW(), ScrH()
        local boardWidth = math.min(1400, scrW * 0.9)
        local boardHeight = math.min(850, scrH * 0.9)
        local boardY = (scrH - boardHeight) / 2
        
        local buttonSize = 60
        local buttonX = scrW - buttonSize - 20
        local currentMode = ply.HomigradSubmode or ""
        local modeLower = string.lower(currentMode)
        
        local teamButtonY = boardY + boardHeight / 2 - buttonSize / 2
        local scoreboardButtonY = teamButtonY - buttonSize - 10
        
        local alpha = math.floor(math.Clamp(TeamSelectMenuAlpha, 0, 1) * 255)
        
        local mouseX, mouseY = gui.MousePos()
        local isScoreboardHovering = mouseX >= buttonX and mouseX <= buttonX + buttonSize and
                                     mouseY >= scoreboardButtonY and mouseY <= scoreboardButtonY + buttonSize
        
        local scoreboardButtonColor = isScoreboardHovering and Color(0, 0, 0, math.floor(alpha * 0.8)) or Color(0, 0, 0, math.floor(alpha * 0.5))
        draw.RoundedBox(4, buttonX, scoreboardButtonY, buttonSize, buttonSize, scoreboardButtonColor)
        
        surface.SetDrawColor(166, 166, 166, alpha)
        surface.DrawOutlinedRect(buttonX, scoreboardButtonY, buttonSize, buttonSize)
        
        draw.SimpleText("СКОР", "ScoreboardButton", buttonX + buttonSize / 2, scoreboardButtonY + buttonSize / 2 - 8, 
            Color(255, 255, 255, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText("БОРД", "ScoreboardButton", buttonX + buttonSize / 2, scoreboardButtonY + buttonSize / 2 + 8, 
            Color(255, 255, 255, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        
        -- Обработка клика по кнопке scoreboard когда меню выбора команды открыто
        if isScoreboardHovering and input.IsMouseDown(MOUSE_LEFT) and (CurTime() - LastTeamSelectClick) > 0.5 then
            LastTeamSelectClick = CurTime()
            -- Закрываем меню выбора команды и открываем ScoreBoard
            TeamSelectMenuOpen = false
            TeamSelectMenuTargetAlpha = 0
            TeamSelectMenuCursorEnabled = false
            -- Открываем ScoreBoard
            TabHudTargetAlpha = 1
            PoliceTimerTargetAlpha = 1
            ScoreboardTargetAlpha = 1
            ScoreboardAlpha = 0 -- Устанавливаем начальное значение для плавного появления
            -- Если открыта кастомизация, закрываем её
            if IsValid(CustomizationPanel) then
                CustomizationPanel:Remove()
                CustomizationPanel = nil
            end
            -- Включаем курсор для ScoreBoard
            gui.EnableScreenClicker(true)
            -- Сбрасываем смещение прокрутки при открытии
            ScoreboardScrollOffset = 0
            ScoreboardScrollTarget = 0
            -- Запрашиваем актуальные данные ScoreBoard
            net.Start("Homigrad_ScoreboardData")
            net.SendToServer()
        end
        
        -- Кнопка выбора команды (всегда отображается)
        local isHovering = mouseX >= buttonX and mouseX <= buttonX + buttonSize and
                          mouseY >= teamButtonY and mouseY <= teamButtonY + buttonSize
        
        local buttonColor = isHovering and Color(0, 0, 0, math.floor(alpha * 0.8)) or Color(0, 0, 0, math.floor(alpha * 0.5))
        draw.RoundedBox(4, buttonX, teamButtonY, buttonSize, buttonSize, buttonColor)
        
        surface.SetDrawColor(166, 166, 166, alpha)
        surface.DrawOutlinedRect(buttonX, teamButtonY, buttonSize, buttonSize)
        
        draw.SimpleText("КОМ", "ScoreboardButton", buttonX + buttonSize / 2, teamButtonY + buttonSize / 2 - 8, 
            Color(255, 255, 255, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText("АНДА", "ScoreboardButton", buttonX + buttonSize / 2, teamButtonY + buttonSize / 2 + 8, 
            Color(255, 255, 255, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

        -- Клик по кнопке команды из экрана кастомизации: закрываем кастомизацию и открываем меню выбора команды
        local isDown = input.IsMouseDown(MOUSE_LEFT)
        if isHovering and isDown and not TeamButtonWasDown and (CurTime() - LastTeamSelectClick) > 0.2 then
            LastTeamSelectClick = CurTime()
            -- Закрываем кастомизацию
            if IsValid(CustomizationPanel) then
                CustomizationPanel:Remove()
                CustomizationPanel = nil
            end
            -- Открываем меню выбора команды
            TeamSelectMenuOpen = false
            TeamSelectMenuAlpha = 0
            TeamSelectMenuCursorEnabled = false
            TeamSelectMenuOpen = true
            TeamSelectMenuTargetAlpha = 1
            TeamSelectMenuAlpha = math.max(TeamSelectMenuAlpha or 0, 0.02)
            TeamSelectMenuCursorEnabled = false
            gui.EnableScreenClicker(true)
            -- Скрываем скорборд
            TabHudTargetAlpha = 0
            ScoreboardTargetAlpha = 0
            ScoreboardAlpha = 0
        end
        TeamButtonWasDown = isDown
        
        -- Кнопка "КАСТОМИЗАЦИЯ" под кнопкой КОМАНДА, даже когда открыто меню выбора команды
        do
            local custBtnY = teamButtonY + buttonSize + 10
            local custBtnW, custBtnH = buttonSize, buttonSize
            local mx, my = gui.MousePos()
            local custHover = mx >= buttonX and mx <= buttonX + custBtnW and my >= custBtnY and my <= custBtnY + custBtnH
            local custCol = custHover and Color(0, 0, 0, math.floor(alpha * 0.8)) or Color(0, 0, 0, math.floor(alpha * 0.5))
            draw.RoundedBox(4, buttonX, custBtnY, custBtnW, custBtnH, custCol)
            surface.SetDrawColor(166, 166, 166, alpha)
            surface.DrawOutlinedRect(buttonX, custBtnY, custBtnW, custBtnH)
            draw.SimpleText("КАСТО", "ScoreboardButton", buttonX + custBtnW / 2, custBtnY + custBtnH / 2 - 8,
                Color(255, 255, 255, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            draw.SimpleText("МИЗАЦ", "ScoreboardButton", buttonX + custBtnW / 2, custBtnY + custBtnH / 2 + 8,
                Color(255, 255, 255, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

            -- Клик: закрываем меню выбора команды, открываем кастомизацию и скрываем скорборд
            if custHover and input.IsMouseDown(MOUSE_LEFT) and (CurTime() - LastCustomizationClick) > 0.3 then
                LastCustomizationClick = CurTime()
                TeamSelectMenuOpen = false
                TeamSelectMenuTargetAlpha = 0
                TeamSelectMenuCursorEnabled = false
                OpenCustomizationPanel(scrW/2 - boardWidth/2, boardY, boardWidth, boardHeight)
                TabHudTargetAlpha = 0
                ScoreboardTargetAlpha = 0
                ScoreboardAlpha = 0
            end
        end
        
        return
    end
    if ScoreboardAlpha <= 0 then 
        -- Если открыт экран кастомизации, продолжаем рисовать правые кнопки (Скорборд, Команда, Кастомизация)
        if IsValid(CustomizationPanel) then
            local scrW, scrH = ScrW(), ScrH()
            local boardWidth = math.min(1400, scrW * 0.9)
            local boardHeight = math.min(850, scrH * 0.9)
            local boardY = (scrH - boardHeight) / 2
            local buttonSize = 60
            local buttonX = scrW - buttonSize - 20
            local teamButtonY = boardY + boardHeight / 2 - buttonSize / 2
            local scoreboardButtonY = teamButtonY - buttonSize - 10
            local alpha = 255

            local mouseX, mouseY = gui.MousePos()
            local isScoreboardHovering = mouseX >= buttonX and mouseX <= buttonX + buttonSize and
                                         mouseY >= scoreboardButtonY and mouseY <= scoreboardButtonY + buttonSize

            local scoreboardButtonColor = isScoreboardHovering and Color(0, 0, 0, math.floor(alpha * 0.8)) or Color(0, 0, 0, math.floor(alpha * 0.5))
            draw.RoundedBox(4, buttonX, scoreboardButtonY, buttonSize, buttonSize, scoreboardButtonColor)
            surface.SetDrawColor(166, 166, 166, alpha)
            surface.DrawOutlinedRect(buttonX, scoreboardButtonY, buttonSize, buttonSize)
            draw.SimpleText("СКОР", "ScoreboardButton", buttonX + buttonSize / 2, scoreboardButtonY + buttonSize / 2 - 8, 
                Color(255, 255, 255, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            draw.SimpleText("БОРД", "ScoreboardButton", buttonX + buttonSize / 2, scoreboardButtonY + buttonSize / 2 + 8, 
                Color(255, 255, 255, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

            do
                local isTeamHovering = mouseX >= buttonX and mouseX <= buttonX + buttonSize and
                                       mouseY >= teamButtonY and mouseY <= teamButtonY + buttonSize
                local teamButtonColor = isTeamHovering and Color(0, 0, 0, math.floor(alpha * 0.8)) or Color(0, 0, 0, math.floor(alpha * 0.5))
                draw.RoundedBox(4, buttonX, teamButtonY, buttonSize, buttonSize, teamButtonColor)
                surface.SetDrawColor(166, 166, 166, alpha)
                surface.DrawOutlinedRect(buttonX, teamButtonY, buttonSize, buttonSize)
                draw.SimpleText("КОМ", "ScoreboardButton", buttonX + buttonSize / 2, teamButtonY + buttonSize / 2 - 8, 
                    Color(255, 255, 255, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                draw.SimpleText("АНДА", "ScoreboardButton", buttonX + buttonSize / 2, teamButtonY + buttonSize / 2 + 8, 
                    Color(255, 255, 255, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

                -- Клик по кнопке команды из экрана кастомизации: закрываем кастомизацию и открываем меню выбора команды
                local isDown = input.IsMouseDown(MOUSE_LEFT)
                if isTeamHovering and isDown and not TeamButtonWasDown and (CurTime() - LastTeamSelectClick) > 0.2 then
                    LastTeamSelectClick = CurTime()
                    -- Закрываем кастомизацию
                    if IsValid(CustomizationPanel) then
                        CustomizationPanel:Remove()
                        CustomizationPanel = nil
                    end
                    -- Открываем меню выбора команды
                    TeamSelectMenuOpen = false
                    TeamSelectMenuAlpha = 0
                    TeamSelectMenuCursorEnabled = false
                    TeamSelectMenuOpen = true
                    TeamSelectMenuTargetAlpha = 1
                    TeamSelectMenuAlpha = math.max(TeamSelectMenuAlpha or 0, 0.02)
                    TeamSelectMenuCursorEnabled = false
                    gui.EnableScreenClicker(true)
                    -- Скрываем скорборд
                    TabHudTargetAlpha = 0
                    ScoreboardTargetAlpha = 0
                    ScoreboardAlpha = 0
                end
                TeamButtonWasDown = isDown
            end

            do
                local custBtnY = teamButtonY + buttonSize + 10
                local custBtnW, custBtnH = buttonSize, buttonSize
                local mx, my = gui.MousePos()
                local custHover = mx >= buttonX and mx <= buttonX + custBtnW and my >= custBtnY and my <= custBtnY + custBtnH
                local custCol = custHover and Color(0, 0, 0, math.floor(alpha * 0.8)) or Color(0, 0, 0, math.floor(alpha * 0.5))
                draw.RoundedBox(4, buttonX, custBtnY, custBtnW, custBtnH, custCol)
                surface.SetDrawColor(166, 166, 166, alpha)
                surface.DrawOutlinedRect(buttonX, custBtnY, custBtnW, custBtnH)
                draw.SimpleText("КАСТО", "ScoreboardButton", buttonX + custBtnW / 2, custBtnY + custBtnH / 2 - 8,
                    Color(255, 255, 255, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                draw.SimpleText("МИЗАЦ", "ScoreboardButton", buttonX + custBtnW / 2, custBtnY + custBtnH / 2 + 8,
                    Color(255, 255, 255, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end

            return
        end
        return 
    end
    
    local alpha = ScoreboardAlpha * 255
    local ply = LocalPlayer()
    if not IsValid(ply) then return end
    
    -- Размеры и позиция ScoreBoard (еще больше)
    local scrW, scrH = ScrW(), ScrH()
    local boardWidth = math.min(1400, scrW * 0.9)
    local boardHeight = math.min(850, scrH * 0.9)
    local boardX = (scrW - boardWidth) / 2
    local boardY = (scrH - boardHeight) / 2
    
    -- Фон ScoreBoard
    draw.RoundedBox(8, boardX, boardY, boardWidth, boardHeight, Color(20, 20, 20, alpha * 0.9))
    
    -- Рамка
    surface.SetDrawColor(100, 100, 100, alpha)
    surface.DrawOutlinedRect(boardX, boardY, boardWidth, boardHeight)
    
    -- Заголовок
    draw.SimpleText("ЖЕСТОКАЯ ТЮРЯГА | МУСОРСКОЙ БЕСПРЕДЕЛ | !8+", "ScoreboardTitle", boardX + boardWidth / 2, boardY + 20, Color(255, 255, 255, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)

    -- Заголовки колонок
    local headerY = boardY + 60
    local colWidth = (boardWidth - 40) / 7 -- Увеличиваем количество колонок для аватарки
    
    draw.SimpleText("АВАТАР", "ScoreboardInfo", boardX + 20, headerY, Color(200, 200, 200, alpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
    draw.SimpleText("ИГРОК", "ScoreboardInfo", boardX + 20 + colWidth, headerY, Color(200, 200, 200, alpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
    draw.SimpleText("КОМАНДА", "ScoreboardInfo", boardX + 20 + colWidth * 2, headerY, Color(200, 200, 200, alpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

    do
        local buttonSize = 60
        local buttonX = scrW - buttonSize - 20
        local teamButtonY = boardY + boardHeight / 2 - buttonSize / 2
        local scoreboardButtonY = teamButtonY - buttonSize - 10

        local mouseX, mouseY = gui.MousePos()
        local isScoreboardHovering = mouseX >= buttonX and mouseX <= buttonX + buttonSize and
                                     mouseY >= scoreboardButtonY and mouseY <= scoreboardButtonY + buttonSize

        local scoreboardButtonColor = isScoreboardHovering and Color(0, 0, 0, math.floor(alpha * 0.8)) or Color(0, 0, 0, math.floor(alpha * 0.5))
        draw.RoundedBox(4, buttonX, scoreboardButtonY, buttonSize, buttonSize, scoreboardButtonColor)
        surface.SetDrawColor(166, 166, 166, alpha)
        surface.DrawOutlinedRect(buttonX, scoreboardButtonY, buttonSize, buttonSize)
        draw.SimpleText("СКОР", "ScoreboardButton", buttonX + buttonSize / 2, scoreboardButtonY + buttonSize / 2 - 8, 
            Color(255, 255, 255, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText("БОРД", "ScoreboardButton", buttonX + buttonSize / 2, scoreboardButtonY + buttonSize / 2 + 8, 
            Color(255, 255, 255, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

        local currentMode = ply.HomigradSubmode or ""
        local modeLower = string.lower(currentMode)
        do
            local isTeamHovering = mouseX >= buttonX and mouseX <= buttonX + buttonSize and
                                   mouseY >= teamButtonY and mouseY <= teamButtonY + buttonSize
            local teamButtonColor = isTeamHovering and Color(0, 0, 0, math.floor(alpha * 0.8)) or Color(0, 0, 0, math.floor(alpha * 0.5))
            draw.RoundedBox(4, buttonX, teamButtonY, buttonSize, buttonSize, teamButtonColor)
            surface.SetDrawColor(255, 255, 255, alpha)
            surface.DrawOutlinedRect(buttonX, teamButtonY, buttonSize, buttonSize)
            draw.SimpleText("КОМ", "ScoreboardButton", buttonX + buttonSize / 2, teamButtonY + buttonSize / 2 - 8, 
                Color(255, 255, 255, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            draw.SimpleText("АНДА", "ScoreboardButton", buttonX + buttonSize / 2, teamButtonY + buttonSize / 2 + 8, 
                Color(255, 255, 255, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

            -- Прямой обработчик клика по кнопке "КОМАНДА" для открытия меню выбора команды
            local isDown = input.IsMouseDown(MOUSE_LEFT)
            if isTeamHovering and isDown and not TeamButtonWasDown and (CurTime() - LastTeamSelectClick) > 0.2 then
                LastTeamSelectClick = CurTime()
                -- Открываем меню выбора команды и закрываем ScoreBoard
                -- Сбрасываем состояние, чтобы повторные открытия всегда работали
                TeamSelectMenuOpen = false
                TeamSelectMenuAlpha = 0
                TeamSelectMenuCursorEnabled = false
                -- Теперь открываем заново
                TeamSelectMenuOpen = true
                TeamSelectMenuTargetAlpha = 1
                -- Небольшой толчок альфы, чтобы меню начало рисоваться в этот же кадр
                TeamSelectMenuAlpha = math.max(TeamSelectMenuAlpha or 0, 0.02)
                TeamSelectMenuCursorEnabled = false -- Курсор включится в HUDPaint меню
                -- На переходе убедимся, что курсор включен
                gui.EnableScreenClicker(true)
                -- Закрываем ScoreBoard
                TabHudTargetAlpha = 0
                ScoreboardTargetAlpha = 0
                ScoreboardAlpha = 0
            end
            -- Запоминаем состояние мыши, чтобы клик обрабатывался по фронту нажатия
            TeamButtonWasDown = isDown
        end
    end
    draw.SimpleText("ВРЕМЯ", "ScoreboardInfo", boardX + 20 + colWidth * 3, headerY, Color(200, 200, 200, alpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
  draw.SimpleText("ПИНГ", "ScoreboardInfo", boardX + 20 + colWidth * 4, headerY, Color(200, 200, 200, alpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
  draw.SimpleText("СТАТУС", "ScoreboardInfo", boardX + 20 + colWidth * 5, headerY, Color(200, 200, 200, alpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
  draw.SimpleText("ДЕЙСТВИЯ", "ScoreboardInfo", boardX + 20 + colWidth * 6, headerY, Color(200, 200, 200, alpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
  -- Отображение игроков (больше по размеру)
  local playerY = headerY + 40
  local playerHeight = 80 -- Увеличиваем высоту строки игрока
  
  -- Определяем видимую область для игроков (с учетом графика внизу)
  local graphHeight = 100 -- Высота графика
  local visibleAreaTop = headerY + 20 -- Ограничиваем сверху областью заголовков
  local visibleAreaBottom = boardY + boardHeight - graphHeight - 20
  local visibleAreaHeight = visibleAreaBottom - visibleAreaTop
  
  -- Рассчитываем максимальное смещение прокрутки
  local totalPlayersHeight = #ScoreboardData * playerHeight
  local maxScrollOffset = math.max(0, totalPlayersHeight - visibleAreaHeight)
  
  -- Ограничиваем смещение прокрутки
  if ScoreboardScrollOffset > maxScrollOffset then
      ScoreboardScrollOffset = maxScrollOffset
  end
    
    -- Ограничиваем целевое смещение прокрутки
    if ScoreboardScrollTarget > maxScrollOffset then
        ScoreboardScrollTarget = maxScrollOffset
    end
    if ScoreboardScrollTarget < 0 then
        ScoreboardScrollTarget = 0
    end
    
    for i, playerData in ipairs(ScoreboardData) do
        -- Применяем смещение прокрутки
        local rowY = playerY + (i - 1) * playerHeight - ScoreboardScrollOffset
        
        -- Проверяем, находится ли строка в видимой области
        -- Также убеждаемся, что строка не налезает на заголовки
        local separatorLineY = headerY + 20
        local minRowY = separatorLineY + 5 -- Минимальная позиция для начала строки (5 пикселей отступа)
        if rowY >= minRowY and rowY <= visibleAreaBottom then
        
        -- Фон строки (чередующиеся цвета)
        local rowColor = i % 2 == 0 and Color(30, 30, 30, alpha * 0.5) or Color(40, 40, 40, alpha * 0.3)
        draw.RoundedBox(4, boardX + 10, rowY, boardWidth - 20, playerHeight - 5, rowColor)
        
        local localMuted = false
        do
            for _, ep in ipairs(player.GetAll()) do
                if IsValid(ep) and ep:SteamID() == playerData.steamid then
                    if ep.IsMuted then
                        localMuted = ep:IsMuted()
                    end
                    break
                end
            end
        end

        -- Цвет имени игрока в зависимости от статуса
        local nameColor = Color(255, 255, 255, alpha)
        if not playerData.alive then
            nameColor = Color(150, 150, 150, alpha)
        elseif localMuted then
            nameColor = Color(255, 100, 100, alpha)
        end
        
        -- Аватарка игрока (уменьшена)
        local avatarSize = 64
        local avatarX = boardX + 20
        local avatarY = rowY + (playerHeight - avatarSize) / 2
        
        -- Загружаем аватарку если еще не загружена
        if not PlayerAvatars[playerData.steamid] or not PlayerAvatars[playerData.steamid].loaded then
            LoadPlayerAvatar(playerData.steamid)
        end
        
        -- Рисуем аватарку или заглушку
        do
            local av = PlayerAvatars[playerData.steamid]
            local drew = false
            -- Привязываем прозрачность аватара к прозрачности всего ScoreBoard
            local avatarAlpha = alpha
            if av then
                -- 1) Валидный материал — рисуем сразу
                if av.material and (not av.material:IsError()) then
                    surface.SetDrawColor(255, 255, 255, avatarAlpha)
                    surface.SetMaterial(av.material)
                    surface.DrawTexturedRect(avatarX, avatarY, avatarSize, avatarSize)
                    drew = true
                else
                    -- 2) Форсим инициализацию панели и пробуем вытащить материал
                    if IsValid(av.panel) then
                        if av.panel.PaintAt then av.panel:PaintAt(-10000, -10000, 2, 2) end
                        if av.panel.GetMaterial then
                            local mat = av.panel:GetMaterial()
                            if mat and (not mat:IsError()) then
                                av.material = mat
                                surface.SetDrawColor(255, 255, 255, avatarAlpha)
                                surface.SetMaterial(mat)
                                surface.DrawTexturedRect(avatarX, avatarY, avatarSize, avatarSize)
                                drew = true
                            end
                        end
                        -- Рисуем live панель на месте аватара, теперь без артефактов (панель 64x64)
                        if not drew and av.panel.PaintAt then
                            if av.panel.SetAlpha then av.panel:SetAlpha(avatarAlpha) end
                            av.panel:PaintAt(avatarX, avatarY, avatarSize, avatarSize)
                            -- Попробуем сразу забрать материал после live-отрисовки
                            if av.panel.GetMaterial then
                                local liveMat = av.panel:GetMaterial()
                                if liveMat and (not liveMat:IsError()) then
                                    av.material = liveMat
                                end
                            end
                            drew = true
                        end
                    end
                end
            end
            if not drew then
                -- Заглушка пока аватарка загружается
                draw.RoundedBox(4, avatarX, avatarY, avatarSize, avatarSize, Color(100, 100, 100, avatarAlpha))
            end
        end
        
        -- Рамка аватарки
        surface.SetDrawColor(200, 200, 200, alpha)
        surface.DrawOutlinedRect(avatarX, avatarY, avatarSize, avatarSize)
        
        -- Имя игрока
        draw.SimpleText(playerData.name, "ScoreboardPlayerName", boardX + 20 + colWidth, rowY + playerHeight / 2, nameColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        
        -- Команда
        local teamColor = Color(255, 255, 255, alpha)
        local teamDisplayText = playerData.teamDisplay
        
        -- Определяем цвет в зависимости от команды
        if playerData.teamDisplay == "Неизвестно" then
            teamColor = Color(150, 150, 150, alpha) -- Серый цвет для "Неизвестно"
        elseif playerData.teamDisplay == "Бунтующие" then
            teamColor = Color(255, 100, 10, alpha)
        elseif playerData.teamDisplay == "Полиция" then
            teamColor = Color(16, 0, 255, alpha)
        elseif playerData.teamDisplay == "Жертвы" then
            teamColor = Color(0, 255, 29, alpha)
        elseif playerData.teamDisplay == "Стрелки" then
            teamColor = Color(255, 0, 0, alpha)
        elseif playerData.teamDisplay == "Охранник" then
            teamColor = Color(16, 0, 255, alpha)
        elseif playerData.teamDisplay == "Заключённый" then
            teamColor = Color(255, 100, 10, alpha)
        elseif playerData.teamDisplay == "Предатель" then
            teamColor = Color(255, 0, 0, alpha)
        elseif playerData.teamDisplay == "Вооружённый" then
            teamColor = Color(161, 0, 255, alpha)
        elseif playerData.teamDisplay == "Невиновный" then
            teamColor = Color(0, 185, 255, alpha)
        elseif playerData.teamDisplay == "Боец" then
            teamColor = Color(255, 0, 0, alpha)
        elseif playerData.teamDisplay == "Ивент" then
            teamColor = Color(242, 0, 255, alpha)
        elseif playerData.teamDisplay == "Админ" then
            teamColor = Color(255, 0, 0, alpha)
        elseif playerData.teamDisplay == "Наблюдатели" then
            teamColor = Color(160, 160, 160, alpha)
        elseif playerData.teamDisplay == "Спецназ" then
            teamColor = Color(0, 185, 255, alpha)
        elseif playerData.teamDisplay == "Террористы" then
            teamColor = Color(255, 0, 0, alpha)
        end
        
        draw.SimpleText(teamDisplayText, "ScoreboardInfo", boardX + 20 + colWidth * 2, rowY + playerHeight / 2, teamColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        
        -- Время игры
        draw.SimpleText(playerData.playtime, "ScoreboardInfo", boardX + 20 + colWidth * 3, rowY + playerHeight / 2, Color(255, 255, 255, alpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        
        -- Пинг
        local pingColor = Color(255, 255, 255, alpha)
        if playerData.ping > 100 then
            pingColor = Color(255, 100, 100, alpha)
        elseif playerData.ping > 50 then
            pingColor = Color(255, 200, 100, alpha)
        end
        
        draw.SimpleText(tostring(playerData.ping), "ScoreboardInfo", boardX + 20 + colWidth * 4, rowY + playerHeight / 2, pingColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        
        -- Статус
        local statusText = playerData.alive and "ЖИВ" or "МЕРТВ"
        local statusColor = playerData.alive and Color(0, 255, 8, alpha) or Color(255, 0, 0, alpha)
        draw.SimpleText(statusText, "ScoreboardInfo", boardX + 32 + colWidth * 5, rowY + playerHeight / 2, statusColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        
        -- Кнопка мута в виде иконки (только для админов)
        if playerData.steamid ~= ply:SteamID() then
            local iconSize = 24
            local iconX = boardX + 20 + colWidth * 6 + (colWidth - iconSize) / 2 - 50
            local iconY = rowY + (playerHeight - iconSize) / 2
            
            -- Проверяем наведение мыши
            local mouseX, mouseY = gui.MouseX(), gui.MouseY()
            local isHovered = mouseX >= iconX and mouseX <= iconX + iconSize and 
                            mouseY >= iconY and mouseY <= iconY + iconSize
            
            -- Фон кнопки при наведении
            if isHovered then
                draw.RoundedBox(4, iconX - 2, iconY - 2, iconSize + 4, iconSize + 4, Color(255, 255, 255, alpha * 0.2))
                
                -- Обработка клика (с защитой от спама)
                if input.IsMouseDown(MOUSE_LEFT) and (CurTime() - LastMuteClick) > 0.5 then
                    LastMuteClick = CurTime()
                    local target = nil
                    for _, ep in ipairs(player.GetAll()) do
                        if IsValid(ep) and ep:SteamID() == playerData.steamid then
                            target = ep
                            break
                        end
                    end
                    if IsValid(target) and target.IsMuted and target.SetMuted then
                        target:SetMuted(not target:IsMuted())
                    end
                end
            end
            
            -- Загружаем иконку из icon16
            local iconMaterial = Material(localMuted and "icon16/sound_mute.png" or "icon16/sound.png", "noclamp smooth")
            
            -- Устанавливаем цвет иконки (для мутированных игроков красный оттенок)
            if localMuted then
                surface.SetDrawColor(255, 100, 100, alpha)
            else
                surface.SetDrawColor(255, 255, 255, alpha)
            end
            
            surface.SetMaterial(iconMaterial)
            
            -- Рисуем иконку
            surface.DrawTexturedRect(iconX, iconY, iconSize, iconSize)
            
            -- Подсказка при наведении
            if isHovered then
                local tooltipText = localMuted and "Размутить игрока" or "Замутить игрока"
                local tooltipWidth = #tooltipText * 7 + 10
                local tooltipX = iconX - tooltipWidth / 2
                local tooltipY = iconY - 30
                
                -- Фон подсказки
                draw.RoundedBox(4, tooltipX, tooltipY, tooltipWidth, 20, Color(0, 0, 0, alpha * 0.8))
                
                -- Текст подсказки
                draw.SimpleText(tooltipText, "ScoreboardInfo", iconX + iconSize / 2, tooltipY + 10, Color(255, 255, 255, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end
        end
        end -- Конец if для проверки видимости строки
    end
    
    -- Рисуем график FPS напрямую в ScoreBoard (без отступов, вплотную к краям)
    local graphHeight = 100
    -- График занимает всю ширину ScoreBoard без отступов по бокам
    local graphWidth = boardWidth -- Полная ширина
    local graphX = boardX -- Начинаем с левого края
    local graphY = boardY + boardHeight - graphHeight -- Вплотную к нижнему краю
    
    -- Фон для графика (полупрозрачная область)
    surface.SetDrawColor(0, 0, 0, alpha * 0.2)
    surface.DrawRect(graphX, graphY, graphWidth, graphHeight)
    
    if #FPSHistory > 1 and #SmoothFPSHistory > 1 then
        -- Масштабируем график используя сглаженные значения
        local maxFPS = 0
        for i = 1, #SmoothFPSHistory do
            maxFPS = math.max(maxFPS, SmoothFPSHistory[i])
        end
        maxFPS = math.max(60, maxFPS)
        
        -- Рисуем линии графика с плавной анимацией
        for i = 1, #SmoothFPSHistory - 1 do
            local x1 = graphX + (i - 1) * (graphWidth / MaxFPSHistoryPoints)
            local y1 = graphY + graphHeight - (SmoothFPSHistory[i] / maxFPS) * graphHeight
            
            local x2 = graphX + i * (graphWidth / MaxFPSHistoryPoints)
            local y2 = graphY + graphHeight - (SmoothFPSHistory[i + 1] / maxFPS) * graphHeight
            
            -- Цвет линии зависит от FPS
            local lineColor = Color(100, 255, 100, alpha)
            if SmoothFPSHistory[i] < 30 then
                lineColor = Color(255, 100, 100, alpha)
            elseif SmoothFPSHistory[i] < 50 then
                lineColor = Color(255, 200, 100, alpha)
            end
            
            -- Рисуем более толстую линию для лучшей видимости (3 пикселя)
            surface.SetDrawColor(lineColor)
            for offset = -1, 1 do
                surface.DrawLine(x1, y1 + offset, x2, y2 + offset)
            end
        end
        
        -- Добавляем заливку под графиком
        if #SmoothFPSHistory > 0 then
            local fillPoints = {}
            table.insert(fillPoints, {x = graphX, y = graphY + graphHeight})
            
            for i = 1, #SmoothFPSHistory do
                local x = graphX + (i - 1) * (graphWidth / MaxFPSHistoryPoints)
                local y = graphY + graphHeight - (SmoothFPSHistory[i] / maxFPS) * graphHeight
                table.insert(fillPoints, {x = x, y = y})
            end
            
            table.insert(fillPoints, {x = graphX + graphWidth, y = graphY + graphHeight})
            
            -- Полупрозрачная заливка
            surface.SetDrawColor(50, 255, 50, alpha * 0.1)
            surface.DrawPoly(fillPoints)
        end
        
        -- Текущий FPS
        local currentFPS = FPSHistory[#FPSHistory]
        local fpsColor = Color(100, 255, 100, alpha)
        if currentFPS < 30 then
            fpsColor = Color(255, 100, 100, alpha)
        elseif currentFPS < 50 then
            fpsColor = Color(255, 200, 100, alpha)
        end
        
        -- Минимальный FPS
        local minFPS = FPSHistory[1]
        for i = 2, #FPSHistory do
            minFPS = math.min(minFPS, FPSHistory[i])
        end
        
        draw.SimpleText("TickRate: " .. currentFPS, "ScoreboardInfo", graphX + 10, graphY + graphHeight - 20, fpsColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        draw.SimpleText("Min TickRate: " .. minFPS, "ScoreboardInfo", graphX + graphWidth - 60, graphY + graphHeight - 20, Color(255, 100, 100, alpha), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
    end
    
    -- Кнопка выбора команды (во всех режимах, справа прилегая к краю экрана, квадратная)
    -- Скрываем кнопку если открыто меню выбора команды
    local buttonSize = 60 -- Квадратная кнопка
    local buttonX = scrW - buttonSize - 20 -- Справа прилегая к краю экрана
    local currentMode = ply.HomigradSubmode or ""
    local modeLower = string.lower(currentMode)
    
    -- Вычисляем позицию кнопки команды (используется для позиционирования кнопки скорборда)
    local teamButtonY = boardY + boardHeight / 2 - buttonSize / 2 -- По центру вертикально
    
    -- Кнопка scoreboard (справа прилегая к краю экрана, квадратная, всегда чуть выше кнопки команды)
    local scoreboardButtonY = teamButtonY - buttonSize - 10 -- Всегда выше кнопки команды на размер кнопки + 10 пикселей
    
    -- Проверяем клик по кнопке scoreboard
    local mouseX, mouseY = gui.MousePos()
    local isScoreboardHovering = mouseX >= buttonX and mouseX <= buttonX + buttonSize and
                                 mouseY >= scoreboardButtonY and mouseY <= scoreboardButtonY + buttonSize
    
    -- Фон кнопки scoreboard
    local scoreboardButtonColor = isScoreboardHovering and Color(0, 0, 0, math.floor(alpha * 0.8)) or Color(0, 0, 0, math.floor(alpha * 0.5))
    draw.RoundedBox(4, buttonX, scoreboardButtonY, buttonSize, buttonSize, scoreboardButtonColor)
    
    -- Рамка кнопки scoreboard
    surface.SetDrawColor(166, 166, 166, alpha)
    surface.DrawOutlinedRect(buttonX, scoreboardButtonY, buttonSize, buttonSize)
    
    -- Текст кнопки scoreboard (разбиваем на две строки для квадратной кнопки)
    draw.SimpleText("СКОР", "ScoreboardButton", buttonX + buttonSize / 2, scoreboardButtonY + buttonSize / 2 - 8, 
        Color(255, 255, 255, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    draw.SimpleText("БОРД", "ScoreboardButton", buttonX + buttonSize / 2, scoreboardButtonY + buttonSize / 2 + 8, 
        Color(255, 255, 255, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    
    -- Кнопка выбора команды (во всех режимах)
    if TeamSelectMenuAlpha <= 0 then
        
        -- Проверяем клик по кнопке
        local isHovering = mouseX >= buttonX and mouseX <= buttonX + buttonSize and
                          mouseY >= teamButtonY and mouseY <= teamButtonY + buttonSize
        
        -- Фон кнопки
        local buttonColor = isHovering and Color(0, 0, 0, math.floor(alpha * 0.8)) or Color(0, 0, 0, math.floor(alpha * 0.5))
        draw.RoundedBox(4, buttonX, teamButtonY, buttonSize, buttonSize, buttonColor)
        
        -- Рамка кнопки
        surface.SetDrawColor(166, 166, 166, alpha)
        surface.DrawOutlinedRect(buttonX, teamButtonY, buttonSize, buttonSize)
        
        -- Текст кнопки (разбиваем на две строки для квадратной кнопки)
        draw.SimpleText("КОМ", "ScoreboardButton", buttonX + buttonSize / 2, teamButtonY + buttonSize / 2 - 8, 
            Color(255, 255, 255, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText("АНДА", "ScoreboardButton", buttonX + buttonSize / 2, teamButtonY + buttonSize / 2 + 8, 
            Color(255, 255, 255, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

        -- Прямой обработчик клика по плавающей кнопке
        local isDown = input.IsMouseDown(MOUSE_LEFT)
        if isHovering and isDown and not TeamButtonWasDown and (CurTime() - LastTeamSelectClick) > 0.2 then
            LastTeamSelectClick = CurTime()
            TeamSelectMenuOpen = false
        end
    end

    -- Кнопка "КАСТОМИЗАЦИЯ" под кнопкой КОМАНДА (всегда отображается; доступность проверяется внутри OpenCustomizationPanel)
    do
        local custBtnY = teamButtonY + buttonSize + 10
        local custBtnW, custBtnH = buttonSize, buttonSize
        local mx, my = gui.MousePos()
        local custHover = mx >= buttonX and mx <= buttonX + custBtnW and my >= custBtnY and my <= custBtnY + custBtnH
        local custCol = custHover and Color(0, 0, 0, math.floor(alpha * 0.8)) or Color(0, 0, 0, math.floor(alpha * 0.5))
        draw.RoundedBox(4, buttonX, custBtnY, custBtnW, custBtnH, custCol)
        surface.SetDrawColor(166, 166, 166, alpha)
        surface.DrawOutlinedRect(buttonX, custBtnY, custBtnW, custBtnH)
        draw.SimpleText("КАСТО", "ScoreboardButton", buttonX + custBtnW / 2, custBtnY + custBtnH / 2 - 8,
            Color(255, 255, 255, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText("МИЗАЦ", "ScoreboardButton", buttonX + custBtnW / 2, custBtnY + custBtnH / 2 + 8,
            Color(255, 255, 255, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

        if custHover and input.IsMouseDown(MOUSE_LEFT) and (CurTime() - LastCustomizationClick) > 0.3 then
            LastCustomizationClick = CurTime()
            print("[Homigrad|Client] Opening customization panel")
            OpenCustomizationPanel(boardX, boardY, boardWidth, boardHeight)
            -- Hide scoreboard when opening customization panel
            TabHudTargetAlpha = 0
            ScoreboardTargetAlpha = 0
            ScoreboardAlpha = 0
        end
    end
end)

-- Обработка прокрутки колесиком мыши
local lastScrollValue = 0
hook.Add("PlayerButtonDown", "Homigrad_ScoreboardScroll", function(ply, button)
    if ply ~= LocalPlayer() then return end
    
    if ScoreboardAlpha > 0 then
        if button == KEY_WHEEL_UP or button == MOUSE_WHEEL_UP then
            ScoreboardScrollTarget = math.max(0, ScoreboardScrollTarget - 80)
        elseif button == KEY_WHEEL_DOWN or button == MOUSE_WHEEL_DOWN then
            ScoreboardScrollTarget = ScoreboardScrollTarget + 80
        end
    end
end)

-- Обработка кликов по кнопке scoreboard
hook.Add("PlayerButtonDown", "Homigrad_ScoreboardButton", function(ply, button)
    if ply ~= LocalPlayer() then return end
    if button ~= MOUSE_LEFT then return end
    -- Обрабатываем клик даже если scoreboard закрыт или открыто меню выбора команды
    -- Проверяем клик по кнопке scoreboard
    local scrW, scrH = ScrW(), ScrH()
    local boardWidth = math.min(1400, scrW * 0.9)
    local boardHeight = math.min(850, scrH * 0.9)
    local boardX = (scrW - boardWidth) / 2
    local boardY = (scrH - boardHeight) / 2
    
    -- Локальная геометрия, чтобы работать независимо от состояния скорборда
    local scrW, scrH = ScrW(), ScrH()
    local boardWidth = math.min(1400, scrW * 0.9)
    local boardHeight = math.min(850, scrH * 0.9)
    local boardY = (scrH - boardHeight) / 2
    local buttonSize = 60 -- Квадратная кнопка
    local buttonX = scrW - buttonSize - 20 -- Справа прилегая к краю экрана
    -- Вычисляем позицию кнопки команды для правильного позиционирования кнопки скорборда
    local teamButtonY = boardY + boardHeight / 2 - buttonSize / 2
    local scoreboardButtonY = teamButtonY - buttonSize - 10 -- Всегда выше кнопки команды на размер кнопки + 10 пикселей
    
    local mx, my = gui.MousePos()
    local isHoveringScore = mx >= buttonX and mx <= buttonX + buttonSize and my >= scoreboardButtonY and my <= scoreboardButtonY + buttonSize
    if isHoveringScore then
        -- Если открыта кастомизация, закрываем её и открываем скорборд
        if IsValid(CustomizationPanel) then
            CustomizationPanel:Remove()
            CustomizationPanel = nil
        end
        -- Гарантированно закрываем меню выбора команды при переходе к скорборду
        TeamSelectMenuOpen = false
        TeamSelectMenuTargetAlpha = 0
        TeamSelectMenuCursorEnabled = false
        -- Всегда открываем скорборд при нажатии этой кнопки
        TabHudTargetAlpha = 1
        PoliceTimerTargetAlpha = 1
        ScoreboardTargetAlpha = 1
        ScoreboardAlpha = 0
        gui.EnableScreenClicker(true)
        ScoreboardScrollOffset = 0
        ScoreboardScrollTarget = 0
        net.Start("Homigrad_ScoreboardData")
        net.SendToServer()
        return
    end

    -- Проверяем клик по кнопке кастомизации
    local custBtnY = teamButtonY + buttonSize + 10
    local custBtnW, custBtnH = buttonSize, buttonSize
    local isHoveringCust = mx >= buttonX and mx <= buttonX + custBtnW and my >= custBtnY and my <= custBtnY + custBtnH
    if isHoveringCust and (CurTime() - LastCustomizationClick) > 0.2 then
        LastCustomizationClick = CurTime()
        print("[Homigrad|Client] Opening customization panel (PlayerButtonDown)")
        -- Закрываем меню выбора команды при переходе в кастомизацию
        TeamSelectMenuOpen = false
        TeamSelectMenuTargetAlpha = 0
        TeamSelectMenuCursorEnabled = false
        OpenCustomizationPanel(boardX, boardY, boardWidth, boardHeight)
        -- При открытии кастомизации скрываем скорборд
        TabHudTargetAlpha = 0
        ScoreboardTargetAlpha = 0
        ScoreboardAlpha = 0
        return
    end

    local mouseX, mouseY = gui.MousePos()
    if mouseX >= buttonX and mouseX <= buttonX + buttonSize and
       mouseY >= scoreboardButtonY and mouseY <= scoreboardButtonY + buttonSize then
        -- Закрываем меню выбора команды если открыто
        TeamSelectMenuOpen = false
        TeamSelectMenuTargetAlpha = 0
        TeamSelectMenuCursorEnabled = false
        -- Всегда открываем scoreboard
        TabHudTargetAlpha = 1
        PoliceTimerTargetAlpha = 1
        ScoreboardTargetAlpha = 1
        ScoreboardAlpha = 0 -- Устанавливаем начальное значение для плавного появления
        gui.EnableScreenClicker(true)
        ScoreboardScrollOffset = 0
        ScoreboardScrollTarget = 0
        net.Start("Homigrad_ScoreboardData")
        net.SendToServer()
    end
end)

-- Обработка кликов по кнопке выбора команды в JailBreak
hook.Add("PlayerButtonDown", "Homigrad_TeamSelectButton", function(ply, button)
    if ply ~= LocalPlayer() then return end
    if button ~= MOUSE_LEFT then return end
    
    local currentMode = ply.HomigradSubmode or ""
    local modeLower = string.lower(currentMode)
    if modeLower ~= "jailbreak" then return end
    if ScoreboardAlpha <= 0 then return end
    if TeamSelectMenuOpen then return end
    
    -- Проверяем клик по кнопке
    local scrW, scrH = ScrW(), ScrH()
    local boardWidth = math.min(1400, scrW * 0.9)
    local boardHeight = math.min(850, scrH * 0.9)
    local boardX = (scrW - boardWidth) / 2
    local boardY = (scrH - boardHeight) / 2
    
    local buttonSize = 60 -- Квадратная кнопка
    local buttonX = scrW - buttonSize - 20 -- Справа прилегая к краю экрана
    local buttonY = boardY + boardHeight / 2 - buttonSize / 2 -- По центру вертикально
    
    local mouseX, mouseY = gui.MousePos()
    if mouseX >= buttonX and mouseX <= buttonX + buttonSize and
       mouseY >= buttonY and mouseY <= buttonY + buttonSize then
        -- Открываем меню выбора команды и закрываем ScoreBoard
        TeamSelectMenuOpen = true
        TeamSelectMenuTargetAlpha = 1
        TeamSelectMenuCursorEnabled = false -- Сброс флага, курсор включится автоматически в хуке HUDPaint
        -- Закрываем ScoreBoard
        TabHudTargetAlpha = 0
        ScoreboardTargetAlpha = 0
        ScoreboardAlpha = 0
    end
end)

-- Переменные для админ-меню
local AdminMenuOpen = false
local AdminMenuAlpha = 0
local AdminMenuTargetAlpha = 0
local AvailableModes = {}
local LastButtonClick = 0
local LastButtonAction = 0
local ShowModesList = false
local ModeListOpen = false
local ModeListAlpha = 0
local ModeListTargetAlpha = 0
local ModeListScrollOffset = 0
local ModeListScrollTarget = 0
local ModeListScrollSpeed = 15

-- Обработка нажатия F6
hook.Add("PlayerButtonDown", "Homigrad_AdminMenu", function(ply, button)
    if ply ~= LocalPlayer() then return end
    
    -- Проверяем, что игрок - администратор
    if not ply:IsAdmin() then return end
    
    if button == KEY_F6 and (CurTime() - LastButtonClick) > 0.3 then
        LastButtonClick = CurTime()
        
        -- Если открыто меню выбора режима, закрываем его по F6 и не трогаем админ-меню
        if ModeListOpen then
            ModeListOpen = false
            ModeListTargetAlpha = 0
            gui.EnableScreenClicker(false)
            return
        end
        
        if not AdminMenuOpen then
            AdminMenuOpen = true
            AdminMenuTargetAlpha = 1
            gui.EnableScreenClicker(true)
            
            -- При открытии меню прячем список режимов
            ShowModesList = false
            ModeListOpen = false
            ModeListTargetAlpha = 0
        else
            AdminMenuOpen = false
            AdminMenuTargetAlpha = 0
            gui.EnableScreenClicker(false)
        end
    end
end)

-- Закрытие меню при нажатии Escape
hook.Add("OnPlayerChat", "Homigrad_AdminMenuClose", function(ply, text)
    if ply ~= LocalPlayer() then return end
    if AdminMenuOpen and (text == "!close" or text == "/close") then
        AdminMenuOpen = false
        AdminMenuTargetAlpha = 0
        gui.EnableScreenClicker(false)
        return true
    end
end)

-- Получение списка доступных режимов
net.Receive("Homigrad_AdminGetAvailableModes", function()
    AvailableModes = net.ReadTable()
end)

-- Обновление альфа-канала для админ-меню
hook.Add("Think", "Homigrad_AdminMenuFade", function()
    local diff = AdminMenuTargetAlpha - AdminMenuAlpha
    AdminMenuAlpha = AdminMenuAlpha + diff * FrameTime() * 5
end)

-- Плавное появление/исчезновение меню выбора режима
hook.Add("Think", "Homigrad_ModeListFade", function()
    local diff = ModeListTargetAlpha - ModeListAlpha
    ModeListAlpha = ModeListAlpha + diff * FrameTime() * 8
end)

-- Отрисовка админ-меню
hook.Add("HUDPaint", "Homigrad_AdminMenu", function()
    if AdminMenuAlpha <= 0 then return end
    
    local ply = LocalPlayer()
    if not IsValid(ply) or not ply:IsAdmin() then return end
    
    local alpha = AdminMenuAlpha
    local scrW, scrH = ScrW(), ScrH()
    
    -- Затемнение фона
    draw.RoundedBox(0, 0, 0, scrW, scrH, Color(0, 0, 0, 150 * alpha))
    
    -- Основное окно меню
    local menuWidth = 400
    local menuHeight = 300
    local menuX = (scrW - menuWidth) / 2
    local menuY = (scrH - menuHeight) / 2
    
    -- Фон меню
    draw.RoundedBox(8, menuX, menuY, menuWidth, menuHeight, Color(40, 40, 40, 240 * alpha))
    
    -- Рамка
    surface.SetDrawColor(100, 100, 100, 255 * alpha)
    surface.DrawOutlinedRect(menuX, menuY, menuWidth, menuHeight)
    
    -- Заголовок
    draw.SimpleText("АДМИН-МЕНЮ", "HomigradLarge", menuX + menuWidth / 2, menuY + 20, Color(255, 215, 0, 255 * alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
    
    -- Кнопка "Завершить раунд"
    local buttonY = menuY + 70
    local buttonHeight = 40
    local mouseX, mouseY = gui.MouseX(), gui.MouseY()
    local isEndRoundHovered = mouseX >= menuX + 20 and mouseX <= menuX + menuWidth - 20 and
                              mouseY >= buttonY and mouseY <= buttonY + buttonHeight
    
    local endRoundColor = Color(150, 50, 50, 200 * alpha)
    if isEndRoundHovered then
        endRoundColor = Color(200, 60, 60, 255 * alpha)
    end
    
    draw.RoundedBox(4, menuX + 20, buttonY, menuWidth - 40, buttonHeight, endRoundColor)
    draw.SimpleText("ЗАВЕРШИТЬ РАУНД", "HomigradLarge", menuX + menuWidth / 2, buttonY + buttonHeight / 2, Color(255, 255, 255, 255 * alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    
    -- Обработка клика по кнопке "Завершить раунд"
    if AdminMenuOpen and isEndRoundHovered and input.IsMouseDown(MOUSE_LEFT) and (CurTime() - LastButtonAction) > 0.5 then
        LastButtonAction = CurTime()
        net.Start("Homigrad_AdminEndRound")
        net.SendToServer()
        
        -- Закрываем меню после действия
        AdminMenuOpen = false
        AdminMenuTargetAlpha = 0
        gui.EnableScreenClicker(false)
    end
    
    -- Вторая кнопка: "Изменить режим" (открывает отдельное меню выбора)
    local changeButtonY = buttonY + buttonHeight + 10
    local isChangeHovered = mouseX >= menuX + 20 and mouseX <= menuX + menuWidth - 20 and
                            mouseY >= changeButtonY and mouseY <= changeButtonY + buttonHeight
    local changeColor = Color(50, 100, 150, 200 * alpha)
    if isChangeHovered then
        changeColor = Color(80, 140, 200, 255 * alpha)
    end
    draw.RoundedBox(4, menuX + 20, changeButtonY, menuWidth - 40, buttonHeight, changeColor)
    draw.SimpleText("СЛЕДУЮЩИЙ РЕЖИМ", "HomigradLarge", menuX + menuWidth / 2, changeButtonY + buttonHeight / 2, Color(255, 255, 255, 255 * alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    
    if AdminMenuOpen and isChangeHovered and input.IsMouseDown(MOUSE_LEFT) and (CurTime() - LastButtonAction) > 0.5 then
        LastButtonAction = CurTime()
        -- Открываем меню выбора режимов
        ModeListOpen = true
        ModeListTargetAlpha = 1
        ModeListScrollOffset = 0
        ModeListScrollTarget = 0
        -- Закрываем админ-меню при открытии выбора режимов
        AdminMenuOpen = false
        AdminMenuTargetAlpha = 0
        -- Обновляем список доступных режимов при открытии
        net.Start("Homigrad_AdminGetAvailableModes")
        net.SendToServer()
    end

    
    -- Подсказка внизу
    draw.SimpleText("Нажмите F6 для закрытия", "ScoreboardButton", menuX + menuWidth / 2, menuY + menuHeight - 30, Color(150, 150, 150, 200 * alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end)

-- Отдельное меню выбора режима (только список названий + прокрутка)
hook.Add("HUDPaint", "Homigrad_ModeListMenu", function()
    if ModeListAlpha <= 0 then return end
    if not ModeListOpen then return end
    
    local ply = LocalPlayer()
    if not IsValid(ply) or not ply:IsAdmin() then return end
    
    local alpha = ModeListAlpha
    local scrW, scrH = ScrW(), ScrH()
    
    -- Затемнение фона (сильнее, чтобы выделить отдельное меню)
    draw.RoundedBox(0, 0, 0, scrW, scrH, Color(0, 0, 0, 180 * alpha))
    
    -- Размеры окна
    local menuWidth = 460
    local menuHeight = math.min(520, scrH * 0.8)
    local menuX = (scrW - menuWidth) / 2
    local menuY = (scrH - menuHeight) / 2
    
    -- Фон меню
    draw.RoundedBox(8, menuX, menuY, menuWidth, menuHeight, Color(35, 35, 35, 240 * alpha))
    surface.SetDrawColor(120, 120, 120, 255 * alpha)
    surface.DrawOutlinedRect(menuX, menuY, menuWidth, menuHeight)
    
    -- Заголовок
    draw.SimpleText("ВЫБОР РЕЖИМА", "HomigradLarge", menuX + menuWidth / 2, menuY + 18, Color(255, 215, 0, 255 * alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
    
    local mouseX, mouseY = gui.MouseX(), gui.MouseY()
    local buttonHeight = 40
    
    -- Кнопка Назад (снизу по центру)
    local backButtonWidth = 140
    local backY = menuY + menuHeight - 20 - buttonHeight
    local backX = menuX + (menuWidth - backButtonWidth) / 2
    local isBackHovered = mouseX >= backX and mouseX <= backX + backButtonWidth and mouseY >= backY and mouseY <= backY + buttonHeight
    local backColor = isBackHovered and Color(200, 60, 60, 255 * alpha) or Color(150, 50, 50, 200 * alpha)
    draw.RoundedBox(4, backX, backY, backButtonWidth, buttonHeight, backColor)
    draw.SimpleText("НАЗАД", "ScoreboardButton", backX + backButtonWidth / 2, backY + buttonHeight / 2, Color(255, 255, 255, 255 * alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    if isBackHovered and input.IsMouseDown(MOUSE_LEFT) and (CurTime() - LastButtonAction) > 0.5 then
        LastButtonAction = CurTime()
        ModeListOpen = false
        ModeListTargetAlpha = 0
        -- Открываем обратно админ-меню
        AdminMenuOpen = true
        AdminMenuTargetAlpha = 1
        gui.EnableScreenClicker(true)
    end
    
    -- Область списка
    local listTop = menuY + 60
    -- Список не должен заходить на кнопку назад: ограничим низ на 10px выше кнопки
    local listHeight = (backY - 10) - listTop
    local listX = menuX + 20
    local listW = menuWidth - 40
    
    -- Фон списка
    draw.RoundedBox(6, listX, listTop, listW, listHeight, Color(25, 25, 25, 230 * alpha))
    surface.SetDrawColor(90, 90, 90, 200 * alpha)
    surface.DrawOutlinedRect(listX, listTop, listW, listHeight)
    
    -- Прокрутка: расчет
    local itemHeight = 36
    local totalHeight = #AvailableModes * itemHeight
    local maxScroll = math.max(0, totalHeight - listHeight)
    if ModeListScrollTarget > maxScroll then ModeListScrollTarget = maxScroll end
    if ModeListScrollTarget < 0 then ModeListScrollTarget = 0 end
    local scrollDiff = ModeListScrollTarget - ModeListScrollOffset
    ModeListScrollOffset = ModeListScrollOffset + scrollDiff * FrameTime() * ModeListScrollSpeed
    
    -- Маска отрисовки (ручной клип)
    local oldScissor = render.EnableScissorRect
    render.SetScissorRect(listX, listTop, listX + listW, listTop + listHeight, true)
    
    -- Рисуем элементы списка
    local mouseOverIndex = nil
    for i, mode in ipairs(AvailableModes) do
        local y = listTop + (i - 1) * itemHeight - ModeListScrollOffset
        if y + itemHeight >= listTop and y <= listTop + listHeight then
            local hovered = mouseX >= listX and mouseX <= listX + listW and mouseY >= y and mouseY <= y + itemHeight
            local rowColor = hovered and Color(60, 120, 200, 220 * alpha) or Color(45, 45, 45, 200 * alpha)
            draw.RoundedBox(2, listX + 2, y + 2, listW - 4, itemHeight - 4, rowColor)
            draw.SimpleText(string.upper(mode.name or mode.id or "UNKNOWN"), "ScoreboardPlayerName", listX + 12, y + itemHeight / 2, Color(255, 255, 255, 255 * alpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            if hovered then mouseOverIndex = i end
        end
    end
    
    -- Отключаем клип
    render.SetScissorRect(0, 0, 0, 0, false)
    
    -- Обработка клика по элементу
    if mouseOverIndex and input.IsMouseDown(MOUSE_LEFT) and (CurTime() - LastButtonAction) > 0.5 then
        LastButtonAction = CurTime()
        local mode = AvailableModes[mouseOverIndex]
        if mode and mode.id then
            net.Start("Homigrad_AdminSelectNextMode")
                net.WriteString(mode.id)
            net.SendToServer()
            -- Закрываем оба меню
            AdminMenuOpen = false
            AdminMenuTargetAlpha = 0
            ModeListOpen = false
            ModeListTargetAlpha = 0
            gui.EnableScreenClicker(false)
        end
    end
end)

-- Прокрутка колесиком в меню выбора режима
hook.Add("PlayerButtonDown", "Homigrad_ModeListScroll", function(ply, button)
    if ply ~= LocalPlayer() then return end
    if not ModeListOpen or ModeListAlpha <= 0 then return end
    if button == KEY_WHEEL_UP or button == MOUSE_WHEEL_UP then
        ModeListScrollTarget = math.max(0, ModeListScrollTarget - 60)
    elseif button == KEY_WHEEL_DOWN or button == MOUSE_WHEEL_DOWN then
        ModeListScrollTarget = ModeListScrollTarget + 60
    end
end)

-- Отображение меню выбора команды для JailBreak
hook.Add("HUDPaint", "Homigrad_TeamSelectMenu", function()
    if TeamSelectMenuAlpha <= 0 then 
        TeamSelectMenuOpen = false
        if TeamSelectMenuCursorEnabled and ScoreboardAlpha <= 0 then
            gui.EnableScreenClicker(false)
            TeamSelectMenuCursorEnabled = false
        end
        return 
    end
    
    local ply = LocalPlayer()
    if not IsValid(ply) then return end
    
    local currentMode = ply.HomigradSubmode or ""
    local modeLower = string.lower(currentMode)
    
    -- Включаем курсор только один раз при открытии меню
    if TeamSelectMenuOpen and not TeamSelectMenuCursorEnabled then
        gui.EnableScreenClicker(true)
        TeamSelectMenuCursorEnabled = true
    end
    
    local alpha = TeamSelectMenuAlpha
    local scrW, scrH = ScrW(), ScrH()
    
    -- Размеры меню
    local menuWidth = 400
    local menuHeight = (modeLower == "jailbreak") and 320 or 180
    local menuX = (scrW - menuWidth) / 2
    local menuY = (scrH - menuHeight) / 2
    
    -- Фон меню
    draw.RoundedBox(8, menuX, menuY, menuWidth, menuHeight, Color(40, 40, 40, 240 * alpha))
    
    -- Рамка
    surface.SetDrawColor(100, 100, 100, 255 * alpha)
    surface.DrawOutlinedRect(menuX, menuY, menuWidth, menuHeight)
    
    -- Заголовок
    draw.SimpleText("ВЫБОР КОМАНДЫ", "HomigradLarge", menuX + menuWidth / 2, menuY + 20, Color(255, 255, 255, 255 * alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
    
    local buttonHeight = 50
    local buttonSpacing = 15
    local mouseX, mouseY = gui.MouseX(), gui.MouseY()
    
    local optionsStartY = menuY + 70
    local currentTeam = ply:GetNWString("HomigradTeam", "")
    local mouseX, mouseY = gui.MouseX(), gui.MouseY()

    local function drawButton(x, y, w, h, bgColor, text, hover)
        draw.RoundedBox(4, x, y, w, h, bgColor)
        surface.SetDrawColor(150, 150, 150, 255 * alpha)
        surface.DrawOutlinedRect(x, y, w, h)
        draw.SimpleText(text, "ScoreboardButton", x + w / 2, y + h / 2, Color(255,255,255,255 * alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    local clicked = input.IsMouseDown(MOUSE_LEFT) and (CurTime() - LastTeamSelectClick) > 0.5

    if modeLower == "jailbreak" then
        -- Prisoners
        local prisonerButtonY = optionsStartY
        local prisonerButtonX = menuX + 20
        local prisonerButtonWidth = menuWidth - 40
        local isPrisonerHovered = mouseX >= prisonerButtonX and mouseX <= prisonerButtonX + prisonerButtonWidth and
                                 mouseY >= prisonerButtonY and mouseY <= prisonerButtonY + buttonHeight
        local prisonerColor = isPrisonerHovered and Color(255, 100, 10, 200 * alpha) or Color(255, 100, 10, 180 * alpha)
        drawButton(prisonerButtonX, prisonerButtonY, prisonerButtonWidth, buttonHeight, prisonerColor, "ЗАКЛЮЧЁННЫЕ", isPrisonerHovered)

        -- Guards with capacity
        local guardButtonY = prisonerButtonY + buttonHeight + buttonSpacing
        local guardButtonX = menuX + 20
        local guardButtonWidth = menuWidth - 40
        local isGuardHovered = mouseX >= guardButtonX and mouseX <= guardButtonX + guardButtonWidth and
                              mouseY >= guardButtonY and mouseY <= guardButtonY + buttonHeight

        local guardsCount, prisonersCount = 0, 0
        for _, p in ipairs(player.GetAll()) do
            if IsValid(p) and p:Alive() then
                local t = p:GetNWString("HomigradTeam", "")
                if t == "guards" then guardsCount = guardsCount + 1 end
                if t == "prisoners" then prisonersCount = prisonersCount + 1 end
            end
        end
        local totalPlayers = #player.GetAll()
        local maxGuards = (totalPlayers <= 6) and 1 or (totalPlayers <= 12) and 2 or (totalPlayers <= 18) and 3 or 4
        local canBeGuard = guardsCount < maxGuards or currentTeam == "guards"
        local guardColor = canBeGuard and (isGuardHovered and Color(16, 0, 255, 200 * alpha) or Color(16, 0, 255, 180 * alpha)) or Color(80, 80, 80, 120 * alpha)
        local guardText = canBeGuard and "ОХРАННИКИ" or "ОХРАННИКИ (НЕТ МЕСТА)"
        drawButton(guardButtonX, guardButtonY, guardButtonWidth, buttonHeight, guardColor, guardText, isGuardHovered)

        -- Spectators option
        local specButtonY = guardButtonY + buttonHeight + buttonSpacing
        local specButtonX = menuX + 20
        local specButtonWidth = menuWidth - 40
        local isSpecHovered = mouseX >= specButtonX and mouseX <= specButtonX + specButtonWidth and
                              mouseY >= specButtonY and mouseY <= specButtonY + buttonHeight
        local specColor = isSpecHovered and Color(160,160,160, 200 * alpha) or Color(120,120,120, 180 * alpha)
        drawButton(specButtonX, specButtonY, specButtonWidth, buttonHeight, specColor, "НАБЛЮДАТЕЛИ", isSpecHovered)

        if clicked then
            LastTeamSelectClick = CurTime()
            if isPrisonerHovered then
                net.Start("Homigrad_SelectTeam") net.WriteString("prisoners") net.SendToServer()
            elseif isGuardHovered and canBeGuard then
                net.Start("Homigrad_SelectTeam") net.WriteString("guards") net.SendToServer()
            elseif isSpecHovered then
                net.Start("Homigrad_SelectTeam") net.WriteString("spectators") net.SendToServer()
            end
            TeamSelectMenuOpen = false
            TeamSelectMenuTargetAlpha = 0
            if TeamSelectMenuCursorEnabled and ScoreboardAlpha <= 0 then
                gui.EnableScreenClicker(false)
                TeamSelectMenuCursorEnabled = false
            end
        end
    else
        -- Non-JailBreak: only Spectators
        -- Green "ИГРОКИ" button to exit spectator
        local playersButtonY = optionsStartY
        local playersButtonX = menuX + 20
        local playersButtonWidth = menuWidth - 40
        local isPlayersHovered = mouseX >= playersButtonX and mouseX <= playersButtonX + playersButtonWidth and
                                 mouseY >= playersButtonY and mouseY <= playersButtonY + buttonHeight
        local playersColor = isPlayersHovered and Color(40, 160, 40, 220 * alpha) or Color(30, 130, 30, 200 * alpha)
        drawButton(playersButtonX, playersButtonY, playersButtonWidth, buttonHeight, playersColor, "ИГРОКИ", isPlayersHovered)

        -- Spectators button below
        local specButtonY = playersButtonY + buttonHeight + buttonSpacing
        local specButtonX = menuX + 20
        local specButtonWidth = menuWidth - 40
        local isSpecHovered = mouseX >= specButtonX and mouseX <= specButtonX + specButtonWidth and
                              mouseY >= specButtonY and mouseY <= specButtonY + buttonHeight
        local specColor = isSpecHovered and Color(160,160,160, 200 * alpha) or Color(120,120,120, 180 * alpha)
        drawButton(specButtonX, specButtonY, specButtonWidth, buttonHeight, specColor, "НАБЛЮДАТЕЛИ", isSpecHovered)

        if clicked then
            LastTeamSelectClick = CurTime()
            if isPlayersHovered then
                net.Start("Homigrad_SelectTeam") net.WriteString("players") net.SendToServer()
            elseif isSpecHovered then
                net.Start("Homigrad_SelectTeam") net.WriteString("spectators") net.SendToServer()
            end
            TeamSelectMenuOpen = false
            TeamSelectMenuTargetAlpha = 0
            if TeamSelectMenuCursorEnabled and ScoreboardAlpha <= 0 then
                gui.EnableScreenClicker(false)
                TeamSelectMenuCursorEnabled = false
            end
        end
    end
end)

-- Закрытие меню выбора команды по Escape
hook.Add("PlayerButtonDown", "Homigrad_TeamSelectMenuClose", function(ply, button)
    if ply ~= LocalPlayer() then return end
    if button == KEY_ESCAPE and TeamSelectMenuOpen then
        TeamSelectMenuOpen = false
        TeamSelectMenuTargetAlpha = 0
        TeamSelectMenuCursorEnabled = false
        -- Возвращаемся к ScoreBoard если Tab был зажат
        -- Проверяем, был ли открыт ScoreBoard до открытия меню
        TabHudTargetAlpha = 1
        PoliceTimerTargetAlpha = 1
        ScoreboardTargetAlpha = 1
        ScoreboardAlpha = 0 -- Устанавливаем начальное значение для плавного появления
        -- Включаем курсор для ScoreBoard
        gui.EnableScreenClicker(true)
        -- Сбрасываем смещение прокрутки при открытии
        ScoreboardScrollOffset = 0
        ScoreboardScrollTarget = 0
        -- Запрашиваем актуальные данные ScoreBoard
        net.Start("Homigrad_ScoreboardData")
        net.SendToServer()
    end
end)