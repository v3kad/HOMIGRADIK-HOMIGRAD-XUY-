SubmodeConfig = SubmodeConfig or {}

SubmodeConfig = {}
SubmodeConfig.Sequence = {
    {id = "tdm", duration = 180},
    {id = "dm", duration = 180},
    {id = "riot", duration = 300},
    {id = "school", duration = 180},
    {id = "homicide", duration = 420}, -- Homicide ends after 7 minutes, or when traitor dies, or when all others die
    {id = "jailbreak", duration = 600} -- JailBreak режим, доступен только на картах jb_*
}

SubmodeConfig.DefaultRespawn = 5
SubmodeConfig.BroadcastInterval = 1

-- Конфигурация точек спавна для каждого режима
SubmodeConfig.SpawnPoints = {
    dm = {
        "dm_dm"
    },
    riot = {
        "riot_rioters",
        "riot_police"
    },
    school = {
        "school_victims",
        "school_shooters",
        "school_police"
    },
    homicide = {
        "hmcd_homicide",
        "hmcd_police"
    },
    tdm = {
        "tdm_swat",
        "tdm_terrorists"
    },
    jailbreak = {
        "jb_guards",
        "jb_prisoners"
    },
    event = {
        "event"
    }
}