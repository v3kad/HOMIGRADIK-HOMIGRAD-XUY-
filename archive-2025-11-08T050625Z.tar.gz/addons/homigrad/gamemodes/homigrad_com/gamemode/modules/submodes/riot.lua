-- gamemodes/homigrad/gamemode/submodes/riot.lua
Riot = {}
Riot.__homigrad_id = "riot"
Riot.Name = "Riot"
Riot.Duration = 300 -- 5 минут

Riot.PoliceModels = {
    "models/player/kerry/policeru_01_patrol.mdl",
    "models/player/kerry/policeru_02_patrol.mdl",
    "models/player/kerry/policeru_03_patrol.mdl",
    "models/player/kerry/policeru_04_patrol.mdl",
    "models/player/kerry/policeru_05_patrol.mdl",
    "models/player/kerry/policeru_06_patrol.mdl",
    "models/player/kerry/policeru_07_patrol.mdl"
}

Riot.RebelModels = {
	"models/player/Group01/male_01.mdl",
	"models/player/Group01/male_02.mdl",
	"models/player/Group01/male_03.mdl",
	"models/player/Group01/male_04.mdl",
	"models/player/Group01/male_05.mdl",
	"models/player/Group01/male_06.mdl",
	"models/player/Group01/male_07.mdl",
	"models/player/Group01/male_08.mdl",
	"models/player/Group01/male_09.mdl",
	"models/player/Group01/female_01.mdl",
	"models/player/Group01/female_02.mdl",
	"models/player/Group01/female_03.mdl",
	"models/player/Group01/female_04.mdl",
	"models/player/Group01/female_06.mdl"
}

function Riot:Start()
    print("[Homigrad|Riot] Round started!")
    
    -- Устанавливаем hostname для режима Riot
    RunConsoleCommand("hostname", "HOMIGRAD XUY Riot")
    
    -- Проигрываем звук начала режима Riot всем игрокам
    if SERVER then
        for _, ply in ipairs(player.GetAll()) do
            if IsValid(ply) then
                ply:EmitSound("riot.wav")
            end
        end
    end
    
    -- Разделяем игроков на команды с равным распределением
    local players = player.GetAll()
    local totalPlayers = #players
    
    if totalPlayers == 0 then
        print("[Homigrad|Riot] No players to assign teams!")
        return
    end
    
    -- Вычисляем количество игроков для каждой команды
    local rebelsCount = math.floor(totalPlayers / 2)
    local policeCount = totalPlayers - rebelsCount
    
    print("[Homigrad|Riot] Assigning teams: " .. rebelsCount .. " rebels, " .. policeCount .. " police")
    
    -- Перемешиваем список игроков для случайного распределения
    local shuffledPlayers = {}
    for i = 1, totalPlayers do
        shuffledPlayers[i] = players[i]
    end
    
    -- Алгоритм Фишера-Йетса для перемешивания
    for i = totalPlayers, 2, -1 do
        local j = math.random(i)
        shuffledPlayers[i], shuffledPlayers[j] = shuffledPlayers[j], shuffledPlayers[i]
    end
    
    -- Назначаем команды
    for i, ply in ipairs(shuffledPlayers) do
        if i <= rebelsCount then
            -- Первая половина - бунтующие
            ply:SetTeam(1) -- Rebels
            ply:SetNWString("HomigradTeam", "rebels")
            ply:SetModel(table.Random(self.RebelModels))
        else
            -- Вторая половина - полиция
            ply:SetTeam(2) -- Police
            ply:SetNWString("HomigradTeam", "police")
            ply:SetModel(table.Random(self.PoliceModels))
        end
        ply:StripWeapons()
        ply:Give("weapon_hg_metalbat") -- стандартное оружие
    end
    
    -- Сбрасываем флаг оповещения о победителе на случай повторного старта
    self._announcedWinner = false

    print("[Homigrad|Riot] Team assignment completed!")
end

function Riot:PlayerSpawn(ply)
    local teamName = ply:GetNWString("HomigradTeam") or "rebels"
    print("[Riot] Player spawning as: " .. tostring(teamName))
    
    -- Устанавливаем сетевую переменную для отображения команды на клиенте
    local teamDisplayName = teamName == "rebels" and "Бунтующие" or "Полиция"
    ply:SetNWString("CurrentTeamDisplay", teamDisplayName)
    ply:SetNWFloat("SpawnTime", CurTime()) -- Время спавна для отслеживания 10 секунд
    
    -- Проверяем, это начало раунда или обычный спавн
    if SubmodeManager and SubmodeManager.isRoundStart then
        -- В начале раунда игроки спавнятся живыми
        print("[Riot] Round start - player spawning alive")
        local spawns = HOMIGRAD_GetSpawnPoints(teamName)
        print("[Riot] Found " .. #spawns .. " spawn points for " .. tostring(teamName))
        if #spawns > 0 then
            ply:SetPos(table.Random(spawns))
            print("[Riot] Spawning player alive at: " .. tostring(ply:GetPos()))
        else
            print("[Riot] No spawn points found, using fallback position")
            ply:SetPos(Vector(0,0,100))
        end
    else
        -- При обычном спавне игроки остаются мертвыми
        print("[Riot] Normal spawn - player stays dead")
        local spawns = HOMIGRAD_GetSpawnPoints(teamName)
        print("[Riot] Found " .. #spawns .. " spawn points for " .. tostring(teamName))
        if #spawns > 0 then
            ply:SetPos(table.Random(spawns))
            print("[Riot] Setting observer position at: " .. tostring(ply:GetPos()))
        else
            print("[Riot] No spawn points found, using fallback position")
            ply:SetPos(Vector(0,0,100))
        end
        
        -- Убеждаемся, что игрок остается в режиме наблюдателя
        ply:Spectate(OBS_MODE_ROAMING)
        ply:SetMoveType(MOVETYPE_OBSERVER)
    end

    -- Equip armor for police in Riot
    if teamName == "police" then
        if HG_GiveVestByModel then
            HG_GiveVestByModel(ply, "models/eft_props/gear/armor/ar_thor_crv.mdl")
        end
    end
end

-- Цель 1: Проверка на уничтожение команды
function Riot:CheckRoundEnd()
    local players = player.GetAll()
    local rebelsAlive = 0
    local policeAlive = 0

    for _, ply in ipairs(players) do
        if ply:Alive() then
            local team = ply:GetNWString("HomigradTeam")
            if team == "rebels" then
                rebelsAlive = rebelsAlive + 1
            elseif team == "police" then
                policeAlive = policeAlive + 1
            end
        end
    end

    -- Если в одной из команд 0 живых игроков, завершаем раунд
    if rebelsAlive == 0 or policeAlive == 0 then
        local winner = "Никто"
        if rebelsAlive > 0 then
            winner = "Бунтующие"
        elseif policeAlive > 0 then
            winner = "Полиция"
        end
        print("[Homigrad|Riot] Round ended! Winners: " .. winner)

        -- Гарантируем отправку сообщения клиентам сразу при определении победителя,
        -- даже до вызова Riot:End() менеджером, чтобы HUD всегда появился.
        if not self._announcedWinner then
            self._announcedWinner = true
            local ok, err = pcall(function()
                if HG_Armor_RoundEndCleanup then HG_Armor_RoundEndCleanup() end
                net.Start("Homigrad_RoundEnd")
                    net.WriteString("riot")
                    net.WriteString(winner)
                    net.WriteString("")
                net.Broadcast()
            end)
            if ok then
                print("[Homigrad|Riot] (CheckRoundEnd) Winner announcement broadcasted: " .. winner)
            else
                print("[Homigrad|Riot] (CheckRoundEnd) ERROR broadcasting winner: " .. tostring(err))
            end
        end

        return true -- Да, завершаем раунд
    end

    return false -- Нет, продолжаем
end

function Riot:End()
    print("[Homigrad|Riot] Round ended!")
    
    -- Подсчитываем результаты
    local players = player.GetAll()
    local rebelsAlive = 0
    local policeAlive = 0
    
    for _, ply in ipairs(players) do
        if ply:Alive() then
            local team = ply:GetNWString("HomigradTeam")
            if team == "rebels" then
                rebelsAlive = rebelsAlive + 1
            elseif team == "police" then
                policeAlive = policeAlive + 1
            end
        end
    end
    
    -- Определяем победителя
    local winner = "Ничья"
    if rebelsAlive == 0 then
        winner = "Полиция"
    elseif policeAlive == 0 then
        winner = "Бунтующие"
    end
    
    -- Отправляем информацию о победителе на клиент для отображения прямоугольника
    print("[Homigrad|Riot] Sending network message to clients...")
    print("[Homigrad|Riot] Mode: riot, Winner: " .. winner)
    
    local success, err = pcall(function()
        if HG_Armor_RoundEndCleanup then HG_Armor_RoundEndCleanup() end
        net.Start("Homigrad_RoundEnd")
            net.WriteString("riot")
            net.WriteString(winner)
            net.WriteString("") -- Пустая строка для совместимости с homicide
        net.Broadcast()
    end)
    
    if success then
        print("[Homigrad|Riot] Winner announcement sent successfully: " .. winner)
    else
        print("[Homigrad|Riot] ERROR sending network message: " .. tostring(err))
    end
end