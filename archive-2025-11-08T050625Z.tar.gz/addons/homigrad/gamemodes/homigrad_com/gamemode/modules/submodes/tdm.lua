-- gamemodes/homigrad/gamemode/modules/submodes/tdm.lua
TDM = {}
TDM.__homigrad_id = "tdm"
TDM.Name = "Team DeathMatch"
TDM.Duration = 180 -- 3 минуты отображения таймера, но таймер не завершает раунд
TDM.IgnoreTimer = true -- Раунд заканчивается только при полном уничтожении одной из команд

local COLOR_SWAT = Vector(0/255, 185/255, 255/255)
local COLOR_TERROR = Vector(255/255, 0/255, 0/255)

TDM.SWATModel = "models/css_seb_swat/css_swat.mdl"
TDM.TErrorModel = "models/playermodels/t2_mp.mdl"

-- Названия групп спавна (через homigrad_spawnpoint)
TDM.SpawnTypeSWAT = "tdm_swat"
TDM.SpawnTypeTERROR = "tdm_terrorists"

function TDM:Start()
    RunConsoleCommand("hostname", "HOMIGRAD XUY Team DeathMatch")

    local players = player.GetAll()
    if SERVER and HG_ResetAllInventories then HG_ResetAllInventories() end
    if #players == 0 then return end

    -- Звук начала раунда для всех игроков
    if SERVER then
        for _, ply in ipairs(players) do
            if IsValid(ply) then
                ply:EmitSound("csgo_round.wav")
            end
        end
    end

    -- Перемешиваем игроков и делим пополам
    local shuffled = table.Copy(players)
    for i = #shuffled, 2, -1 do
        local j = math.random(i)
        shuffled[i], shuffled[j] = shuffled[j], shuffled[i]
    end

    local half = math.floor(#shuffled / 2)
    for i, ply in ipairs(shuffled) do
        if not IsValid(ply) then continue end
        ply:StripWeapons()
        if i <= half then
            -- Спецназ
            ply:SetTeam(1)
            ply:SetNWString("HomigradTeam", "swat")
            ply:SetModel(self.SWATModel)
        else
            -- Террористы
            ply:SetTeam(2)
            ply:SetNWString("HomigradTeam", "terrorists")
            ply:SetModel(self.TErrorModel)
        end
    end

    self._announcedWinner = false
end

local function giveTDMLoadout(ply)
    if not IsValid(ply) then return end

    local teamName = ply:GetNWString("HomigradTeam")
    if SERVER and HG_ClearPlayerInventory then HG_ClearPlayerInventory(ply) end
    ply:StripWeapons()

    -- Общие предметы
    ply:Give("weapon_hg_bandage")
    ply:Give("weapon_hg_painkiller")
    ply:Give("weapon_grenade_f1")
    
    -- АКМ + 3 магазина кастомных патронов Homigrad (калибр 7x62, по 30)
    ply:Give("weapon_akm")
    do
        local function _hgGiveAmmoItem(caliber, amount)
            local item = { name = tostring(caliber), kind = "ammo", caliber = caliber, amount = amount, icon = nil, entClass = nil }
            if caliber == "9x19" then
                item.icon = "homigrad/9x19.png"; item.entClass = "hg_ammo_9x19"
            elseif caliber == "7x62" then
                item.icon = "homigrad/7x62.png"; item.entClass = "hg_ammo_7x62"
            end
            if HG_AddItemToPlayer then return HG_AddItemToPlayer(ply, item) end
            return false
        end
        local ok1 = _hgGiveAmmoItem("7x62", 30)
        local ok2 = _hgGiveAmmoItem("7x62", 30)
        local ok3 = _hgGiveAmmoItem("7x62", 30)
        if (not ok1) and (not ok2) and (not ok3) and ply.GiveAmmo then
            -- Фолбэк: если инвентарь не загружен, выдаём HL2-патроны
            ply:GiveAmmo(90, "ar2", true)
        end
    end

    if teamName == "swat" then
        -- Броня: Bagariy vest + Fast Ops helmet
        if HG_GiveVestByModel then
            HG_GiveVestByModel(ply, "models/eft_props/gear/armor/cr/cr_bagarii.mdl")
        end
        if HG_GiveHelmetByModel then
            HG_GiveHelmetByModel(ply, "models/eft_props/gear/helmets/helmet_ops_core_fast_tan.mdl")
        end
        ply:SetPlayerColor(COLOR_SWAT)
        ply:SetModel(TDM.SWATModel)
        ply:SetNWString("CurrentTeamDisplay", "Спецназ")
    else
        -- Террористы: Thor vest + 6B47 helmet
        if HG_GiveVestByModel then
            HG_GiveVestByModel(ply, "models/eft_props/gear/armor/ar_thor_crv.mdl")
        end
        if HG_GiveHelmetByModel then
            HG_GiveHelmetByModel(ply, "models/eft_props/gear/helmets/helmet_6b47.mdl")
        end
        ply:SetPlayerColor(COLOR_TERROR)
        ply:SetModel(TDM.TErrorModel)
        ply:SetNWString("CurrentTeamDisplay", "Террористы")
    end

    ply:SetNWFloat("SpawnTime", CurTime())

    -- Обновляем клиентский инвентарь после выдачи лоадаута
    if SERVER and BuildActualInventory then
        local actual = BuildActualInventory(ply)
        net.Start("HG_Inventory_Send")
            net.WriteTable(actual)
        net.Send(ply)
    end
end

function TDM:PlayerSpawn(ply)
    local teamName = ply:GetNWString("HomigradTeam") or "swat"

    -- Спавним только в начале раунда; вне начала — оставляем в спектрах
    if SubmodeManager and SubmodeManager.isRoundStart then
        local spawnType = (teamName == "swat") and self.SpawnTypeSWAT or self.SpawnTypeTERROR
        local spawns = HOMIGRAD_GetSpawnPoints(spawnType)
        if #spawns == 0 then
            -- Fallback на обычный DM, если точки не проставлены
            spawns = HOMIGRAD_GetSpawnPoints("dm")
        end
        if #spawns > 0 then
            ply:SetPos(table.Random(spawns))
        else
            ply:SetPos(Vector(0,0,100))
        end
        giveTDMLoadout(ply)
    else
        local spawnType = (teamName == "swat") and self.SpawnTypeSWAT or self.SpawnTypeTERROR
        local spawns = HOMIGRAD_GetSpawnPoints(spawnType)
        if #spawns == 0 then spawns = HOMIGRAD_GetSpawnPoints("dm") end
        if #spawns > 0 then
            ply:SetPos(table.Random(spawns))
        else
            ply:SetPos(Vector(0,0,100))
        end
        ply:Spectate(OBS_MODE_ROAMING)
        ply:SetMoveType(MOVETYPE_OBSERVER)
        ply:SetNWString("CurrentTeamDisplay", (teamName == "swat") and "Спецназ" or "Террористы")
    end
end

function TDM:CheckRoundEnd()
    local swatAlive, terrorAlive = 0, 0
    for _, p in ipairs(player.GetAll()) do
        if IsValid(p) and p:Alive() then
            local t = p:GetNWString("HomigradTeam")
            if t == "swat" then swatAlive = swatAlive + 1 end
            if t == "terrorists" then terrorAlive = terrorAlive + 1 end
        end
    end

    if swatAlive == 0 or terrorAlive == 0 then
        local winner = "Никто"
        if swatAlive > 0 then winner = "Спецназ" end
        if terrorAlive > 0 then winner = "Террористы" end

        if not self._announcedWinner then
            self._announcedWinner = true
            if HG_Armor_RoundEndCleanup then HG_Armor_RoundEndCleanup() end
            net.Start("Homigrad_RoundEnd")
                net.WriteString("tdm")
                net.WriteString(winner)
                net.WriteString("")
            net.Broadcast()
        end
        return true
    end

    return false
end

function TDM:End()
    -- Дублируем логику победителя для финального экрана
    local swatAlive, terrorAlive = 0, 0
    for _, p in ipairs(player.GetAll()) do
        if IsValid(p) and p:Alive() then
            local t = p:GetNWString("HomigradTeam")
            if t == "swat" then swatAlive = swatAlive + 1 end
            if t == "terrorists" then terrorAlive = terrorAlive + 1 end
        end
    end

    local winner = "Ничья"
    if swatAlive == 0 and terrorAlive > 0 then winner = "Террористы" end
    if terrorAlive == 0 and swatAlive > 0 then winner = "Спецназ" end

    if HG_Armor_RoundEndCleanup then HG_Armor_RoundEndCleanup() end
    net.Start("Homigrad_RoundEnd")
        net.WriteString("tdm")
        net.WriteString(winner)
        net.WriteString("")
    net.Broadcast()
end
