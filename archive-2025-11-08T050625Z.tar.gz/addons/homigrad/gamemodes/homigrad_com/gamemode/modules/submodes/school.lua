-- gamemodes/homigrad/gamemode/submodes/school.lua
School = {}
School.__homigrad_id = "school"
School.Name = "School Shooting"
School.Duration = 180 -- 3 минуты

-- Доступен только на карте gm_school
function School:IsAvailable()
    return game.GetMap() == "gm_school"
end

-- Модели из Homicide (гражданские)
School.CitizenModels = {
    "models/player/Group01/male_01.mdl",
    "models/player/Group01/male_02.mdl",
    "models/player/Group01/male_03.mdl",
    "models/player/Group01/male_04.mdl",
    "models/player/Group01/male_05.mdl",
    "models/player/Group01/male_06.mdl",
    "models/player/Group01/male_07.mdl",
    "models/player/Group01/male_08.mdl",
    "models/player/Group01/male_09.mdl",
    "models/player/Group01/female_01.mdl",
    "models/player/Group01/female_02.mdl",
    "models/player/Group01/female_03.mdl",
    "models/player/Group01/female_04.mdl",
    "models/player/Group01/female_06.mdl"
}

-- Полиция как в Riot
School.PoliceModels = Riot and Riot.PoliceModels or {
    "models/player/kerry/policeru_01_patrol.mdl",
    "models/player/kerry/policeru_02_patrol.mdl"
}

local COLOR_VICTIMS = Vector(0/255,255/255,29/255)
local COLOR_SHOOTERS = Vector(255/255,0/255,0/255)
local COLOR_POLICE = Vector(16/255,0/255,255/255)

local function setRandomCitizenModel(ply)
    local mdl = table.Random(School.CitizenModels)
    ply:SetSkin(0)
    ply:SetModel(mdl)
    local skinCount = ply:SkinCount() or 1
    if skinCount > 1 then
        ply:SetSkin(math.random(0, skinCount - 1))
    end
end

function School:Start()
    RunConsoleCommand("hostname", "HOMIGRAD XUY School Shooting")

    local players = player.GetAll()
    if #players == 0 then return end

    -- Сброс сетевых переменных
    for _, p in ipairs(players) do
        p:SetNWString("HomigradTeam", "victims")
        p:SetNWString("SchoolRole", "victim")
    end

    -- Определяем количество стрелков по числу жертв
    local victimsCount = #players -- на старте все считаются жертвами
    local shootersCount = (victimsCount >= 11) and 2 or 1

    -- Выбираем стрелков случайно
    local pool = table.Copy(players)
    for i = #pool, 2, -1 do
        local j = math.random(i)
        pool[i], pool[j] = pool[j], pool[i]
    end

    local shooters = {}
    for i = 1, math.min(shootersCount, #pool) do
        shooters[i] = pool[i]
    end

    for _, ply in ipairs(players) do
        if table.HasValue(shooters, ply) then
            ply:SetNWString("HomigradTeam", "shooters")
            ply:SetNWString("SchoolRole", "shooter")
        else
            ply:SetNWString("HomigradTeam", "victims")
            ply:SetNWString("SchoolRole", "victim")
        end
    end

    -- Полиция приедет через минуту
    timer.Simple(60, function()
        if SubmodeManager.current ~= self then return end
        local deadPlayers = {}
        for _, p in ipairs(player.GetAll()) do
            if not p:Alive() then table.insert(deadPlayers, p) end
        end
        if #deadPlayers == 0 then return end
        local spawnTargets = {}
        for i = 1, math.min(5, #deadPlayers) do
            table.insert(spawnTargets, deadPlayers[i])
        end
        for _, ply in ipairs(spawnTargets) do
            ply:SetNWString("HomigradTeam", "police")
            ply:SetNWString("SchoolRole", "police")
            ply:SetSkin(0)
            ply:SetModel(table.Random(self.PoliceModels))
            ply:Spawn()
        end
    end)
end

function School:PlayerSpawn(ply)
    local teamName = ply:GetNWString("HomigradTeam") or "victims"
    local role = ply:GetNWString("SchoolRole") or "victim"

    -- UI имя команды
    local teamDisplayName = "Жертвы"
    if teamName == "shooters" then teamDisplayName = "Стрелки" end
    if teamName == "police" then teamDisplayName = "Полиция" end
    ply:SetNWString("CurrentTeamDisplay", teamDisplayName)
    ply:SetNWFloat("SpawnTime", CurTime())

    -- Выдаем модель/цвета и экипировку
    if teamName == "police" then
        -- Полиция
        ply:StripWeapons()
        ply:SetPlayerColor(COLOR_POLICE)
        if HG_GiveVestByModel then
            HG_GiveVestByModel(ply, "models/eft_props/gear/armor/ar_thor_crv.mdl")
        end
        ply:Give("weapon_hg_metalbat") -- как в Riot, базовое оружие
    elseif teamName == "shooters" then
        -- Стрелки
        setRandomCitizenModel(ply)
        ply:SetPlayerColor(COLOR_SHOOTERS)
        ply:StripWeapons()
        ply:Give("weapon_pistol")
        ply:Give("weapon_hg_kitknife")
    else
        -- Жертвы
        setRandomCitizenModel(ply)
        ply:SetPlayerColor(COLOR_VICTIMS)
        ply:StripWeapons()
    end

    -- Расставляем позиции спавна (раздельные точки для жертв, стрелков и полиции)
    local spawnType = "school_victims"
    if teamName == "shooters" then
        spawnType = "school_shooters"
    elseif teamName == "police" then
        spawnType = "school_police"
    end

    if SubmodeManager and SubmodeManager.isRoundStart then
        local spawns = HOMIGRAD_GetSpawnPoints(spawnType)
        if #spawns == 0 then
            -- Fallback to homicide/police groups if school_* not placed yet
            local fb = (teamName == "police") and "hmcd_police" or "hmcd_homicide"
            spawns = HOMIGRAD_GetSpawnPoints(fb)
        end
        if #spawns > 0 then
            ply:SetPos(table.Random(spawns))
        else
            ply:SetPos(Vector(0,0,100))
        end
    else
        local spawns = HOMIGRAD_GetSpawnPoints(spawnType)
        if #spawns == 0 then
            local fb = (teamName == "police") and "hmcd_police" or "hmcd_homicide"
            spawns = HOMIGRAD_GetSpawnPoints(fb)
        end
        if #spawns > 0 then
            ply:SetPos(table.Random(spawns))
        else
            ply:SetPos(Vector(0,0,100))
        end
        ply:Spectate(OBS_MODE_ROAMING)
        ply:SetMoveType(MOVETYPE_OBSERVER)
    end
end

function School:CheckRoundEnd()
    local shootersAlive = 0
    local victimsAlive = 0
    for _, ply in ipairs(player.GetAll()) do
        if ply:Alive() then
            local team = ply:GetNWString("HomigradTeam")
            if team == "shooters" then
                shootersAlive = shootersAlive + 1
            elseif team == "victims" then
                victimsAlive = victimsAlive + 1
            end
        end
    end

    if shootersAlive == 0 or victimsAlive == 0 then
        return true
    end
    return false
end

function School:End()
    local shootersAlive = 0
    local victimsAlive = 0
    for _, ply in ipairs(player.GetAll()) do
        if ply:Alive() then
            local team = ply:GetNWString("HomigradTeam")
            if team == "shooters" then
                shootersAlive = shootersAlive + 1
            elseif team == "victims" then
                victimsAlive = victimsAlive + 1
            end
        end
    end

    local winner = "Ничья"
    if shootersAlive == 0 and (victimsAlive > 0) then winner = "Жертвы" end
    if victimsAlive == 0 and (shootersAlive > 0) then winner = "Стрелки" end

    if HG_Armor_RoundEndCleanup then HG_Armor_RoundEndCleanup() end
    net.Start("Homigrad_RoundEnd")
        net.WriteString("school")
        net.WriteString(winner)
        net.WriteString("")
    net.Broadcast()
end
