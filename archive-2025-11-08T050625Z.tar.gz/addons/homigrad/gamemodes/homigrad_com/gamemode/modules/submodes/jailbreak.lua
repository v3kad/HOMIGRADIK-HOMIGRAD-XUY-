-- gamemodes/homigrad/gamemode/submodes/jailbreak.lua
JailBreak = {}
JailBreak.__homigrad_id = "jailbreak"
JailBreak.Name = "JailBreak"
JailBreak.Duration = 600 -- 10 минут

-- Карты, на которых доступен режим JailBreak
JailBreak.AllowedMaps = {
    "jb_mars_lp",
    "jb_new_summer_v3",
    "jb_vipinthemix_v1_2",
    "ba_jail_electric_vip_v2",
    "jb_lego_jail_pre_v6-2"
}

JailBreak.GuardModels = {
    "models/player/kerry/policeru_01_patrol.mdl",
    "models/player/kerry/policeru_02_patrol.mdl",
    "models/player/kerry/policeru_03_patrol.mdl",
    "models/player/kerry/policeru_04_patrol.mdl",
    "models/player/kerry/policeru_05_patrol.mdl",
    "models/player/kerry/policeru_06_patrol.mdl",
    "models/player/kerry/policeru_07_patrol.mdl"
}

JailBreak.PrisonerModels = {
    "models/player/aperture_science/male_01.mdl",
    "models/player/aperture_science/male_02.mdl",
    "models/player/aperture_science/male_03.mdl",
    "models/player/aperture_science/male_04.mdl",
    "models/player/aperture_science/male_05.mdl",
    "models/player/aperture_science/male_06.mdl",
    "models/player/aperture_science/male_07.mdl",
    "models/player/aperture_science/male_08.mdl",
    "models/player/aperture_science/male_09.mdl"
}

-- Специальная модель для одного охранника (обязательно у одного охранника)
JailBreak.SpecialGuardModel = "models/player/kerry/policeru_07.mdl"

-- Функция проверки доступности режима на текущей карте
function JailBreak:IsAvailable()
    local currentMap = game.GetMap()
    -- Разрешаем режим на картах с префиксами jb_ и ba_
    if string.StartWith(currentMap, "jb_") or string.StartWith(currentMap, "ba_") then
        return true
    end
    -- Иначе проверяем явный белый список
    for _, mapName in ipairs(self.AllowedMaps) do
        if currentMap == mapName then
            return true
        end
    end
    return false
end

-- Функция определения количества охранников в зависимости от общего количества игроков
-- Логика: определяем количество охранников так, чтобы получилось нужное количество заключённых
-- Цель: 1-5 заключённых (1 охранник), 6-10 (2 охранника), 11-15 (3 охранника), 15+ (4 охранника)
function JailBreak:GetGuardCount(totalPlayers)
    if totalPlayers <= 6 then
        -- Для 2-6 игроков: 1 охранник → 1-5 заключённых
        return 1
    elseif totalPlayers <= 12 then
        -- Для 7-12 игроков: 2 охранника → 5-10 заключённых
        return 2
    elseif totalPlayers <= 18 then
        -- Для 13-18 игроков: 3 охранника → 10-15 заключённых
        return 3
    else
        -- Для 19+ игроков: 4 охранника → 15+ заключённых
        return 4
    end
end

function JailBreak:Start()
    print("[Homigrad|JailBreak] Round started!")
    
    -- Проверяем, доступен ли режим на текущей карте
    if not self:IsAvailable() then
        print("[Homigrad|JailBreak] ERROR: Mode not available on current map: " .. game.GetMap())
        return
    end
    
    -- Устанавливаем hostname для режима JailBreak
    RunConsoleCommand("hostname", "HOMIGRAD XUY Jail Break")
    
    -- Флаг: сейчас идет назначение команд (чтобы не убивать при SetTeam в процессе старта)
    self._assigning = true
    -- Сброс специального охранника в начале раунда
    self.SpecialGuardSID = nil

    -- Получаем всех игроков
    local players = player.GetAll()
    local totalPlayers = #players
    
    if totalPlayers == 0 then
        print("[Homigrad|JailBreak] No players to assign teams!")
        return
    end
    
    -- Сначала подсчитываем существующих охранников
    local existingGuards = {}
    local existingPrisoners = {}
    local unassignedPlayers = {}
    
    for _, ply in ipairs(players) do
        local currentTeam = ply:GetNWString("HomigradTeam", "")
        if currentTeam == "guards" then
            table.insert(existingGuards, ply)
        elseif currentTeam == "prisoners" then
            table.insert(existingPrisoners, ply)
        else
            table.insert(unassignedPlayers, ply)
        end
    end
    
    local currentGuardCount = #existingGuards
    
    print("[Homigrad|JailBreak] Current guards: " .. currentGuardCount .. " (players must choose guards themselves)")
    
    -- НЕ меняем команды существующих охранников - они остаются охранниками
    -- Сервер НЕ назначает охранников автоматически, игроки должны выбрать сами
    -- Назначаем одному охраннику обязательную специальную модель
    if #existingGuards > 0 then
        local specialIndex = math.random(1, #existingGuards)
        for i, ply in ipairs(existingGuards) do
            if i == specialIndex then
                self.SpecialGuardSID = ply:SteamID64()
                ply:SetModel(self.SpecialGuardModel)
                print("[Homigrad|JailBreak] Special guard assigned: " .. ply:Nick())
            else
                ply:SetModel(table.Random(self.GuardModels))
            end
            ply:StripWeapons()
            print("[Homigrad|JailBreak] Keeping guard: " .. ply:Nick())
        end
    end
    
    -- Назначаем команды остальным игрокам (заключённые)
    -- Игроки без команды автоматически становятся заключёнными
    for _, ply in ipairs(existingPrisoners) do
        ply:SetTeam(1) -- Prisoners team
        ply:SetNWString("HomigradTeam", "prisoners")
        ply:SetModel(table.Random(self.PrisonerModels))
        ply:StripWeapons()
    end
    
    -- Незанятые игроки становятся заключёнными по умолчанию
    for _, ply in ipairs(unassignedPlayers) do
        ply:SetTeam(1) -- Prisoners team
        ply:SetNWString("HomigradTeam", "prisoners")
        ply:SetModel(table.Random(self.PrisonerModels))
        ply:StripWeapons()
        print("[Homigrad|JailBreak] Assigned player to prisoners: " .. ply:Nick())
    end
    
    -- Сбрасываем флаг оповещения о победителе на случай повторного старта
    self._announcedWinner = false

    print("[Homigrad|JailBreak] Team assignment completed!")
    -- Сбрасываем флаг назначения команд
    self._assigning = false
end

function JailBreak:PlayerSpawn(ply)
    local teamName = ply:GetNWString("HomigradTeam") or "prisoners"
    print("[JailBreak] Player spawning as: " .. tostring(teamName))
    
    -- Устанавливаем сетевую переменную для отображения команды на клиенте
    local teamDisplayName = teamName == "guards" and "Охранник" or "Заключённый"
    ply:SetNWString("CurrentTeamDisplay", teamDisplayName)
    ply:SetNWFloat("SpawnTime", CurTime()) -- Время спавна для отслеживания 10 секунд
    
    -- Определяем тип точки спавна
    local spawnType = teamName == "guards" and "jb_guards" or "jb_prisoners"
    
    -- Проверяем, это начало раунда или обычный спавн
    if SubmodeManager and SubmodeManager.isRoundStart then
        -- В начале раунда игроки спавнятся живыми
        print("[JailBreak] Round start - player spawning alive")
        local spawns = HOMIGRAD_GetSpawnPoints(spawnType)
        print("[JailBreak] Found " .. #spawns .. " spawn points for " .. tostring(teamName))
        if #spawns > 0 then
            ply:SetPos(table.Random(spawns))
            print("[JailBreak] Spawning player alive at: " .. tostring(ply:GetPos()))
        else
            print("[JailBreak] No spawn points found, using fallback position")
            ply:SetPos(Vector(0,0,100))
        end
    else
        -- При обычном спавне игроки остаются мертвыми
        print("[JailBreak] Normal spawn - player stays dead")
        local spawns = HOMIGRAD_GetSpawnPoints(spawnType)
        print("[JailBreak] Found " .. #spawns .. " spawn points for " .. tostring(teamName))
        if #spawns > 0 then
            ply:SetPos(table.Random(spawns))
            print("[JailBreak] Setting observer position at: " .. tostring(ply:GetPos()))
        else
            print("[JailBreak] No spawn points found, using fallback position")
            ply:SetPos(Vector(0,0,100))
        end
        
        -- Убеждаемся, что игрок остается в режиме наблюдателя
        ply:Spectate(OBS_MODE_ROAMING)
        ply:SetMoveType(MOVETYPE_OBSERVER)
    end

    -- Устанавливаем корректную модель и выдаём броню/оружие охранникам
    if teamName == "guards" then
        local sid = ply:SteamID64()
        if not self.SpecialGuardSID or self.SpecialGuardSID == "" then
            self.SpecialGuardSID = sid
        end
        if self.SpecialGuardSID == sid then
            ply:SetModel(self.SpecialGuardModel)
        else
            ply:SetModel(table.Random(self.GuardModels))
        end
        if HG_GiveVestByModel then
            HG_GiveVestByModel(ply, "models/eft_props/gear/armor/ar_thor_crv.mdl")
        end
        -- Выдаём громкоговоритель охранникам
        timer.Simple(0.5, function()
            if IsValid(ply) and ply:Alive() then
                ply:Give("weapon_hg_megaphone")
                ply:SelectWeapon("wep_hands")
            end
        end)
    end
end

-- Цель 1: Проверка на уничтожение команды
function JailBreak:CheckRoundEnd()
    local players = player.GetAll()
    local guardsAlive = 0
    local guardsTotal = 0 -- Общее количество охранников
    local prisonersAlive = 0

    for _, ply in ipairs(players) do
        local team = ply:GetNWString("HomigradTeam")
        if team == "guards" then
            guardsTotal = guardsTotal + 1
            if ply:Alive() then
                guardsAlive = guardsAlive + 1
            end
        elseif team == "prisoners" then
            if ply:Alive() then
                prisonersAlive = prisonersAlive + 1
            end
        end
    end

    -- Если нет охранников вообще, раунд не завершается - он ждет пока появится охранник
    if guardsTotal == 0 then
        return false -- Продолжаем раунд
    end

    -- Если в одной из команд 0 живых игроков (но только если есть охранники), завершаем раунд
    if guardsAlive == 0 or prisonersAlive == 0 then
        local winner = "Никто"
        if guardsAlive > 0 then
            winner = "Охранники"
        elseif prisonersAlive > 0 then
            winner = "Заключённые"
        end
        print("[Homigrad|JailBreak] Round ended! Winners: " .. winner)

        -- Гарантируем отправку сообщения клиентам сразу при определении победителя
        if not self._announcedWinner then
            self._announcedWinner = true
            local ok, err = pcall(function()
                if HG_Armor_RoundEndCleanup then HG_Armor_RoundEndCleanup() end
                net.Start("Homigrad_RoundEnd")
                    net.WriteString("jailbreak")
                    net.WriteString(winner)
                    net.WriteString("")
                net.Broadcast()
            end)
            if ok then
                print("[Homigrad|JailBreak] (CheckRoundEnd) Winner announcement broadcasted: " .. winner)
            else
                print("[Homigrad|JailBreak] (CheckRoundEnd) ERROR broadcasting winner: " .. tostring(err))
            end
        end

        return true -- Да, завершаем раунд
    end

    return false -- Нет, продолжаем
end

function JailBreak:End()
    print("[Homigrad|JailBreak] Round ended!")
    
    -- Подсчитываем результаты
    local players = player.GetAll()
    local guardsAlive = 0
    local prisonersAlive = 0
    
    for _, ply in ipairs(players) do
        if ply:Alive() then
            local team = ply:GetNWString("HomigradTeam")
            if team == "guards" then
                guardsAlive = guardsAlive + 1
            elseif team == "prisoners" then
                prisonersAlive = prisonersAlive + 1
            end
        end
    end
    
    -- Определяем победителя
    local winner = "Ничья"
    if guardsAlive == 0 then
        winner = "Заключённые"
    elseif prisonersAlive == 0 then
        winner = "Охранники"
    end
    
    -- Отправляем информацию о победителе на клиент для отображения прямоугольника
    print("[Homigrad|JailBreak] Sending network message to clients...")
    print("[Homigrad|JailBreak] Mode: jailbreak, Winner: " .. winner)
    
    local success, err = pcall(function()
        if HG_Armor_RoundEndCleanup then HG_Armor_RoundEndCleanup() end
        net.Start("Homigrad_RoundEnd")
            net.WriteString("jailbreak")
            net.WriteString(winner)
            net.WriteString("") -- Пустая строка для совместимости
        net.Broadcast()
    end)
    
    if success then
        print("[Homigrad|JailBreak] Winner announcement sent successfully: " .. winner)
    else
        print("[Homigrad|JailBreak] ERROR sending network message: " .. tostring(err))
    end
end


hook.Add("OnPlayerChangedTeam", "HG_JB_KillOnTeamChange", function(ply, oldTeam, newTeam)
    if not SubmodeManager or not SubmodeManager.current then return end
    if SubmodeManager.current.__homigrad_id ~= "jailbreak" then return end
    if SubmodeManager.isRoundStart then return end
    if JailBreak and JailBreak._assigning then return end
    if not IsValid(ply) then return end
    if ply:Alive() then ply:Kill() else ply:KillSilent() end
end)
