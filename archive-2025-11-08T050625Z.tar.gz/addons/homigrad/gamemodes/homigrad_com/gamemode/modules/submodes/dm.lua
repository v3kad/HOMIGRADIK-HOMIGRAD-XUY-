-- gamemodes/homigrad_com/gamemode/modules/submodes/dm.lua
DM = {}
DM.__homigrad_id = "dm"
DM.Name = "DeathMatch"
DM.Duration = 180 -- 3 минуты

DM.PlayerModel = "models/css_seb_swat/css_seb.mdl"

function DM:Start()
    print("[Homigrad|DM] Round started!")

    for _, ply in ipairs(player.GetAll()) do
        if IsValid(ply) then
            ply:EmitSound("snd_jack_hmcd_deathmatch.mp3")
        end
    end

    -- hostname для DM
    RunConsoleCommand("hostname", "HOMIGRAD XUY DeathMatch")

    -- Все игроки участвуют, ффа
    for _, ply in ipairs(player.GetAll()) do
        if IsValid(ply) then
            ply:SetNWString("HomigradTeam", "dm")
            ply:SetNWString("CurrentTeamDisplay", "Боец")
            ply:SetModel(self.PlayerModel)
            ply:StripWeapons()
            ply:Give("weapon_akm")
            ply:Give("weapon_grenade_f1")
            ply:Give("weapon_hg_bandage")
            ply:Give("weapon_hg_painkiller")
            do
                local function _hgGiveAmmoItem(caliber, amount)
                    local item = { name = tostring(caliber), kind = "ammo", caliber = caliber, amount = amount, icon = nil, entClass = nil }
                    if caliber == "9x19" then
                        item.icon = "homigrad/9x19.png"; item.entClass = "hg_ammo_9x19"
                    elseif caliber == "7x62" then
                        item.icon = "homigrad/7x62.png"; item.entClass = "hg_ammo_7x62"
                    end
                    if HG_AddItemToPlayer then return HG_AddItemToPlayer(ply, item) end
                    return false
                end
                local ok1 = _hgGiveAmmoItem("7x62", 30)
                local ok2 = _hgGiveAmmoItem("7x62", 30)
                local ok3 = _hgGiveAmmoItem("7x62", 30)
                if (not ok1) and (not ok2) and (not ok3) and ply.GiveAmmo then
                    ply:GiveAmmo(90, "ar2", true)
                end
            end
            if HG_GiveVestByModel then
                HG_GiveVestByModel(ply, "models/eft_props/gear/armor/cr/cr_bagarii.mdl")
            end
            if HG_GiveHelmetByModel then
                HG_GiveHelmetByModel(ply, "models/eft_props/gear/helmets/helmet_6b47.mdl")
            end
        end
    end
end

function DM:PlayerSpawn(ply)
    local spawnType = "dm"
    ply:SetNWString("HomigradTeam", "dm")
    ply:SetNWString("CurrentTeamDisplay", "Боец")

    -- Установим модель и базовое оружие
    ply:SetModel(self.PlayerModel)
    ply:StripWeapons()
    ply:Give("weapon_akm")
    ply:Give("weapon_grenade_f1")
    ply:Give("weapon_hg_bandage")
    ply:Give("weapon_hg_painkiller")
    do
        local function _hgGiveAmmoItem(caliber, amount)
            local item = { name = tostring(caliber), kind = "ammo", caliber = caliber, amount = amount, icon = nil, entClass = nil }
            if caliber == "9x19" then
                item.icon = "homigrad/ui/9x19.png"; item.entClass = "hg_ammo_9x19"
            elseif caliber == "7x62" then
                item.icon = "homigrad/ui/7x62.png"; item.entClass = "hg_ammo_7x62"
            end
            if HG_AddItemToPlayer then return HG_AddItemToPlayer(ply, item) end
            return false
        end
        local ok1 = _hgGiveAmmoItem("7x62", 30)
        local ok2 = _hgGiveAmmoItem("7x62", 30)
        local ok3 = _hgGiveAmmoItem("7x62", 30)
        if (not ok1) and (not ok2) and (not ok3) and ply.GiveAmmo then
            ply:GiveAmmo(90, "ar2", true)
        end
    end
    -- Экипируем броню: Bagariy vest + 6B47 helmet
    if HG_GiveVestByModel then
        HG_GiveVestByModel(ply, "models/eft_props/gear/armor/cr/cr_bagarii.mdl")
    end
    if HG_GiveHelmetByModel then
        HG_GiveHelmetByModel(ply, "models/eft_props/gear/helmets/helmet_6b47.mdl")
    end
    ply:SetNWFloat("SpawnTime", CurTime())

    if SubmodeManager and SubmodeManager.isRoundStart then
        -- В начале раунда игроки спавнятся живыми
        local spawns = HOMIGRAD_GetSpawnPoints(spawnType)
        if #spawns > 0 then
            ply:SetPos(table.Random(spawns))
        else
            ply:SetPos(Vector(0,0,100))
        end
    else
        -- Обычный спавн: оставляем в спектрах до нового раунда
        local spawns = HOMIGRAD_GetSpawnPoints(spawnType)
        if #spawns > 0 then
            ply:SetPos(table.Random(spawns))
        else
            ply:SetPos(Vector(0,0,100))
        end
        ply:Spectate(OBS_MODE_ROAMING)
        ply:SetMoveType(MOVETYPE_OBSERVER)
    end
end

function DM:CheckRoundEnd()
    local aliveCount = 0
    for _, p in ipairs(player.GetAll()) do
        if IsValid(p) and p:Alive() then
            aliveCount = aliveCount + 1
            if aliveCount > 1 then
                return false
            end
        end
    end
    -- Завершаем когда остался 1 или 0 живых
    if aliveCount <= 1 then
        print("[Homigrad|DM] Round ended by last man standing (" .. tostring(aliveCount) .. ")")
        return true
    end
    return false
end

function DM:End()
    print("[Homigrad|DM] Round ended!")

    local alivePlayers = {}
    for _, p in ipairs(player.GetAll()) do
        if IsValid(p) and p:Alive() then
            table.insert(alivePlayers, p)
        end
    end

    local winner = "Никто"
    if #alivePlayers == 1 then
        winner = alivePlayers[1]:Nick()
    elseif #alivePlayers > 1 then
        -- Если по таймеру и несколько живых — ничья
        winner = "Ничья"
    end

    -- HUD прямоугольник
    local ok, err = pcall(function()
        if HG_Armor_RoundEndCleanup then HG_Armor_RoundEndCleanup() end
        net.Start("Homigrad_RoundEnd")
            net.WriteString("dm")
            net.WriteString(winner)
            net.WriteString("")
        net.Broadcast()
    end)
    if not ok then
        print("[Homigrad|DM] ERROR sending round end: " .. tostring(err))
    end
end


