-- gamemodes/homigrad_com/gamemode/modules/submodes/event.lua
Event = {}
Event.__homigrad_id = "event"
Event.Name = "Event"
Event.Duration = 999999 -- effectively infinite
Event.AdminOnly = true -- allow on any map and only by admin selection

-- HL2 citizen models for Event participants
Event.CitizenModels = {
    "models/player/Group01/male_01.mdl",
    "models/player/Group01/male_02.mdl",
    "models/player/Group01/male_03.mdl",
    "models/player/Group01/male_04.mdl",
    "models/player/Group01/male_05.mdl",
    "models/player/Group01/male_06.mdl",
    "models/player/Group01/male_07.mdl",
    "models/player/Group01/male_08.mdl",
    "models/player/Group01/male_09.mdl",
    "models/player/Group01/female_01.mdl",
    "models/player/Group01/female_02.mdl",
    "models/player/Group01/female_03.mdl",
    "models/player/Group01/female_04.mdl",
    "models/player/Group01/female_06.mdl"
}

function Event:SetRandomCitizenModel(ply)
    local mdl = table.Random(self.CitizenModels)
    ply:SetSkin(0)
    ply:SetModel(mdl)
    local skinCount = ply:SkinCount() or 1
    if skinCount > 1 then
        ply:SetSkin(math.random(0, skinCount - 1))
    end
end

function Event:Start()
    RunConsoleCommand("hostname", "HOMIGRAD XUY Event")

    -- Assign team display for all players: non-admins -> "Ивент", admins -> "Админ"
    for _, ply in ipairs(player.GetAll()) do
        if not IsValid(ply) then continue end
        if ply:IsAdmin() then
            ply:SetTeam(2)
            ply:SetNWString("HomigradTeam", "admins")
            ply:SetNWString("CurrentTeamDisplay", "Админ")
        else
            ply:SetTeam(1)
            ply:SetNWString("HomigradTeam", "event")
            ply:SetNWString("CurrentTeamDisplay", "Ивент")
            -- Assign random citizen model
            self:SetRandomCitizenModel(ply)
        end
    end
    self._announcedWinner = false
end

function Event:PlayerSpawn(ply)
    -- Spawn handling similar to DM: alive on round start, otherwise spectate
    local spawnType = "event"
    -- Update team display each spawn
    if IsValid(ply) then
        if ply:IsAdmin() then
            ply:SetTeam(2)
            ply:SetNWString("HomigradTeam", "admins")
            ply:SetNWString("CurrentTeamDisplay", "Админ")
        else
            ply:SetTeam(1)
            ply:SetNWString("HomigradTeam", "event")
            ply:SetNWString("CurrentTeamDisplay", "Ивент")
            self:SetRandomCitizenModel(ply)
        end
        ply:SetNWFloat("SpawnTime", CurTime())
    end
    if SubmodeManager and SubmodeManager.isRoundStart then
        local spawns = HOMIGRAD_GetSpawnPoints(spawnType)
        if #spawns > 0 then
            ply:SetPos(table.Random(spawns))
        else
            ply:SetPos(Vector(0,0,100))
        end
    else
        local spawns = HOMIGRAD_GetSpawnPoints(spawnType)
        if #spawns > 0 then
            ply:SetPos(table.Random(spawns))
        else
            ply:SetPos(Vector(0,0,100))
        end
        ply:Spectate(OBS_MODE_ROAMING)
        ply:SetMoveType(MOVETYPE_OBSERVER)
    end
end

function Event:CheckRoundEnd()
    -- End only when one or zero non-admin alive
    local aliveNonAdmin = {}
    for _, p in ipairs(player.GetAll()) do
        if IsValid(p) and p:Alive() and not p:IsAdmin() then
            table.insert(aliveNonAdmin, p)
            if #aliveNonAdmin > 1 then
                return false
            end
        end
    end

    -- 0 or 1 non-admin alive: end round
    local winner = "Никто"
    if #aliveNonAdmin == 1 then
        winner = aliveNonAdmin[1]:Nick()
    end

    if not self._announcedWinner then
        self._announcedWinner = true
        local ok, err = pcall(function()
            if HG_Armor_RoundEndCleanup then HG_Armor_RoundEndCleanup() end
            net.Start("Homigrad_RoundEnd")
                net.WriteString("event")
                net.WriteString(winner)
                net.WriteString("")
            net.Broadcast()
        end)
        if not ok then
            print("[Homigrad|Event] (CheckRoundEnd) ERROR broadcasting winner:", err)
        end
    end

    return true
end

function Event:End()
    -- Recompute winner on End() for redundancy
    local aliveNonAdmin = {}
    for _, p in ipairs(player.GetAll()) do
        if IsValid(p) and p:Alive() and not p:IsAdmin() then
            table.insert(aliveNonAdmin, p)
        end
    end

    local winner = "Никто"
    if #aliveNonAdmin == 1 then
        winner = aliveNonAdmin[1]:Nick()
    elseif #aliveNonAdmin > 1 then
        winner = "Ничья"
    end

    for _, ply in ipairs(player.GetAll()) do
        if winner == "Никто" then
            ply:ChatPrint(Color(200, 200, 200), "EVENT ЗАВЕРШЕН - Победителя нет")
        elseif winner == "Ничья" then
            ply:ChatPrint(Color(200, 200, 200), "EVENT ЗАВЕРШЕН - Ничья")
        else
            ply:ChatPrint(Color(255, 200, 0), "EVENT ЗАВЕРШЕН - Победил: " .. winner)
        end
    end

    local ok, err = pcall(function()
        if HG_Armor_RoundEndCleanup then HG_Armor_RoundEndCleanup() end
        net.Start("Homigrad_RoundEnd")
            net.WriteString("event")
            net.WriteString(winner)
            net.WriteString("")
        net.Broadcast()
    end)
    if not ok then
        print("[Homigrad|Event] ERROR sending network message:", err)
    end
end
