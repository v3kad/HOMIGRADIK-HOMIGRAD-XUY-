-- gamemodes/homigrad/gamemode/submodes/homicide.lua
Homicide = {}
Homicide.__homigrad_id = "homicide"
Homicide.Name = "Homicide"
Homicide.Duration = 420 -- Homicide ends after 7 minutes, or when traitor dies, or when all others die

Homicide.PoliceModel = "models/police/policeru_02_patrol.mdl"
Homicide.CitizenModels = {
	-- Half-Life 2 citizen variants (Group01) with colored casual clothing
	"models/player/Group01/male_01.mdl",
	"models/player/Group01/male_02.mdl",
	"models/player/Group01/male_03.mdl",
	"models/player/Group01/male_04.mdl",
	"models/player/Group01/male_05.mdl",
	"models/player/Group01/male_06.mdl",
	"models/player/Group01/male_07.mdl",
	"models/player/Group01/male_08.mdl",
	"models/player/Group01/male_09.mdl",
	"models/player/Group01/female_01.mdl",
	"models/player/Group01/female_02.mdl",
	"models/player/Group01/female_03.mdl",
	"models/player/Group01/female_04.mdl",
	"models/player/Group01/female_06.mdl"
}

function Homicide:SetRandomCitizenModel(ply)
	local mdl = table.Random(self.CitizenModels)
	-- Reset skin to avoid carryover from previous submodes
	ply:SetSkin(0)
	ply:SetModel(mdl)
	-- Randomize skin if the model supports multiple skins (varied clothing colors)
	local skinCount = ply:SkinCount() or 1
	if skinCount > 1 then
		ply:SetSkin(math.random(0, skinCount - 1))
	end
end

function Homicide:Start()
    print("[Homigrad|Homicide] Round started!")
    
    -- Устанавливаем hostname для режима Homicide
    RunConsoleCommand("hostname", "HOMIGRAD XUY Homicide")
    
    -- Spawn loot cases at saved pointers (only for Homicide)
    if HG_LootSpawns and HG_LootSpawns.SpawnForMode then
        HG_LootSpawns.SpawnForMode("homicide")
    end
    
    local players = player.GetAll()

    -- Сбрасываем команды с прошлого раунда
    for _, p in ipairs(players) do
        p:SetNWString("HomicideRole", "")
        p:SetNWString("HomigradTeam", "citizen")
    end
    
    -- Случайный предатель
	local traitor = table.Random(players)
	traitor:SetNWString("HomicideRole", "traitor")
	self:SetRandomCitizenModel(traitor)
    traitor:StripWeapons()
    traitor:Give("weapon_hg_kitknife")
    traitor:Give("weapon_grenade_f1")

    -- Случайный шериф (не предатель)
    local others = {}
    for _, p in ipairs(players) do if p ~= traitor then table.insert(others,p) end end
    if #others > 0 then
		local sheriff = table.Random(others)
		sheriff:SetNWString("HomicideRole", "sheriff")
		self:SetRandomCitizenModel(sheriff)
        sheriff:StripWeapons()
        sheriff:Give("weapon_hg_machete")
    end

    -- Остальные мирные
    for _, ply in ipairs(players) do
		-- Assign citizen role to everyone who doesn't already have a role
		if ply:GetNWString("HomicideRole") == "" then
			ply:SetNWString("HomicideRole", "citizen")
			self:SetRandomCitizenModel(ply)
            ply:StripWeapons()
        end
    end

    -- Отправляем информацию о времени приезда полиции клиентам
    local policeArrivalTime = CurTime() + 180
    net.Start("Homigrad_PoliceArrival")
        net.WriteFloat(policeArrivalTime)
    net.Broadcast()
    
    -- Таймер приезда полиции через 3 минуты
    timer.Simple(180, function()
        -- Мы должны быть уверены, что раунд все еще идет
        if SubmodeManager.current ~= self then return end

        local deadPlayers = {}
        -- Собираем всех игроков, кто сейчас мертв (в спектрах)
        for _, p in ipairs(player.GetAll()) do
            if not p:Alive() then table.insert(deadPlayers,p) end
        end
        
        if #deadPlayers == 0 then
            print("")
            return
        end

        local spawnTargets = {}
        for i = 1, math.min(5,#deadPlayers) do
            table.insert(spawnTargets, deadPlayers[i])
        end
        
        print("")
        for _, ply in ipairs(spawnTargets) do
            ply:SetNWString("HomigradTeam", "police")
            ply:SetNWString("HomicideRole", "police")
            -- Reset skin before setting police model to avoid wrong skin indices
            ply:SetSkin(0)
            ply:SetModel(self.PoliceModel)
            
            -- Полиция также спавнится мертвой - вызываем PlayerSpawn для настройки позиции
            ply:Spawn() 
        end
    end)
end

function Homicide:PlayerSpawn(ply)
    local teamName = ply:GetNWString("HomigradTeam")
    local role = ply:GetNWString("HomicideRole")
    local spawnType = "homicide"

    -- Устанавливаем сетевую переменную для отображения команды на клиенте
    local teamDisplayName = "Невиновный"
    if teamName == "police" then
        teamDisplayName = "Полиция"
	elseif role == "traitor" then
		teamDisplayName = "Предатель"
    elseif role == "sheriff" then
        teamDisplayName = "Вооружённый"
    end
    
    ply:SetNWString("CurrentTeamDisplay", teamDisplayName)
    ply:SetNWFloat("SpawnTime", CurTime()) -- Время спавна для отслеживания 10 секунд

    -- Если это полиция (прибывшая по таймеру или респавн в начале раунда)
    if teamName == "police" then
        spawnType = "police"
        ply:StripWeapons()
        ply:Give("weapon_pistol")
        ply:Give("weapon_crowbar")
        if HG_GiveVestByModel then
            HG_GiveVestByModel(ply, "models/eft_props/gear/armor/ar_thor_crv.mdl")
        end
    
    -- Если это игроки в начале раунда
    elseif role == "traitor" then
        ply:StripWeapons()
        ply:Give("weapon_hg_kitknife")
        ply:Give("weapon_grenade_f1")
    elseif role == "sheriff" then
        ply:StripWeapons()
        ply:Give("weapon_pistol")
    elseif role == "citizen" then
        ply:StripWeapons()
    end

    print("[Homicide] Player spawning as: " .. tostring(teamName) .. ", role: " .. tostring(role) .. ", spawn type: " .. tostring(spawnType))

    -- Проверяем, это начало раунда или обычный спавн
    if SubmodeManager and SubmodeManager.isRoundStart then
        -- В начале раунда игроки спавнятся живыми
        print("")
        local spawns = HOMIGRAD_GetSpawnPoints(spawnType)
        print("")
        if #spawns > 0 then
            ply:SetPos(table.Random(spawns))
            print("")
        else
            print("")
            ply:SetPos(Vector(0,0,100))
        end
    else
        -- При обычном спавне игроки остаются мертвыми
        print("[Homicide] Normal spawn - player stays dead")
        local spawns = HOMIGRAD_GetSpawnPoints(spawnType)
        print("[Homicide] Found " .. #spawns .. " spawn points for " .. tostring(spawnType))
        if #spawns > 0 then
            ply:SetPos(table.Random(spawns))
            print("[Homicide] Setting observer position at: " .. tostring(ply:GetPos()))
        else
            print("[Homicide] No spawn points available, using default position")
            ply:SetPos(Vector(0,0,100))
        end
        
        -- Убеждаемся, что игрок остается в режиме наблюдателя
        ply:Spectate(OBS_MODE_ROAMING)
        ply:SetMoveType(MOVETYPE_OBSERVER)
    end
end

-- Цель 1: Проверка на победу предателя или мирных
function Homicide:CheckRoundEnd()
    local players = player.GetAll()
    local traitorAlive = false
    local othersAlive = 0 -- Мирные + Шериф

    for _, ply in ipairs(players) do
        -- Игнорируем полицию, они не часть условия победы
        local team = ply:GetNWString("HomigradTeam")
        local role = ply:GetNWString("HomicideRole")
        
        -- Проверяем живых игроков
        if ply:Alive() and team ~= "police" then
            if role == "traitor" then
                traitorAlive = true
            elseif role == "citizen" or role == "sheriff" then
                othersAlive = othersAlive + 1
            end
        end
    end

    -- Раунд заканчивается если:
    -- 1. Предатель мертв (traitorAlive == false)
    -- 2. Все мирные мертвы (othersAlive == 0 и трайтор жив)
    if not traitorAlive then
        print("[Homigrad|Homicide] Round ended! Traitor died - Peaceful inhabitants win!")
        return true -- Завершаем раунд
    end
    
    if othersAlive == 0 then
        print("[Homigrad|Homicide] Round ended! All peaceful inhabitants are dead - Traitor wins!")
        return true -- Завершаем раунд
    end

    return false -- Продолжаем раунд
end

function Homicide:End()
    print("[Homigrad|Homicide] Round ended!")
    if HG_LootSpawns and HG_LootSpawns.Cleanup then
        HG_LootSpawns.Cleanup()
    end
    
    -- Ищем всех предателей и выводим в чат
    local traitors = {}
    local allPlayers = player.GetAll()
    
    for _, ply in ipairs(allPlayers) do
        local role = ply:GetNWString("HomicideRole")
        if role == "traitor" then
            table.insert(traitors, ply)
        end
    end
    
    -- Определяем победителя по статусу жив/мертв, а не по наличию роли
    local winner = "Мирные жители"
    local traitorNames = ""

    local traitorAlive = false
    local othersAlive = 0

    for _, ply in ipairs(allPlayers) do
        local team = ply:GetNWString("HomigradTeam")
        local role = ply:GetNWString("HomicideRole")
        if ply:Alive() and team ~= "police" then
            if role == "traitor" then
                traitorAlive = true
            elseif role == "citizen" or role == "sheriff" then
                othersAlive = othersAlive + 1
            end
        end
    end

    -- Список имен предателя (даже если он мертв), чтобы показать в итогах
    if #traitors > 0 then
        local traitorNamesList = {}
        for _, traitor in ipairs(traitors) do
            table.insert(traitorNamesList, traitor:Nick())
        end
        traitorNames = table.concat(traitorNamesList, ", ")
    end

    if not traitorAlive then
        winner = "Мирные жители"
    elseif othersAlive == 0 then
        winner = "Предатель"
    end
    
    -- Отправляем информацию о победителе на клиент для отображения прямоугольника
    if HG_Armor_RoundEndCleanup then HG_Armor_RoundEndCleanup() end
    net.Start("Homigrad_RoundEnd")
        net.WriteString("homicide")
        net.WriteString(winner)
        net.WriteString(traitorNames)
    net.Broadcast()
end