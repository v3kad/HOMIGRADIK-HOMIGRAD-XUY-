-- Homigrad: simple camera bob while walking/sprinting

local bobTime = 0
local function GetBobStrength(ply, speed2D)
	local base = 0.2 -- base amplitude
	-- scale with speed; sprint a bit stronger
	local isSprint = ply:GetNWBool("HG_IsSprinting", false)
	local scale = math.Clamp(speed2D / 200, 0, 1)
	local mult = isSprint and 1.6 or 1.0
	return base * scale * mult
end

-- Если используется головная камера, не вмешиваемся
if HG_UseHeadCam then return end

hook.Add("CalcView", "HG_CameraBob", function(ply, pos, ang, fov)
	if not IsValid(ply) then return end
	if not ply:Alive() then return end
	if ply:GetObserverMode() ~= OBS_MODE_NONE then return end

	local vel = ply:GetVelocity()
	local speed2D = vel:Length2D()
	if speed2D < 10 or not ply:OnGround() then return end

	-- advance time by movement speed to sync frequency
	bobTime = bobTime + FrameTime() * math.Clamp(speed2D / 120, 0.5, 2.2)

	local strength = GetBobStrength(ply, speed2D)
	local view = {}
	view.origin = pos + ang:Up() * (math.sin(bobTime * 8) * 0.5 + math.sin(bobTime * 4) * 0.25) * strength * 4

	local newAng = Angle(ang.p, ang.y, ang.r)
	newAng.p = newAng.p + math.sin(bobTime * 8) * strength * 2.0
	newAng.y = newAng.y + math.cos(bobTime * 8) * strength * 1.2
	newAng.r = newAng.r + math.sin(bobTime * 16) * strength * 1.5

	view.angles = newAng
	view.fov = fov
	return view
end)


