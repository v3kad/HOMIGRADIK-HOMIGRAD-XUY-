-- Homigrad Organism: basic stamina system
-- Shared definitions

local PLAYER = FindMetaTable("Player")

local NW_STAMINA = "HG_Stamina"
local NW_SPRINTING = "HG_IsSprinting"
local NW_BLOOD = "HG_Blood"      -- Новая NW переменная
local NW_BLEEDING = "HG_Bleeding"   -- Переменная-состояние кровотечения
local NW_PAIN = "HG_Pain"
local NW_BULLET_WOUNDS = "HG_BulletWounds"
local NW_BROKEN_LEG = "HG_BrokenLeg"
local NW_BROKEN_SPINE = "HG_BrokenSpine"
local NW_BLACKOUT = "HG_Blackout"

-- Config
local MAX_STAMINA = 100
local SPRINT_DRAIN_PER_SEC = 18
local IDLE_REGEN_PER_SEC = 12
local WALK_REGEN_PER_SEC = 8
local JUMP_COST = 15

local LOW_STAMINA_THRESHOLD = 15
local NORMAL_WALK = 120
local NORMAL_RUN = 260
local TIRED_RUN = 200

local MAX_BLOOD = 5000           -- в мл (5 литров)
local BLEEDING_INTERVAL = 1  -- интервал тика кровотечения (сек)
local BLEEDING_BLOOD_LOSS_PER_SEC = 30 -- мл в секунду (примерное значение)
local BLOOD_LOSS_PER_WOUND_PER_SEC = 1 -- мл/сек за каждое огнестрельное ранение

local MAX_PAIN = 100

-- BLEED EFFECT
local BLOOD_DECAL_PATH = "ztarkov/blood1"
local BLOOD_DECAL_MAT = Material(BLOOD_DECAL_PATH)
local BLOOD_DRIP_INTERVAL_WEAK = 2.5 -- при обычном кровотечении
local BLOOD_DRIP_INTERVAL_STRONG = 1 -- при сильном (огнестрел) кровотечении

-- Белый список острых мили, вызывающих кровотечение
local SHARP_MELEE = {
    ["weapon_hg_kitknife"] = true,
    ["weapon_hg_machete"] = true,
    ["weapon_hg_fireaxe"] = true,
    ["weapon_hg_hatchet"] = true,
}

-- Настраиваемые эффекты мили по классам оружия
-- painSlash/painClub: сколько боли добавить при резе/ударе
-- bleed: 0=нет, 1=слабое, 2=сильное кровотечение
local MELEE_EFFECTS = {
    ["weapon_hg_kitknife"] = { painSlash = 5, bleed = 1 },
    ["weapon_hg_machete"]  = { painSlash = 12, bleed = 2 },
    ["weapon_hg_fireaxe"]  = { painSlash = 10, bleed = 2 },
    ["weapon_hg_hatchet"]  = { painSlash = 7, bleed = 1 },
    ["weapon_hg_metalpipe"]  = { painSlash = 5, bleed = 0 },
    ["weapon_hg_wrench"]  = { painSlash = 6, bleed = 0 },
    ["weapon_hg_sleagehammer"]  = { painSlash = 13, bleed = 0 },
    ["weapon_hg_crowbar"]  = { painSlash = 10, bleed = 0 },
    ["weapon_hg_metalbat"]  = { painSlash = 6, bleed = 0 },
    ["weapon_hg_shovel"]  = { painSlash = 6, bleed = 0 },
    ["weapon_hg_fubar"]  = { painSlash = 13, bleed = 0 },
    ["weap_hands"]  = { painSlash = 1, bleed = 0 }, -- руки
    -- Пример для тупого оружия: боль повышенная, кровотечения нет
    -- ["weapon_hg_crowbar"] = { painClub = 12, bleed = 0 },
}

function PLAYER:GetHGStamina()
	return self:GetNWFloat(NW_STAMINA, MAX_STAMINA)
end

function PLAYER:SetHGStamina(value)
	self:SetNWFloat(NW_STAMINA, math.Clamp(value or 0, 0, MAX_STAMINA))
end

function PLAYER:AddHGStamina(delta)
	self:SetHGStamina(self:GetHGStamina() + (delta or 0))
end

function PLAYER:GetHGBlood()
    return self:GetNWInt(NW_BLOOD, MAX_BLOOD)
end

function PLAYER:SetHGBlood(amount)
    self:SetNWInt(NW_BLOOD, math.Clamp(amount or 0, 0, MAX_BLOOD))
end

function PLAYER:AddHGBlood(delta)
    self:SetHGBlood(self:GetHGBlood() + (delta or 0))
end

function PLAYER:IsHGBleeding()
    return self:GetNWInt(NW_BLEEDING, 0) > 0
end

function PLAYER:SetHGBleeding(rate)
    -- rate: 0 = нет, 1 = обычный, 2 = сильный (огнестрел)
    self:SetNWInt(NW_BLEEDING, rate)
end
function PLAYER:GetHGBleedingRate()
    return self:GetNWInt(NW_BLEEDING, 0)
end

function PLAYER:GetHGPain()
	return self:GetNWInt(NW_PAIN, 0)
end

function PLAYER:SetHGPain(value)
	self:SetNWInt(NW_PAIN, math.Clamp(tonumber(value) or 0, 0, MAX_PAIN))
end

function PLAYER:AddHGPain(delta)
	self:SetHGPain(self:GetHGPain() + (delta or 0))
end

function PLAYER:GetHGBulletWounds()
	return self:GetNWInt(NW_BULLET_WOUNDS, 0)
end

function PLAYER:SetHGBulletWounds(count)
	self:SetNWInt(NW_BULLET_WOUNDS, math.max(0, math.floor(tonumber(count) or 0)))
end

function PLAYER:AddHGBulletWounds(delta)
	self:SetHGBulletWounds(self:GetHGBulletWounds() + (delta or 0))
end

function PLAYER:HasHGBrokenLeg()
    return self:GetNWBool(NW_BROKEN_LEG, false)
end

function PLAYER:SetHGBrokenLeg(broken)
    self:SetNWBool(NW_BROKEN_LEG, broken and true or false)
end

function PLAYER:HasHGBrokenSpine()
    return self:GetNWBool(NW_BROKEN_SPINE, false)
end

function PLAYER:SetHGBrokenSpine(broken)
    self:SetNWBool(NW_BROKEN_SPINE, broken and true or false)
end

if SERVER then

    if util and util.AddNetworkString then
        util.AddNetworkString("HG_BloodDecal")
    end

    if game and game.AddDecal then
        -- Register custom decal name mapped to our material so util.Decal can place it reliably
        game.AddDecal("HG_Blood", BLOOD_DECAL_PATH)
    end

	local function InitPlayerStamina(ply)
		ply:SetHGStamina(MAX_STAMINA)
		ply:SetNWBool(NW_SPRINTING, false)
		ply:SetRunSpeed(NORMAL_RUN)
		ply:SetWalkSpeed(NORMAL_WALK)
		ply:SetHGBlood(MAX_BLOOD) -- инициализация крови при спавне
		ply:SetHGBleeding(0) -- был false, теперь 0
		ply:SetHGPain(0)
		ply:SetHGBulletWounds(0)
		ply:SetHGBrokenLeg(false)
		ply:SetHGBrokenSpine(false)
		ply:SetNWBool(NW_BLACKOUT, false)
		-- Полностью отключаем влияние стандартного здоровья
		ply:SetMaxHealth(100)
		ply:SetHealth(100)
	end

	local function ResetOrganismOnDeath(ply)
		if not IsValid(ply) then return end
		ply:SetHGBleeding(0)
		ply:SetHGPain(0)
		ply:SetHGBrokenLeg(false)
		ply:SetHGBrokenSpine(false)
		ply:SetNWBool(NW_BLACKOUT, false)
		ply:SetNWBool(NW_SPRINTING, false)
		ply:SetNWBool("hg_pain_ragdoll", false)
		ply:SetHGStamina(MAX_STAMINA)
		-- очистка локальных трекеров эффектов крови
		ply._hgNextBloodDrop = nil
		ply._hgLastBloodDrop = nil
	end

	hook.Add("PlayerSpawn", "HG_Organism_Init", function(ply)
		InitPlayerStamina(ply)
	end)

	hook.Add("PlayerDeath", "HG_Organism_ResetOnDeath", function(ply)
		ResetOrganismOnDeath(ply)
	end)

	-- Snapshot bullet wounds to corpse ragdoll so they persist after respawn
	hook.Add("CreateEntityRagdoll", "HG_SnapshotWoundsOnCorpse", function(ent, rag)
		if not IsValid(ent) or not ent:IsPlayer() then return end
		if not IsValid(rag) or rag:GetClass() ~= "prop_ragdoll" then return end
		local wounds = ent.GetHGBulletWounds and ent:GetHGBulletWounds() or 0
		rag:SetNWInt("HG_BulletWoundsSnapshot", math.max(0, wounds))
		-- also store owner reference for consistency with control ragdolls
		rag:SetNWEntity("hg_ragdoll_owner", ent)
		-- make PlayerDeath aware of this ragdoll to avoid spawning a duplicate
		if ent.SetNWEntity then
			ent:SetNWEntity("hg_ragdoll_entity", rag)
		end
	end)

	-- Drain on jump
	hook.Add("KeyPress", "HG_Organism_JumpDrain", function(ply, key)
		if key == IN_JUMP and ply:Alive() then
			ply:AddHGStamina(-JUMP_COST)
		end
	end)

	-- Main stamina think
	hook.Add("Think", "HG_Organism_Think", function()
		local ft = FrameTime()
		for _, ply in ipairs(player.GetAll()) do
			if not IsValid(ply) or not ply:Alive() then continue end

			local vel = ply:GetVelocity():Length2D()
			local isMoving = vel > 10
			local isSprinting = isMoving and ply:KeyDown(IN_SPEED) and ply:OnGround()

			local stamina = ply:GetHGStamina()
			if isSprinting and stamina > 0 then
				stamina = stamina - SPRINT_DRAIN_PER_SEC * ft
				ply:SetNWBool(NW_SPRINTING, true)
			else
				local regen = isMoving and WALK_REGEN_PER_SEC or IDLE_REGEN_PER_SEC
				stamina = stamina + regen * ft
				ply:SetNWBool(NW_SPRINTING, false)
			end

			stamina = math.Clamp(stamina, 0, MAX_STAMINA)
			ply:SetHGStamina(stamina)

			-- Speed: tired vs normal, apply broken leg cap and pain scaling
			local baseRun = (stamina <= LOW_STAMINA_THRESHOLD) and TIRED_RUN or NORMAL_RUN
			local baseWalk = NORMAL_WALK
			local pain = ply.GetHGPain and ply:GetHGPain() or 0
			local painFactor = 1.0
			if pain >= 30 then
				painFactor = 0.1
			elseif pain >= 20 then
				painFactor = 0.2
			elseif pain >= 10 then
				painFactor = 0.3
			end
			-- If leg is broken, hard-cap speeds to 30% of base
			local brokenCap = (ply.HasHGBrokenLeg and ply:HasHGBrokenLeg()) and 0.3 or 1.0
			local targetRun = baseRun * math.min(painFactor, brokenCap)
			local targetWalk = baseWalk * math.min(painFactor, brokenCap)
			if ply:GetRunSpeed() ~= targetRun then
				ply:SetRunSpeed(targetRun)
			end
			if ply:GetWalkSpeed() ~= targetWalk then
				ply:SetWalkSpeed(targetWalk)
			end

			-- While truly walking with a broken leg, add pain over time: +3 per second
			if brokenCap < 1.0 then
				local pressingMove = ply:KeyDown(IN_FORWARD) or ply:KeyDown(IN_BACK) or ply:KeyDown(IN_MOVELEFT) or ply:KeyDown(IN_MOVERIGHT)
				local grounded = ply:OnGround()
				local notRagdolled = (not HG_IsRagdolled) or (HG_IsRagdolled and not HG_IsRagdolled(ply))
				if grounded and notRagdolled and pressingMove and vel > 60 then
					if ply.AddHGPain then ply:AddHGPain(3 * ft) end
				end
			end

			-- Pain threshold ragdoll: fall at >=35 and stay down until pain < 35
			if HG_StartRagdoll and HG_IsRagdolled and HG_IsForcedRagdoll and HG_StopRagdoll then
				local PAIN_RAGDOLL_THRESHOLD = 35
				if pain >= PAIN_RAGDOLL_THRESHOLD then
					if not HG_IsRagdolled(ply) then
						HG_StartRagdoll(ply, true)
					else
						-- already ragdolled: ensure forced flag stays while pain is high
						if not HG_IsForcedRagdoll(ply) then
							-- mark as forced to block manual stand up while above threshold
							ply:SetNWBool("hg_pain_ragdoll", true)
						end
					end
				end
			end

			-- Unconsciousness (blackout) when pain > 50; wake up when pain < 45
			local wasBlack = ply:GetNWBool(NW_BLACKOUT, false)
			local nowBlack = wasBlack
			if pain > 50 then
				nowBlack = true
			elseif pain < 45 then
				nowBlack = false
			end
			if nowBlack ~= wasBlack then
				ply:SetNWBool(NW_BLACKOUT, nowBlack)
				if nowBlack and HG_StartRagdoll then
					HG_StartRagdoll(ply, true)
				end
			end

			-- Смерть только по нашим условиям: боль 100 или кровь <= 1л
			if (ply.GetHGPain and ply:GetHGPain() >= MAX_PAIN) then
				ply:Kill()
				continue
			end
		end
	end)

    -- Main bleeding think
    timer.Create("HG_Bleeding_Think", BLEEDING_INTERVAL, 0, function()
        for _, ply in ipairs(player.GetAll()) do
            if not IsValid(ply) or not ply:Alive() then continue end
            -- Потеря крови от огнестрельных ранений и активного кровотечения
            local wounds = ply.GetHGBulletWounds and ply:GetHGBulletWounds() or 0
            local rate = ply.GetHGBleedingRate and ply:GetHGBleedingRate() or 0
            local lossPerSec = 0

            -- базовая потеря от кровотечения (например от резаных ран)
            if rate > 0 then
                local rateMul = (rate == 2) and 2 or 1 -- сильное кровотечение = x2
                lossPerSec = lossPerSec + (BLEEDING_BLOOD_LOSS_PER_SEC * rateMul)
            end

            -- дополнительная потеря от количества огнестрельных ран
            if wounds > 0 then
                lossPerSec = lossPerSec + (wounds * BLOOD_LOSS_PER_WOUND_PER_SEC)
            end

            if lossPerSec > 0 and ply:GetHGBlood() > 0 then
                ply:AddHGBlood(-(lossPerSec * BLEEDING_INTERVAL))
                if ply:GetHGBlood() <= 0 then
                    ply:SetHGBlood(0)
                    ply:Kill()
                end
            end
        end
    end)

    -- Public API: reset organism state for a player (admin tools, etc.)
    function HG_ResetOrganism(ply)
        if not IsValid(ply) or not ply:IsPlayer() then return end
        -- Restore vitals and statuses
        ply:SetHGStamina(MAX_STAMINA)
        ply:SetNWBool(NW_SPRINTING, false)
        ply:SetRunSpeed(NORMAL_RUN)
        ply:SetWalkSpeed(NORMAL_WALK)
        ply:SetHGBlood(MAX_BLOOD)
        ply:SetHGBleeding(0)
        ply:SetHGPain(0)
        ply:SetHGBulletWounds(0)
        ply:SetHGBrokenLeg(false)
        ply:SetHGBrokenSpine(false)
        ply:SetNWBool(NW_BLACKOUT, false)
        ply:SetNWBool("hg_pain_ragdoll", false)
        ply._hgNextBloodDrop = nil
        ply._hgLastBloodDrop = nil
        -- If player is ragdolled or forced, allow standing up
        if HG_StopRagdoll then HG_StopRagdoll(ply, true) end
    end

    hook.Add("PlayerSay", "HG_BlockChatWhenBlackout", function(ply, text, team)
        if not IsValid(ply) then return end
        if ply:GetNWBool(NW_BLACKOUT, false) then
            ply:ChatPrint("Вы без сознания и не можете говорить.")
            return ""
        end
    end)

    hook.Remove("EntityTakeDamage", "HG_Demo_BleedingOnDamage") -- убрать старый демо-хук

    hook.Add("EntityTakeDamage", "HG_BleedingOnBulletDamage2", function(target, dmginfo)
        if not IsValid(target) or not target:IsPlayer() then return end
        if not target:Alive() then return end
        -- If player is in ragdoll, ignore direct hits on the invisible player entity;
        -- damage is handled via the ragdoll forwarding hook instead
        if HG_IsRagdolled and HG_IsRagdolled(target) then return end

		-- Отключаем стандартный урон Garry's Mod для игроков
		dmginfo:SetDamage(0)
        if dmginfo:IsBulletDamage() then
            -- Armor mitigation branch: ScalePlayerDamage stores last hitgroup/bullet for this tick
            local hg = target._hg_lastHitgroup
            local lastIsBullet = target._hg_lastDmgIsBullet
            local mitigated = false
            if lastIsBullet then
                if hg == HITGROUP_HEAD and target:GetNWBool("HG_Helmet", false) then
                    mitigated = true
                    if HG_Armor_PlayImpact then HG_Armor_PlayImpact(target, true) end
                    local pos = dmginfo.GetDamagePosition and dmginfo:GetDamagePosition() or (target:EyePos() or target:GetPos())
                    if pos and pos ~= vector_origin then
                        if ParticleEffect then ParticleEffect("hs_impact_fx", pos, angle_zero) end
                    end
                elseif (hg == HITGROUP_CHEST or hg == HITGROUP_STOMACH) and target:GetNWBool("HG_Vest", false) then
                    mitigated = true
                    if HG_Armor_PlayImpact then HG_Armor_PlayImpact(target, false) end
                    local pos = dmginfo.GetDamagePosition and dmginfo:GetDamagePosition() or (target:GetPos() + Vector(0,0,40))
                    if pos and pos ~= vector_origin then
                        if ParticleEffect then ParticleEffect("hs_impact_fx", pos, angle_zero) end
                    end
                end
            end

            if hg == HITGROUP_LEFTARM or hg == HITGROUP_RIGHTARM or hg == HITGROUP_LEFTLEG or hg == HITGROUP_RIGHTLEG then
                if target:GetHGBleedingRate() < 2 then
                    target:SetHGBleeding(2)
                    target:ChatPrint("Вы начали сильно кровоточить от огнестрельного ранения!")
                end
                target:AddHGBulletWounds(1)
            elseif mitigated then
                target:AddHGBulletWounds(1)
                target:AddHGPain(8)
            else
                if target:GetHGBleedingRate() < 2 then
                    target:SetHGBleeding(2)
                    target:ChatPrint("Вы начали сильно кровоточить от огнестрельного ранения!")
                end
                target:AddHGBulletWounds(1)
                target:AddHGPain(15)
            end
        else
            -- Милли/прочий урон (старое поведение)
            local dt = dmginfo:GetDamageType() or 0
            local isSlash = bit and bit.band(dt, DMG_SLASH) ~= 0
            local isClub = bit and bit.band(dt, DMG_CLUB) ~= 0
            if isSlash or isClub then
                -- Avoid adding melee default pain if the recorded hit was a bullet to limbs
                local lastHG = target._hg_lastHitgroup
                local lastIsBullet = target._hg_lastDmgIsBullet
                local limbShot = lastHG == HITGROUP_LEFTARM or lastHG == HITGROUP_RIGHTARM or lastHG == HITGROUP_LEFTLEG or lastHG == HITGROUP_RIGHTLEG

                local weaponClass
                local inf = dmginfo:GetInflictor()
                if IsValid(inf) and inf.IsWeapon and inf:IsWeapon() then
                    weaponClass = inf:GetClass()
                end
                if not weaponClass then
                    local atk = dmginfo:GetAttacker()
                    if IsValid(atk) and atk.IsPlayer and atk:IsPlayer() then
                        local w = atk:GetActiveWeapon()
                        if IsValid(w) then
                            weaponClass = w:GetClass()
                        end
                    end
                end
                local cfg = weaponClass and MELEE_EFFECTS[weaponClass] or nil
                local painToAdd
                if cfg then
                    if isSlash then painToAdd = cfg.painSlash or 12 else painToAdd = cfg.painClub or 10 end
                else
                    painToAdd = isSlash and 12 or 10
                end
                -- One-shot suppression if limb bullet pain was already applied in ScalePlayerDamage
                local suppressed = target._hg_suppressPainOnce
                if suppressed then target._hg_suppressPainOnce = nil end
                if not suppressed and not (lastIsBullet and limbShot) then
                    if target.AddHGPain and painToAdd and painToAdd > 0 then target:AddHGPain(painToAdd) end
                end
                if isSlash then
                    local desiredBleed = nil
                    if cfg and cfg.bleed ~= nil then
                        desiredBleed = tonumber(cfg.bleed) or 0
                    else
                        if weaponClass and SHARP_MELEE[weaponClass] then desiredBleed = 1 end
                    end
                    if desiredBleed and desiredBleed > 0 then
                        local cur = target:GetHGBleedingRate()
                        if desiredBleed > cur then
                            target:SetHGBleeding(desiredBleed)
                            if desiredBleed >= 2 then target:ChatPrint("Вы начали сильно кровоточить!") else target:ChatPrint("Вы начали кровоточить!") end
                        end
                    end
                end
            end
        end
    end)

    -- Extra pain on head damage: bullets and melee, and record hitgroup for armor mitigation
    hook.Add("ScalePlayerDamage", "HG_Headshot_AddPain", function(ply, hitgroup, dmginfo)
        if not IsValid(ply) or not ply:IsPlayer() then return end
        if not ply:Alive() then return end
        if HG_IsRagdolled and HG_IsRagdolled(ply) then return end
        -- Record last hitgroup and bullet flag for EntityTakeDamage
        ply._hg_lastHitgroup = hitgroup
        ply._hg_lastDmgIsBullet = dmginfo:IsBulletDamage()
        if hitgroup == HITGROUP_HEAD then
            local add = 0
            if dmginfo:IsBulletDamage() then
                if ply:GetNWBool("HG_Helmet", false) then
                    add = 7
                else
                    add = 15
                end
            else
                local dt = dmginfo:GetDamageType() or 0
                local isSlash = bit and bit.band(dt, DMG_SLASH) ~= 0
                local isClub = bit and bit.band(dt, DMG_CLUB) ~= 0
                if isSlash or isClub then
                    add = 15
                end
            end
            if add > 0 and ply.AddHGPain then ply:AddHGPain(add) end
        elseif dmginfo:IsBulletDamage() and (hitgroup == HITGROUP_LEFTARM or hitgroup == HITGROUP_RIGHTARM or hitgroup == HITGROUP_LEFTLEG or hitgroup == HITGROUP_RIGHTLEG) then
            if ply.AddHGPain then ply:AddHGPain(5) end
            -- mark to suppress any immediate follow-up melee pain misclassification
            ply._hg_suppressPainOnce = true
        end
    end)

    -- эффекты крови
    timer.Create("HG_BloodDrip", 0.2, 0, function()
        local ok, err = pcall(function()
            for _,ply in ipairs(player.GetAll()) do
                if not IsValid(ply) or not ply:Alive() then
                    ply._hgNextBloodDrop = nil
                    ply._hgLastBloodDrop = nil
                    continue
                end

                local bleeding = ply:IsHGBleeding()
                local wounds = ply.GetHGBulletWounds and ply:GetHGBulletWounds() or 0
                if not bleeding and wounds <= 0 then
                    ply._hgNextBloodDrop = nil
                    ply._hgLastBloodDrop = nil
                    continue
                end

                local rate = ply:GetHGBleedingRate()
                local interval = (rate == 2) and BLOOD_DRIP_INTERVAL_STRONG or BLOOD_DRIP_INTERVAL_WEAK
                if rate == 0 and wounds > 0 then
                    interval = BLOOD_DRIP_INTERVAL_WEAK
                end

                -- watchdog: если давно не капало, перезапускаем
                local now = CurTime()
                if ply._hgLastBloodDrop and (now - ply._hgLastBloodDrop) > (interval * 3) then
                    ply._hgNextBloodDrop = now + math.Rand(0, interval * 0.5)
                end

                ply._hgNextBloodDrop = ply._hgNextBloodDrop or now + math.Rand(0, interval)
                if now >= ply._hgNextBloodDrop then
                    local drops = 1 + math.floor(math.max(0, wounds - 1) / 2)
                    local vel = ply:GetVelocity()
                    local backDir = vel:Length2D() > 20 and (-vel:GetNormalized()) or VectorRand()
                    backDir.z = 0
                    backDir:Normalize()

					-- Prefer dripping from ragdoll body parts when ragdolled
					local rag = ply:GetNWEntity("hg_ragdoll_entity")
					local function GetRagPos()
						if not IsValid(rag) then return nil end
						local preferred = {
							"ValveBiped.Bip01_Pelvis",
							"ValveBiped.Bip01_Spine",
							"ValveBiped.Bip01_Spine1",
							"ValveBiped.Bip01_Spine2",
							"ValveBiped.Bip01_Head1",
							"ValveBiped.Bip01_L_Thigh",
							"ValveBiped.Bip01_R_Thigh",
						}
						local name = preferred[math.random(1, #preferred)]
						local idx = rag:LookupBone(name) or -1
						if idx and idx >= 0 then
							local pos = rag:GetBonePosition(idx)
							if pos and pos ~= vector_origin then return pos end
						end
						return rag:GetPos()
					end

					for i = 1, drops do
						local origin
						if IsValid(rag) then
							origin = GetRagPos() or rag:GetPos()
						else
							origin = ply:GetPos() + Vector(0, 0, 6)
						end
						local radial = Angle(0, math.Rand(0, 360), 0):Forward()
						local spread = 6 + math.random(0, 10)
						local offset = (backDir * (8 + math.random(0, 12))) + (radial * spread)
						local startPos = origin + offset

                        -- трасса вниз
                        local tr = util.TraceLine({start = startPos, endpos = startPos + Vector(0, 0, -200), filter = ply})
                        if not tr.Hit then
                            local mins = Vector(-6, -6, -2)
                            local maxs = Vector(6, 6, 2)
                            tr = util.TraceHull({start = startPos, endpos = startPos + Vector(0, 0, -200), mins = mins, maxs = maxs, filter = ply})
                        end
                        if not tr.Hit then
                            tr = util.QuickTrace(startPos, Vector(0, 0, -200), ply)
                        end
                        if tr.Hit then
                            util.Decal("HG_Blood", tr.HitPos + tr.HitNormal * 2, tr.HitPos - tr.HitNormal * 2)
                            if net then
                                net.Start("HG_BloodDecal")
                                    net.WriteVector(tr.HitPos)
                                    net.WriteVector(tr.HitNormal)
                                net.Broadcast()
                            end
                            sound.Play("bloodsplashing/drip_2.wav", tr.HitPos, 65, 100, 0.6)
                        end
                    end
                end
            end
        end)
        if not ok then
            -- не даём таймеру умереть из-за случайной ошибки
            if SERVER then
                print("[HG] Blood drip error: ", err)
            end
        end
    end)

    -- медленное снижение боли
    local PAIN_DECAY_PER_SEC = 0.5
    timer.Create("HG_PainDecay", 1, 0, function()
        for _, ply in ipairs(player.GetAll()) do
            if not IsValid(ply) or not ply:Alive() then continue end
            local pain = ply.GetHGPain and ply:GetHGPain() or 0
            if pain > 0 then
                ply:SetHGPain(math.max(0, pain - PAIN_DECAY_PER_SEC))
            end
        end
    end)

    -- критический порог крови: 1 литр (1000 мл)
    local CRITICAL_BLOOD_ML = 1000
    timer.Create("HG_BloodCriticalCheck", 0.5, 0, function()
        for _, ply in ipairs(player.GetAll()) do
            if not IsValid(ply) or not ply:Alive() then continue end
            local blood = ply.GetHGBlood and ply:GetHGBlood() or MAX_BLOOD
            if blood <= CRITICAL_BLOOD_ML then
                ply:SetHGBlood(math.max(0, blood))
                ply:Kill()
            end
        end
    end)
    end

    if CLIENT then
        local hudEnabled = false
        local INSPECT_MAX_DISTANCE_CVAR = CreateClientConVar("hg_inspect_max_distance", "300", true, false, "Max distance for pulse/inspect in units.")
        local function HG_GetInspectMaxDistance()
            return math.max(0, INSPECT_MAX_DISTANCE_CVAR:GetFloat() or 0)
        end
        local vignettePainLerp = 0
        local bloodBlurLerp = 0
        local gradL = Material("vgui/gradient-l")
        local gradR = Material("vgui/gradient-r")
        local gradU = Material("vgui/gradient-u")
        local gradD = Material("vgui/gradient-d")
        local matBlurScreen = Material("pp/blurscreen")

        -- Client: mute sounds while unconscious
        hook.Add("EntityEmitSound", "HG_Blackout_Mute", function(data)
            local lp = LocalPlayer()
            if not IsValid(lp) then return end
            if lp:GetNWBool(NW_BLACKOUT, false) then
                return true -- block sound for this client
            end
        end)

        concommand.Add("hg_organism", function()
            local lp = LocalPlayer()
            if not IsValid(lp) then return end
            if not lp:IsAdmin() then
                chat.AddText(Color(255,80,80), "[HG] Команда доступна только администраторам")
                return
            end
            hudEnabled = not hudEnabled
            chat.AddText(Color(120,220,120), "[HG] Организм HUD: ", hudEnabled and Color(0,255,0) or Color(255,0,0), hudEnabled and "ВКЛ" or "ВЫКЛ")
        end)

        hook.Add("HUDPaint", "HG_OrganismHUD", function()
            local lp = LocalPlayer()
            if not IsValid(lp) then return end

            -- Pain vignette (always on client)
            local pain = lp.GetHGPain and lp:GetHGPain() or 0
            -- стартовать эффект с порога 5
            local norm = 0
            if MAX_PAIN > 5 then
                local raw = math.Clamp((pain - 5) / (MAX_PAIN - 5), 0, 1)
                -- минимальная видимость эффекта сразу на 5 боли
                norm = (pain >= 5) and math.max(raw, 0.99) or 0
            end
            vignettePainLerp = Lerp(FrameTime() * 6, vignettePainLerp, norm)
            if vignettePainLerp > 0.01 then
                local sw, sh = ScrW(), ScrH()
                local minDim = math.min(sw, sh)
                -- при боли 40 толщина каждого края ~40% от minDim => покрытие ~80%
                local coverageScale = math.Clamp((pain) / 40, 0, 1) -- 0..1, где 1 соответствует боли 40
                local edge = math.max(32, math.floor(minDim * 0.99 * coverageScale))
                -- без пульсации, чтобы не мерцало
                local pulse = 1
                local baseAlpha = math.floor(210 * vignettePainLerp)
                local r, g, b = 200, 20, 20

                -- Левый край
                surface.SetMaterial(gradL)
                surface.SetDrawColor(r, g, b, baseAlpha)
                surface.DrawTexturedRect(0, 0, edge * pulse, sh)
                -- Правый край
                surface.SetMaterial(gradR)
                surface.SetDrawColor(r, g, b, baseAlpha)
                surface.DrawTexturedRect(sw - edge * pulse, 0, edge * pulse, sh)
                -- Верхний край
                surface.SetMaterial(gradU)
                surface.SetDrawColor(r, g, b, math.floor(baseAlpha * 0.9))
                surface.DrawTexturedRect(0, 0, sw, edge * pulse)
                -- Нижний край
                surface.SetMaterial(gradD)
                surface.SetDrawColor(r, g, b, math.floor(baseAlpha * 0.9))
                surface.DrawTexturedRect(0, sh - edge * pulse, sw, edge * pulse)

                -- Мягкое дополнительное затемнение для глубины
                surface.SetDrawColor(r, g, b, math.floor(baseAlpha * 0.4))
                surface.SetMaterial(gradL)
                surface.DrawTexturedRect(0, 0, edge * 0.6 * pulse, sh)
                surface.SetMaterial(gradR)
                surface.DrawTexturedRect(sw - edge * 0.6 * pulse, 0, edge * 0.6 * pulse, sh)
            end

            -- Full black screen when unconscious
            if lp:GetNWBool(NW_BLACKOUT, false) then
                surface.SetDrawColor(0, 0, 0, 255)
                surface.DrawRect(0, 0, ScrW(), ScrH())
                local sw, sh = ScrW(), ScrH()
                local msg = "Вы потеряли сознание"
                draw.SimpleText(msg, "DermaLarge", sw * 0.5 + 1, sh * 0.5 + 1, Color(0, 0, 0, 200), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                draw.SimpleText(msg, "DermaLarge", sw * 0.5, sh * 0.5, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                return -- don't draw any HUD
            end

            if not hudEnabled then return end

            -- self HUD (top-right)
            local blood = lp.GetHGBlood and lp:GetHGBlood() or 0
            local stamina = lp.GetHGStamina and lp:GetHGStamina() or 0

            local w, h = 220, 74
            local x, y = ScrW() - w - 20, 20

            surface.SetDrawColor(0, 0, 0, 160)
            surface.DrawRect(x, y, w, h)
            surface.SetDrawColor(255, 255, 255, 40)
            surface.DrawOutlinedRect(x, y, w, h)

            draw.SimpleText("Кровь: " .. math.floor(blood) .. " мл", "DermaDefault", x + 8, y + 8, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
            draw.SimpleText("Стамина: " .. math.floor(stamina), "DermaDefault", x + 8, y + 28, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
            draw.SimpleText("Боль: " .. math.floor(pain), "DermaDefault", x + 8, y + 48, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

            -- target HUD (top-left) when aiming at a player
            local tr = lp:GetEyeTrace()
            local tEnt = IsValid(tr.Entity) and tr.Entity or nil
            local targetPly = nil
            if IsValid(tEnt) then
                if tEnt:IsPlayer() then
                    targetPly = tEnt
                elseif tEnt:GetClass() == "prop_ragdoll" then
                    -- Try direct owner reference first
                    local owner = tEnt:GetNWEntity("hg_ragdoll_owner")
                    if IsValid(owner) and owner:IsPlayer() then
                        targetPly = owner
                    end
                    -- Fallback: find a player whose active ragdoll matches this entity
                    if not IsValid(targetPly) then
                        for _, p in ipairs(player.GetAll()) do
                            local rag = IsValid(p) and p:GetNWEntity("hg_ragdoll_entity") or nil
                            if IsValid(rag) and rag == tEnt then
                                targetPly = p
                                break
                            end
                        end
                    end
                end
            end

            if IsValid(targetPly) and targetPly ~= lp then
                local dist = lp:GetPos():DistToSqr((IsValid(tEnt) and tEnt:GetPos()) or targetPly:GetPos())
                local maxd = HG_GetInspectMaxDistance()
                if dist <= (maxd * maxd) then
                    local tblood = targetPly.GetHGBlood and targetPly:GetHGBlood() or 0
                    local tstamina = targetPly.GetHGStamina and targetPly:GetHGStamina() or 0
                    local tpain = targetPly.GetHGPain and targetPly:GetHGPain() or 0

                    local tw, th = 240, 74
                    local tx, ty = 20, 20
                    surface.SetDrawColor(0, 0, 0, 160)
                    surface.DrawRect(tx, ty, tw, th)
                    surface.SetDrawColor(255, 255, 255, 40)
                    surface.DrawOutlinedRect(tx, ty, tw, th)

                    draw.SimpleText(string.format("[%s]", targetPly:Nick()), "DermaDefault", tx + 8, ty - 12, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
                    draw.SimpleText("Кровь: " .. math.floor(tblood) .. " мл", "DermaDefault", tx + 8, ty + 8, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
                    draw.SimpleText("Стамина: " .. math.floor(tstamina), "DermaDefault", tx + 8, ty + 28, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
                    draw.SimpleText("Боль: " .. math.floor(tpain), "DermaDefault", tx + 8, ty + 48, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
                end
            end
        end)

        -- Inspect on R key: prints basic vitals of the aimed player/ragdoll (client-only)
        do
            local lastPress = 0
            local PRESS_CD = 0.2
            local function ResolveTargetPlayerFromTrace(lp)
                local tr = lp:GetEyeTrace()
                local tEnt = IsValid(tr.Entity) and tr.Entity or nil
                local targetPly = nil
                if IsValid(tEnt) then
                    if tEnt:IsPlayer() then
                        targetPly = tEnt
                    elseif tEnt:GetClass() == "prop_ragdoll" then
                        local owner = tEnt:GetNWEntity("hg_ragdoll_owner")
                        if IsValid(owner) and owner:IsPlayer() then
                            targetPly = owner
                        end
                        if not IsValid(targetPly) then
                            for _, p in ipairs(player.GetAll()) do
                                local rag = IsValid(p) and p:GetNWEntity("hg_ragdoll_entity") or nil
                                if IsValid(rag) and rag == tEnt then
                                    targetPly = p
                                    break
                                end
                            end
                        end
                    end
                end
                return tEnt, targetPly
            end

            hook.Add("PlayerBindPress", "HG_InspectOnR", function(ply, bind, pressed)
                if ply ~= LocalPlayer() then return end
                if not pressed then return end
                if (bind ~= "+reload" and bind ~= "reload") then return end

                local now = CurTime()
                if now < (lastPress + PRESS_CD) then return end
                lastPress = now

                local lp = LocalPlayer()
                if not IsValid(lp) then return end
                local tEnt, targetPly = ResolveTargetPlayerFromTrace(lp)
                if not IsValid(tEnt) then return end

                local isRag = tEnt:GetClass() == "prop_ragdoll"
                if (not isRag) and (not tEnt:IsPlayer()) then return end

                -- distance check (use same max as HUD)
                local from = lp:GetShootPos() or lp:GetPos()
                local to = (IsValid(tEnt) and tEnt:GetPos()) or from
                local maxd = HG_GetInspectMaxDistance()
                if from:DistToSqr(to) > (maxd * maxd) then return end

                local snap = isRag and tEnt:GetNWInt("HG_BulletWoundsSnapshot", -1) or -1
                if IsValid(targetPly) and targetPly ~= lp then
                    local pulse = (targetPly:Alive() and (targetPly.GetHGBlood and targetPly:GetHGBlood() or 0) > 0)
                    local conc = not targetPly:GetNWBool("HG_Blackout", false)
                    local wounds = (snap >= 0) and snap or (targetPly.GetHGBulletWounds and targetPly:GetHGBulletWounds() or 0)
                    chat.AddText(Color(200, 200, 255), pulse and "Пульс есть" or "Пульса нет")
                    chat.AddText(Color(200, 200, 255), conc and "В сознании" or "Без сознания")
                    chat.AddText(Color(200, 200, 255), "Огнестрельных ранений: ", Color(255,255,255), tostring(wounds))
                elseif isRag then
                    -- Unknown owner (likely corpse): prefer snapshot if present
                    local wounds = (snap >= 0) and snap or 0
                    chat.AddText(Color(200, 200, 255), "Пульса нет")
                    chat.AddText(Color(200, 200, 255), "Без сознания")
                    chat.AddText(Color(200, 200, 255), "Огнестрельных ранений: ", Color(255,255,255), tostring(wounds))
                end
            end)
        end

        -- Десатурация и размытие экрана от потери крови
        hook.Add("RenderScreenspaceEffects", "HG_BloodDesaturation", function()
            local lp = LocalPlayer()
            if not IsValid(lp) then return end
            -- Сбрасываем размытие при смерти, чтобы эффект от низкой крови не оставался у наблюдателя
            if not lp:Alive() then
                bloodBlurLerp = 0
                return
            end
            local blood = lp.GetHGBlood and lp:GetHGBlood() or MAX_BLOOD
            local frac = math.Clamp(blood / MAX_BLOOD, 0, 1) -- 1 = полная насыщенность, 0 = минимум
            local saturation = Lerp(frac, 0.2, 1.0) -- при 0 крови ~20% цвета, при 100% крови 100%
            local tab = {
                ["$pp_colour_addr"] = 0,
                ["$pp_colour_addg"] = 0,
                ["$pp_colour_addb"] = 0,
                ["$pp_colour_brightness"] = 0,
                ["$pp_colour_contrast"] = 1,
                ["$pp_colour_colour"] = saturation,
                ["$pp_colour_mulr"] = 0,
                ["$pp_colour_mulg"] = 0,
                ["$pp_colour_mulb"] = 0
            }
            DrawColorModify(tab)

            -- Чем меньше крови, тем сильнее настоящее размытие экрана (гаусс)
            -- targetBlur: 0 при полной крови, до 1 при нуле крови
            local targetBlur = 1 - frac
            -- небольшой порог, чтобы не размывать при почти полном здоровье
            targetBlur = math.Clamp((targetBlur - 0.1) / 0.9, 0, 1)
            bloodBlurLerp = Lerp(FrameTime() * 4, bloodBlurLerp, targetBlur)
            if bloodBlurLerp > 0.001 then
                local sw, sh = ScrW(), ScrH()
                -- масштаб силы размытия (0..~8)
                local amount = math.Clamp(bloodBlurLerp * 6, 0, 8)
                surface.SetDrawColor(255, 255, 255, 255)
                surface.SetMaterial(matBlurScreen)
                for i = 1, 3 do
                    matBlurScreen:SetFloat("$blur", (i / 3) * amount)
                    matBlurScreen:Recompute()
                    render.UpdateScreenEffectTexture()
                    surface.DrawTexturedRect(0, 0, sw, sh)
                end
            end
        end)

        if net then
            net.Receive("HG_BloodDecal", function()
                local pos = net.ReadVector()
                local normal = net.ReadVector()
                util.Decal("Blood", pos + normal * 2, pos - normal * 2)
            end)
        end
    end
