-- addons/homigrad/gamemodes/homigrad/gamemode/modules/manager.lua
SubmodeManager = SubmodeManager or {}
SubmodeManager.submodes = SubmodeManager.submodes or {}
SubmodeManager.current = nil
SubmodeManager.timeLeft = 0
SubmodeManager.broadcastTimer = 0
SubmodeManager.waitingForPlayers = true
SubmodeManager.isEnding = false -- Флаг для предотвращения множественных завершений
SubmodeManager.isRoundStart = false -- Флаг для отслеживания начала раунда
SubmodeManager.nextModeID = nil -- Режим, выбранный админом для следующего раунда
SubmodeManager.scheduledNextID = nil -- Запланированный следующий режим (для точного отображения на клиенте)
SubmodeManager.scheduledNextDuration = nil -- Продолжительность запланированного режима

local MIN_PLAYERS = 2

local function collectSubmodes()
    SubmodeManager.submodes = {}
    for k,v in pairs(_G) do
        if type(v) == "table" and v.__homigrad_id then
            SubmodeManager.submodes[v.__homigrad_id] = v
        end
    end
end

-- Карты, на которых доступен только режим JailBreak
local JAILBREAK_ONLY_MAPS = {
    "jb_mars_lp",
    "jb_new_summer_v3",
    "jb_vipinthemix_v1_2",
    "ba_jail_electric_vip_v2",
    "jb_lego_jail_pre_v6-2"
}

-- Функция проверки доступности режима на текущей карте
local function isModeAvailable(mode)
    local currentMap = game.GetMap()
    
    -- Event доступен на любой карте (выбирается только через админ-меню, т.к. не в Sequence)
    if mode and mode.__homigrad_id == "event" then
        return true
    end
    
    -- Проверяем, не на карте JailBreak ли мы
    local isJailBreakMap = false
    -- Сначала по префиксам jb_ и ba_
    if string.StartWith(currentMap, "jb_") or string.StartWith(currentMap, "ba_") then
        isJailBreakMap = true
    else
        for _, mapName in ipairs(JAILBREAK_ONLY_MAPS) do
            if currentMap == mapName then
                isJailBreakMap = true
                break
            end
        end
    end
    
    -- Если мы на карте JailBreak, доступен только режим jailbreak
    if isJailBreakMap then
        if mode and mode.__homigrad_id == "jailbreak" then
            return true
        else
            return false
        end
    end
    
    -- Если режим имеет метод IsAvailable, используем его
    if mode and type(mode.IsAvailable) == "function" then
        return mode:IsAvailable()
    end
    
    -- Если режим jailbreak пытается запуститься на не-JailBreak карте, блокируем
    if mode and mode.__homigrad_id == "jailbreak" then
        return false
    end
    
    -- Если у режима нет метода IsAvailable, считаем его доступным всегда (кроме случаев выше)
    return true
end

function SubmodeManager:Initialize()
    collectSubmodes()
    self.order = {}
    for i,info in ipairs(SubmodeConfig.Sequence) do
        if self.submodes[info.id] then
            table.insert(self.order, { id = info.id, duration = info.duration })
        else
            print("[Homigrad] Warning: submode '"..tostring(info.id).."' not found")
        end
    end

    if #self.order == 0 then
        print("[Homigrad] No submodes registered - Homigrad will not run")
        return
    end

    self.waitingForPlayers = true
end

function SubmodeManager:StartNext()
    -- Сбрасываем флаг завершения
    self.isEnding = false
    
    -- Проверка на количество игроков
    if #player.GetAll() < MIN_PLAYERS then
        self.waitingForPlayers = true
        return
    end

    self.waitingForPlayers = false
    
    -- Выбираем режим: либо заданный админом, либо запланированный ранее, либо случайный
    local selectedEntry = nil
    local mode = nil
    
    -- Проверяем, задал ли админ следующий режим
    if self.nextModeID and self.submodes[self.nextModeID] then
        mode = self.submodes[self.nextModeID]
        
        -- Проверяем доступность режима на текущей карте
        if not isModeAvailable(mode) then
            print("[Homigrad] Admin-selected mode '" .. tostring(self.nextModeID) .. "' is not available on current map: " .. game.GetMap())
            -- Переходим к случайному выбору
            self.nextModeID = nil
        else
            selectedEntry = {
                id = self.nextModeID,
                duration = (mode and mode.Duration) or 300 -- приоритет собственной длительности режима (например, event)
            }
            
            -- Находим продолжительность из конфига
            for _, entry in ipairs(self.order) do
                if entry.id == self.nextModeID then
                    selectedEntry.duration = entry.duration
                    break
                end
            end
            
            self.nextModeID = nil -- Сбрасываем после использования
            
            print("[Homigrad] Starting admin-selected mode: " .. tostring(mode.Name or selectedEntry.id))
        end
    end
    if not mode and self.scheduledNextID and self.submodes[self.scheduledNextID] then
        -- Если есть заранее запланированный режим, используем его
        mode = self.submodes[self.scheduledNextID]
        
        -- Проверяем доступность режима на текущей карте
        if not isModeAvailable(mode) then
            print("[Homigrad] Scheduled mode '" .. tostring(self.scheduledNextID) .. "' is not available on current map: " .. game.GetMap())
            -- Сбрасываем запланированный режим и переходим к случайному выбору
            self.scheduledNextID = nil
            self.scheduledNextDuration = nil
        else
            selectedEntry = {
                id = self.scheduledNextID,
                duration = self.scheduledNextDuration or (mode and mode.Duration) or 300
            }
            -- Находим длительность из order, если не была сохранена
            if not self.scheduledNextDuration then
                for _, entry in ipairs(self.order) do
                    if entry.id == self.scheduledNextID then
                        selectedEntry.duration = entry.duration
                        break
                    end
                end
            end
            print("[Homigrad] Starting scheduled mode: " .. tostring(mode.Name or selectedEntry.id))
        end
    end
    if not mode then
        -- Случайный выбор режима из доступных
        local availableModes = {}
        for _, entry in ipairs(self.order) do
            local submode = self.submodes[entry.id]
            if submode and isModeAvailable(submode) then
                table.insert(availableModes, entry)
            end
        end
        
        if #availableModes == 0 then
            print("[Homigrad] No available modes for current map: " .. game.GetMap())
            return
        end
        
        selectedEntry = availableModes[math.random(#availableModes)]
        mode = self.submodes[selectedEntry.id]
        
        if not mode then
            print("[Homigrad] Missing mode for id "..selectedEntry.id)
            return
        end
        
        print("[Homigrad] Starting random submode: "..tostring(mode.Name or selectedEntry.id))
    end

    -- Защита от случая, когда selectedEntry не установлен (не должно происходить)
    if not selectedEntry or not mode then
        print("[Homigrad] ERROR: selectedEntry or mode is nil!")
        return
    end

    self.current = mode
    self.timeLeft = selectedEntry.duration or 60
    self.broadcastTimer = CurTime() + (SubmodeConfig.BroadcastInterval or 1)
    
    -- Сбрасываем флаг наличия охранников при старте нового раунда
    if mode.__homigrad_id == "jailbreak" then
        local guardsCount = 0
        for _, ply in ipairs(player.GetAll()) do
            if IsValid(ply) then
                local team = ply:GetNWString("HomigradTeam", "")
                if team == "guards" then
                    guardsCount = guardsCount + 1
                end
            end
        end
        self._hadGuardsThisRound = (guardsCount > 0)
    else
        self._hadGuardsThisRound = nil
    end

    if HG_Armor_RoundEndCleanup then
        HG_Armor_RoundEndCleanup()
    end

    -- Очистка карты в начале раунда (вместо конца)
    if SERVER then
        -- Удаляем все prop_physics и prop_ragdoll
        for _, ent in ipairs(ents.FindByClass("prop_physics")) do
            if IsValid(ent) then ent:Remove() end
        end
        for _, ent in ipairs(ents.FindByClass("prop_ragdoll")) do
            if IsValid(ent) then ent:Remove() end
        end
        -- Удаляем оружие, лежащее на земле (не в руках игрока) и не размещённое картой
        for _, wep in ipairs(ents.FindByClass("weapon_*")) do
            if IsValid(wep) and not IsValid(wep:GetOwner()) and (wep:MapCreationID() or -1) == -1 then
                wep:Remove()
            end
        end
        -- Удаляем транспорт, созданный не картой (оставляем статичный транспорт карты)
        for _, veh in ipairs(ents.FindByClass("prop_vehicle_*")) do
            if IsValid(veh) and (veh:MapCreationID() or -1) == -1 then
                veh:Remove()
            end
        end
        -- Популярные аддоны транспорта (если используются): удаляем не-карточные
        for _, veh in ipairs(ents.FindByClass("gmod_sent_vehicle_fphysics_*")) do
            if IsValid(veh) and (veh:MapCreationID() or -1) == -1 then
                veh:Remove()
            end
        end
        for _, veh in ipairs(ents.FindByClass("simfphys_*")) do
            if IsValid(veh) and (veh:MapCreationID() or -1) == -1 then
                veh:Remove()
            end
        end
        for _, veh in ipairs(ents.FindByClass("lvs_*")) do
            if IsValid(veh) and (veh:MapCreationID() or -1) == -1 then
                veh:Remove()
            end
        end
        for _, veh in ipairs(ents.FindByClass("scars_*")) do
            if IsValid(veh) and (veh:MapCreationID() or -1) == -1 then
                veh:Remove()
            end
        end
        -- Общая страховка: любое IsVehicle(), созданное не картой
        for _, ent in ipairs(ents.GetAll()) do
            if IsValid(ent) and (ent:MapCreationID() or -1) == -1 then
                local cls = ent:GetClass() or ""
                if ent.IsVehicle and ent:IsVehicle() then
                    ent:Remove()
                elseif string.find(cls, "vehicle", 1, true) then
                    ent:Remove()
                end
            end
        end
        -- Удаляем предметы брони, лежащие как энтити (шлемы/жилеты), если они не с карты
        for _, ent in ipairs(ents.FindByClass("ent_hg_helmet_*")) do
            if IsValid(ent) and (ent:MapCreationID() or -1) == -1 then ent:Remove() end
        end
        for _, ent in ipairs(ents.FindByClass("ent_hg_vest_*")) do
            if IsValid(ent) and (ent:MapCreationID() or -1) == -1 then ent:Remove() end
        end
        -- Очищаем декали и кровь, и всё остальное мусорное (safe mode)
        -- Всех игроков принудительно чистим декали
        for _, ply in ipairs(player.GetAll()) do
            if ply:IsValid() then ply:ConCommand("r_cleardecals") end
        end
    end

    if mode.Start then
        -- Сначала запускаем Start(), чтобы он успел раздать команды/роли
        pcall(function() mode:Start(mode, { duration = self.timeLeft }) end)
    end

    -- Цель 3 и 4: Респавним всех игроков в начале раунда
    -- Устанавливаем флаг начала раунда
    self.isRoundStart = true
    
    -- Сброс цвета одежды/модели у всех игроков перед спавном нового раунда
    for _, ply in ipairs(player.GetAll()) do
        if ply.SetPlayerColor then
            ply:SetPlayerColor(Vector(1, 1, 1))
        end
        ply:SetColor(Color(255, 255, 255))
    end
    
    -- Это вызовет GM:PlayerSpawn (из init.lua), который, в свою очередь,
    -- вызовет PlayerSpawn() текущего суб-режима (riot или homicide).
    -- Пропускаем игроков, выбравших команду наблюдателей
    for _, ply in ipairs(player.GetAll()) do
        local teamId = ply:GetNWString("HomigradTeam", "")
        if teamId ~= "spectators" then
            ply:Spawn()
        else
            -- Убедимся, что наблюдатели остаются в режиме наблюдения
            if ply.Spectate then ply:Spectate(OBS_MODE_ROAMING) end
            if ply.SetMoveType then ply:SetMoveType(MOVETYPE_OBSERVER) end
            if ply.SetNWBool then ply:SetNWBool("HomigradObserverMode", true) end
        end
    end
    
    -- Сбрасываем флаг после спавна всех игроков
    self.isRoundStart = false

    timer.Simple(0.1, function()
        for _, ply in ipairs(player.GetAll()) do
            if IsValid(ply) then
                local hasHelmet = ply:GetNWBool("HG_Helmet", false)
                local hasVest = ply:GetNWBool("HG_Vest", false)
                local helmetModel = ply:GetNWString("HG_HelmetModel", "")
                local vestModel = ply:GetNWString("HG_VestModel", "")
                if (not hasHelmet and helmetModel == "") and (not hasVest and vestModel == "") then
                    net.Start("hg_clear_player_armor")
                        net.WriteEntity(ply)
                    net.Broadcast()
                end
            end
        end
    end)

    net.Start("Homigrad_SubmodeStart")
        net.WriteString(mode.Name or selectedEntry.id)
        net.WriteInt(self.timeLeft, 32)
    net.Broadcast()
    
    -- Для JailBreak проверяем охранников после старта и отправляем предупреждение если их нет
    if mode.__homigrad_id == "jailbreak" then
        timer.Simple(0.1, function()
            local guardsCount = 0
            for _, ply in ipairs(player.GetAll()) do
                if IsValid(ply) then
                    local team = ply:GetNWString("HomigradTeam", "")
                    if team == "guards" then
                        guardsCount = guardsCount + 1
                    end
                end
            end
            
            if guardsCount < 1 then
                -- Отправляем предупреждение всем игрокам
                net.Start("Homigrad_NoGuardsWarning")
                net.Broadcast()
            end
        end)
    end
    
    -- Планируем и транслируем следующий режим для корректного клиентского отображения
    do
        local availableModes = {}
        for _, entry in ipairs(self.order) do
            local submode = self.submodes[entry.id]
            if submode and isModeAvailable(submode) then
                table.insert(availableModes, entry)
            end
        end
        if #availableModes > 0 then
            local planned = availableModes[math.random(#availableModes)]
            self.scheduledNextID = planned.id
            self.scheduledNextDuration = planned.duration
            local plannedMode = self.submodes[self.scheduledNextID]
            local plannedName = plannedMode and (plannedMode.Name or self.scheduledNextID) or "Unknown"
            net.Start("Homigrad_NextMode")
                net.WriteString(plannedName)
            net.Broadcast()
            print("[Homigrad] Planned next mode: " .. tostring(plannedName))
        end
    end
end

function SubmodeManager:Think()
    if #player.GetAll() < MIN_PLAYERS then
        self.waitingForPlayers = true
        self.current = nil
        -- Отправляем клиентам сообщение
        net.Start("Homigrad_WaitingForPlayers")
            net.WriteBool(true)
        net.Broadcast()
        return
    end

    if self.waitingForPlayers then
        -- Переход из ожидания к активному раунду
        self.waitingForPlayers = false
        net.Start("Homigrad_WaitingForPlayers")
            net.WriteBool(false)
        net.Broadcast()
        self:StartNext()
    end

    if not self.current then return end

    local ct = CurTime()
    self.timeLeft = math.max(0, self.timeLeft - FrameTime())

    -- Для JailBreak проверяем появление охранников и перезапускаем раунд
    if self.current.__homigrad_id == "jailbreak" then
        local guardsCount = 0
        for _, ply in ipairs(player.GetAll()) do
            if IsValid(ply) then
                local team = ply:GetNWString("HomigradTeam", "")
                if team == "guards" then
                    guardsCount = guardsCount + 1
                end
            end
        end
        
        -- Если появился первый охранник (когда раунд идет), перезапускаем
        if guardsCount > 0 and not self._hadGuardsThisRound then
            self._hadGuardsThisRound = true
            print("[Homigrad|JailBreak] First guard appeared! Restarting round...")
            -- Сохраняем текущий режим
            local currentMode = self.current
            -- Перезапускаем раунд через небольшую задержку
            timer.Simple(0.5, function()
                if SubmodeManager and SubmodeManager.StartNext then
                    SubmodeManager:StartNext()
                end
            end)
            return -- Прерываем дальнейшее выполнение
        end
        
        -- Отслеживаем наличие охранников для следующего раунда
        if guardsCount == 0 then
            self._hadGuardsThisRound = false
        end
    end

    -- Цель 1: Проверка на досрочное завершение раунда (победа команды)
    local endRound = false
    if self.current.CheckRoundEnd then
        local ok, shouldEnd = pcall(function() return self.current:CheckRoundEnd(self.current) end)
        if not ok then 
            print("[Homigrad] submode CheckRoundEnd error: ", shouldEnd) -- shouldEnd = err
        elseif shouldEnd then
            endRound = true
        end
    end

    if self.current.Think then
        local ok, err = pcall(function() self.current:Think(self.current) end)
        if not ok then print("[Homigrad] submode Think error: ", err) end
    end

    if ct >= (self.broadcastTimer or 0) then
        self.broadcastTimer = ct + (SubmodeConfig.BroadcastInterval or 1)
        net.Start("Homigrad_SubmodeUpdate")
            net.WriteString(self.current.Name or "")
            net.WriteInt(math.ceil(self.timeLeft), 32)
        net.Broadcast()
    end

    -- Заканчиваем раунд: по победе обязательно, по таймеру — если режим не запрещает
    local timerExpired = (self.timeLeft <= 0)
    if self.current and self.current.IgnoreTimer then
        timerExpired = false
    end
    if (timerExpired or endRound) and not self.isEnding then
        self.isEnding = true -- Предотвращаем множественные вызовы
        
        -- Вызываем End() у текущего режима (если есть)
        if self.current and self.current.End then
            pcall(function() self.current:End() end)
        end
        if HG_Armor_RoundEndCleanup then HG_Armor_RoundEndCleanup() end

        -- Принудительно выводим всех игроков из рэгдолла и очищаем состояния, чтобы они могли нормально заспавниться
        for _, ply in ipairs(player.GetAll()) do
            if IsValid(ply) then
                if ply.SetNWBool then
                    ply:SetNWBool("HG_Blackout", false)
                    ply:SetNWBool("hg_pain_ragdoll", false)
                end
                if ply.SetHGBrokenSpine then ply:SetHGBrokenSpine(false) end
                if ply.SetHGBrokenLeg then ply:SetHGBrokenLeg(false) end
                if HG_StopRagdoll then HG_StopRagdoll(ply, true) end
            end
        end
        
        -- Задержка 7 секунд перед началом следующего раунда
        timer.Simple(7, function()
            if self and self.StartNext then
                self.isEnding = false -- Сбрасываем флаг
                self:StartNext()
            end
        end)
    end
end

-- Сетевой канал для уведомления о минимальных игроках
if SERVER then
    util.AddNetworkString("Homigrad_SubmodeUpdate")
    util.AddNetworkString("Homigrad_SubmodeStart")
    util.AddNetworkString("Homigrad_WaitingForPlayers")
    util.AddNetworkString("Homigrad_RoundEnd")
    util.AddNetworkString("Homigrad_NextMode")
    util.AddNetworkString("Homigrad_NoGuardsWarning")
end

if CLIENT then
    hook.Add("HUDPaint", "Homigrad_WaitingForPlayersText", function()
        net.Receive("Homigrad_WaitingForPlayers", function()
            draw.SimpleText("Для начала игры нужно минимум 2 игрока", "Trebuchet24", ScrW()/2, ScrH()/2, Color(255,50,50,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end)
    end)
end